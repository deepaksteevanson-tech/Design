// Dev server: rebuilds on every change in src/ or public/ and reloads the browser.
// Usage: npm run dev  (or: node scripts/dev.mjs [port])
import { createServer } from "node:http";
import { readFileSync, existsSync, watch } from "node:fs";
import { join, extname, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { build } from "./build.mjs";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const port = Number(process.argv[2] || process.env.PORT || 5173);
let version = String(Date.now());
const rebuild = () => {
  try { build({ dev: true }); version = String(Date.now()); console.log(`[dev] rebuilt ${new Date().toLocaleTimeString()}`); }
  catch (e) { console.error("[dev] build failed:", e.message); }
};
rebuild();
let t;
for (const d of ["src", "public"]) watch(join(root, d), { recursive: true }, () => { clearTimeout(t); t = setTimeout(rebuild, 80); });

const types = { ".html": "text/html; charset=utf-8", ".jpg": "image/jpeg", ".png": "image/png", ".css": "text/css", ".js": "text/javascript" };
createServer((req, res) => {
  const url = decodeURIComponent(req.url.split("?")[0]);
  if (url === "/__version") { res.writeHead(200, { "content-type": "text/plain", "cache-control": "no-store" }); return res.end(version); }
  const file = join(root, "dist", url === "/" ? "index.html" : url.replace(/^\/+/, ""));
  if (!file.startsWith(join(root, "dist")) || !existsSync(file)) { res.writeHead(404); return res.end("Not found"); }
  res.writeHead(200, { "content-type": types[extname(file)] || "application/octet-stream", "cache-control": "no-store" });
  res.end(readFileSync(file));
}).listen(port, () => console.log(`[dev] AlphaX Admin on http://localhost:${port}  (edit src/, the page reloads)`));
