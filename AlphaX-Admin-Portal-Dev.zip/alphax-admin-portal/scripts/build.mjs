// Build the AlphaX Admin portal into one self-contained page.
//   dist/index.html     full HTML document (open it, or host it on any static server)
//   dist/artifact.html  fragment for a claude.ai Artifact (the host adds <!doctype>/<head>/<body>)
//   dist/cover.jpg, dist/alphax-logo.png  copied from public/
// No dependencies: Node 18+ only.
import { readFileSync, writeFileSync, mkdirSync, readdirSync, copyFileSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const src = (...p) => join(root, "src", ...p);
const read = (p) => readFileSync(p, "utf8");

export function build({ dev = false } = {}) {
  const head = read(src("partials", "head.html")).trim();
  // alphax-portal.css is the shared Asset App stylesheet: never edit it here. Admin rules live in admin.css.
  const css = read(src("styles", "alphax-portal.css")) + "\n" + read(src("styles", "admin.css"));
  const body = read(src("partials", "body.html")).trim();
  const js = readdirSync(src("js")).filter((f) => f.endsWith(".js")).sort()
    .map((f) => `/* ---- src/js/${f} ---- */\n` + read(src("js", f))).join("\n");
  const script = `(function(){\n"use strict";\n${js}\n})();`;
  const live = dev
    ? `\n<script>/* dev live reload */(function(){var v=null;setInterval(function(){fetch("/__version").then(function(r){return r.text()}).then(function(t){if(v&&t!==v)location.reload();v=t}).catch(function(){})},800)})();</script>`
    : "";
  const fragment = `${head}\n<style>\n${css}\n</style>\n\n${body}\n<script>\n${script}\n</script>${live}\n`;
  const full = `<!doctype html>\n<html lang="en">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">\n${head}\n<style>\n${css}\n</style>\n</head>\n<body>\n${body}\n<script>\n${script}\n</script>${live}\n</body>\n</html>\n`;
  const out = join(root, "dist");
  mkdirSync(out, { recursive: true });
  writeFileSync(join(out, "index.html"), full);
  if (!dev) writeFileSync(join(out, "artifact.html"), fragment);
  for (const f of readdirSync(join(root, "public"))) copyFileSync(join(root, "public", f), join(out, f));
  return { bytes: full.length, files: readdirSync(src("js")).length };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const r = build();
  console.log(`Built dist/index.html (${(r.bytes / 1024).toFixed(0)} KB, ${r.files} script files) and dist/artifact.html`);
}
