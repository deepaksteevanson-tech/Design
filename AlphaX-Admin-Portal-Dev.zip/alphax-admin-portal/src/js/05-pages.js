/* =====================================================================
   Pages: Overview (alerts, fleet), Requests, Assets, People, New joiners, Infrastructure, Reports renderers
   Concatenated in file-name order by scripts/build.mjs inside one IIFE
   ("use strict"), so every top-level name here is shared with the other files.
   ===================================================================== */

/* =====================================================================
   PAGES
   ===================================================================== */
var F={req:"all",asset:"all",people:"all",join:"all",infra:"all",kit:"all",act:"all"};
var Q={req:"",asset:"",people:"",join:"",infra:"",kit:""};

/* ---------- alerts: checks run on every render ---------- */
function alerts(){
  var out=[];
  var groups={};S.assets.forEach(function(a){var s=String(a.serial||"").trim().toUpperCase();if(!s||a.status==="Retired")return;(groups[s]=groups[s]||[]).push(a)});
  var n=0;Object.keys(groups).forEach(function(s){var g=groups[s];if(g.length<2)return;n++;
    out.push({id:n===1?"alert-dup":"alert-dup-"+n,sev:"error",icon:IC.warn,title:"Serial "+g[0].serial+" is on "+g.map(function(a){return a.id}).join(" and "),desc:"Each device should have its own serial. Existing rows were left as they are; new saves cannot reuse this serial.",affects:g.map(function(a){return a.id}).join(", "),items:g.map(function(a){return {t:"asset",id:a.id}})})});
  var ex=S.people.filter(function(p){return p.status==="Exited"&&kitOf(p.id).length});
  if(ex.length)out.push({id:"alert-exited",sev:"error",icon:IC.exit,title:(ex.length===1?"1 person left but still holds kit":ex.length+" people left but still hold kit"),desc:"Return their kit to stock or assign it to someone else. Exiting a person does not collect it.",affects:ex.map(function(p){return p.name}).join(", "),items:ex.map(function(p){return {t:"person",id:p.id}})});
  var miss=[];["Laptop","Keyboard","Mouse","Monitor"].forEach(function(t){["Dubai","Uganda"].forEach(function(o){if(!stockFor(t,o).length)miss.push("No spare "+t.toLowerCase()+" in "+o)})});
  if(miss.length)out.push({id:"alert-spares",sev:"warning",icon:IC.box,title:miss.slice(0,2).join(" · ")+(miss.length>2?" and "+(miss.length-2)+" more":""),desc:"Add spares to stock so IT does not discover this only when someone requests it.",affects:plural(miss.length,"gap"),items:[],list:miss});
  var ret=S.assets.filter(function(a){return a.status==="Returned"});
  if(ret.length)out.push({id:"alert-returned",sev:"warning",icon:IC.back,title:plural(ret.length,"returned item")+" waiting for a check",desc:"Check condition and data, then move each one to stock or retire it.",affects:ret.map(function(a){return a.id}).join(", "),items:ret.map(function(a){return {t:"asset",id:a.id}})});
  var ns=S.assets.filter(function(a){return !String(a.serial||"").trim()&&a.status!=="Retired"});
  if(ns.length)out.push({id:"alert-noserial",sev:"",icon:IC.label,title:plural(ns.length,"asset")+" without a serial number",desc:"Read the serial from the sticker next time the device is at the IT desk, so it can be tracked and claimed under warranty.",affects:ns.slice(0,4).map(function(a){return a.id}).join(", ")+(ns.length>4?" +"+(ns.length-4):""),items:ns.map(function(a){return {t:"asset",id:a.id}})});
  return out;
}
var SEV={error:["High","error"],warning:["Medium","warning"],"":["Low",""]};
function sevTag(s){var v=SEV[s];return '<span class="a-tag'+(v[1]?' a-tag--'+v[1]:'')+'">'+v[0]+'</span>'}
function openAlert(al){
  var list=al.items.length?'<div class="klist">'+al.items.map(function(it){
    if(it.t==="asset"){var a=asset(it.id);if(!a)return "";return '<button type="button" data-k="asset:'+a.id+'">'+aArt(a,"xs")+'<span class="nm"><b>'+esc(a.id)+' · '+esc(a.name)+'</b><span>'+esc(a.serial||"No serial")+' · '+esc(holderName(a)||("Stock · "+a.loc))+'</span></span>'+aTag(a)+'<span class="go">'+IC.chev+'</span></button>'}
    var p=person(it.id);return '<button type="button" data-k="person:'+p.id+'"><span class="av">'+initials(p.name)+'</span><span class="nm"><b>'+esc(p.name)+'</b><span>'+esc(p.id)+' · '+plural(kitOf(p.id).length,"asset")+' still on their name</span></span><span class="go">'+IC.chev+'</span></button>'}).join("")+'</div>'
    :'<div class="klist">'+(al.list||[]).map(function(t){return '<div><span class="ti n">'+IC.box+'</span><span class="nm"><b>'+esc(t)+'</b><span>Nothing unassigned to issue</span></span></div>'}).join("")+'</div>';
  var body='<div class="dhero"><span class="ti n">'+al.icon+'</span><div><h4>'+esc(al.title)+'</h4><p>'+SEV[al.sev][0]+' priority · '+esc(al.affects)+'</p></div></div>'+nextStrip(al.desc)+'<div class="dsub">'+(al.items.length?"Open an item to fix it":"Gaps by office")+'</div>'+list;
  var foot=al.id==="alert-spares"?'<span style="flex:1"></span><button class="a-btn a-btn--primary" type="button" id="al-add">'+IC.plus+'Add to stock</button>':(al.id==="alert-returned"?'<span style="flex:1"></span><button class="a-btn a-btn--primary" type="button" id="al-ret">'+IC.box+'Move all to stock</button>':'');
  openDrawer('Check · '+SEV[al.sev][0]+' priority',body,foot);
  bindK($("#dr-body"));
  on("al-add",function(){openAddStock()});
  on("al-ret",function(){var ret=S.assets.filter(function(a){return a.status==="Returned"});ret.forEach(function(a){a.status="In stock";a.holder="";addAssetEvent(a,"Moved to stock","Checked after return · unassigned in "+a.loc);log("assign",a.id+" ("+a.name+") checked and moved to stock",a.id)});save();renderAll();closeDrawer();toast(plural(ret.length,"item")+" moved to stock.","success")});
}
function bindK(rt){$$("[data-k]",rt).forEach(function(b){b.addEventListener("click",function(){var p=b.getAttribute("data-k").split(":");if(p[0]==="asset")openAsset(p[1]);else if(p[0]==="person")openPerson(p[1]);else if(p[0]==="req")openRequest(req(p[1]))})})}

/* ---------- requests table (Overview + Requests) ---------- */
function reqRow(r,wide){
  var p=person(r.emp);
  return '<tr class="row'+(needsYou(r)?' mine-turn':'')+'" tabindex="0" data-open="req:'+r.id+'"><td class="num">'+esc(r.id)+'<span class="sub">'+esc(r.date)+'</span></td>'+
    '<td>'+avCell(r.who,(p?p.title||"":"")+(p&&p.title?" · ":"")+r.office)+'</td>'+
    '<td><div class="cell">'+art(rArtType(r),"",r.title)+'<div class="it-main"><b>'+esc(rTitle(r))+'</b><span>'+esc(KIND[r.kind])+(r.ref?' · '+esc(r.ref):'')+'</span></div></div></td>'+
    (wide?'<td class="num">'+esc(r.cost)+'</td>':'')+
    '<td>'+rStockTag(r)+'</td><td>'+rTag(r)+'</td><td class="go">'+IC.chev+'</td></tr>';
}
var REQ_GET={who:function(r){return r.who},item:function(r){return rTitle(r)},raised:function(r){return dnum(r.date)},status:function(r){return RORDER.indexOf(r.st)}};
var RF=[["all","All",function(){return true}],["you","Needs you",needsYou],["mgr","With managers",function(r){return r.st==="mgr"}],["buy","Buying",function(r){return ["proc","ceo","pay","delivery"].indexOf(r.st)!==-1}],["repair","Service",function(r){return r.kind==="service"&&!rClosed(r)}],["closed","Closed",rClosed]];
function renderReqTable(){
  var tid="req-table";
  $("#"+tid+" thead").innerHTML=thead(tid,[{l:"Request ID"},{l:"Requested by",k:"who"},{l:"Item",k:"item"},{l:"Est. cost"},{l:"Stock"},{l:"Status",k:"status"},{l:""}]);
  drawPills("#req-tabs",RF,F.req,S.reqs,function(f){F.req=f;renderReqTable()});
  var f=RF.filter(function(x){return x[0]===F.req})[0];
  var list=S.reqs.filter(f[2]).filter(function(r){return matchQ(Q.req,[r.id,r.who,rTitle(r),r.ref,r.office,KIND[r.kind],rLabel(r)])});
  list=SORT[tid]?sortBy(list,tid,REQ_GET):list.slice().sort(function(a,b){return RORDER.indexOf(a.st)-RORDER.indexOf(b.st)||dnum(b.date)-dnum(a.date)});
  $("#"+tid+" tbody").innerHTML=list.length?list.map(function(r){return reqRow(r,true)}).join(""):noneRow(7,F.req==="you"?"Nothing is waiting for you. New requests appear here after the manager approves.":"No requests match.");
}
RENDER["req-table"]=renderReqTable;
function renderHomeReqs(){
  var tid="home-req-table";
  $("#"+tid+" thead").innerHTML=thead(tid,[{l:"Request ID"},{l:"Requested by",k:"who"},{l:"Item",k:"item"},{l:"Stock"},{l:"Status",k:"status"},{l:""}]);
  var list=S.reqs.filter(needsYou);
  list=SORT[tid]?sortBy(list,tid,REQ_GET):list.sort(function(a,b){return RORDER.indexOf(a.st)-RORDER.indexOf(b.st)||dnum(a.date)-dnum(b.date)});
  $("#"+tid+" tbody").innerHTML=list.length?list.map(function(r){return reqRow(r,false)}).join(""):noneRow(6,"Nothing is waiting for you. New requests appear here after the manager approves.");
}
RENDER["home-req-table"]=renderHomeReqs;
function renderReqPage(){
  var n=function(fn){return S.reqs.filter(fn).length};
  var you=n(needsYou),mgr=n(function(r){return r.st==="mgr"}),buy=n(RF[3][2]),cls=n(rClosed);
  drawTiles("#req-tiles",[
    ["#requests","you",IC.clock,you?you+" waiting for you":"Nothing waiting for you","Stock checks, deliveries and repairs."],
    ["#requests","mgr",IC.people,mgr+" with managers","Still with the manager. They reach you next."],
    ["#requests","buy",IC.cart,buy+" being bought","With Procurement, the CEO, Finance or courier."],
    ["#requests","closed",IC.done,cls+" closed","Delivered, not valid or declined."]
  ],function(k){F.req=k;renderReqTable();scrollToEl("#req-tabs")});
  heroMeta("#req-hero-meta",[you?you+" waiting for you":"Nothing waiting for you",buy+" being bought","Stock first, then Procurement → CEO → Finance"]);
  /* spare stock summary by type and office */
  var groups={};S.assets.filter(function(a){return a.status==="In stock"}).forEach(function(a){var k=a.type+"|"+a.loc;(groups[k]=groups[k]||[]).push(a)});
  var keys=Object.keys(groups).sort();
  $("#stock-summary").innerHTML=keys.length?keys.map(function(k){var g=groups[k];var a=g[0];return '<button type="button" data-stock="'+esc(a.type)+'">'+aArt(a,"xs")+'<span class="nm"><b>'+plural(g.length,a.type.toLowerCase())+' · '+esc(a.loc)+'</b><span>'+esc(g.map(function(x){return x.id}).join(", "))+'</span></span><span class="go">'+IC.chev+'</span></button>'}).join(""):'<div class="none">Nothing in stock. Add spares from Assets.</div>';
  $$("[data-stock]").forEach(function(b){b.addEventListener("click",function(){F.asset="stock";Q.asset=b.getAttribute("data-stock");$("#asset-q").value=Q.asset;renderAssetTable();goTo("assets","#asset-tabs")})});
  renderReqTable();
  var badge=you;$$('.nav [data-nav="requests"],.mnav [data-nav="requests"]').forEach(function(a){a.innerHTML="Requests"+(badge?'<span class="nav-n">'+badge+'</span>':'')});
  var d=$("#dock-req-n");d.hidden=!badge;d.textContent=badge;
}

/* ---------- assets ---------- */
var ASTAT={"Assigned":"success","In stock":"info","Returned":"warning","In repair":"info","Retired":""};
function aTag(a){var c=ASTAT[a.status];return '<span class="a-tag'+(c?' a-tag--'+c:'')+'">'+esc(a.status==="Returned"?"Returned · check":a.status)+'</span>'}
var AF=[["all","All",function(){return true}],["assigned","Assigned",function(a){return a.status==="Assigned"}],["stock","In stock",function(a){return a.status==="In stock"}],["returned","Returned",function(a){return a.status==="Returned"}],["repair","In repair",function(a){return a.status==="In repair"}],["retired","Retired",function(a){return a.status==="Retired"}]];
function renderAssetTable(){
  var tid="asset-table";
  $("#"+tid+" thead").innerHTML=thead(tid,[{l:"Asset ID",k:"id"},{l:"Item",k:"item"},{l:"Type",k:"type"},{l:"Serial"},{l:"Held by",k:"holder"},{l:"Status",k:"status"},{l:""}]);
  drawPills("#asset-tabs",AF,F.asset,S.assets,function(f){F.asset=f;renderAssetTable()});
  var f=AF.filter(function(x){return x[0]===F.asset})[0];
  var dup={};alerts().filter(function(a){return a.id.indexOf("alert-dup")===0}).forEach(function(a){a.items.forEach(function(i){dup[i.id]=1})});
  var list=S.assets.filter(f[2]).filter(function(a){return matchQ(Q.asset,[a.id,a.name,a.brand,a.model,a.serial,a.type,holderName(a),a.holder,a.loc,a.status])});
  list=sortBy(list,tid,{id:function(a){return a.id},item:function(a){return a.name},type:function(a){return a.type},holder:function(a){return holderName(a)||"~"+a.loc},status:function(a){return a.status}});
  $("#"+tid+" tbody").innerHTML=list.length?list.map(function(a){
    var h=holderName(a);var p=a.holder?person(a.holder):null;
    return '<tr class="row" tabindex="0" data-open="asset:'+a.id+'"><td class="num">'+a.id+'</td><td><div class="cell">'+aArt(a)+'<div class="it-main"><b>'+esc(a.name)+'</b><span>'+esc([a.brand,a.model].filter(Boolean).join(" · ")||a.type)+'</span></div></div></td><td>'+esc(a.type)+'</td><td>'+(a.serial?'<code>'+esc(a.serial)+'</code>':'<span style="color:var(--fg-3)">—</span>')+'</td>'+
      '<td>'+(h&&a.status!=="Returned"?esc(h)+'<span class="sub">'+esc(a.holder)+(p&&p.status==="Exited"?' · Exited':'')+'</span>':'<span style="color:var(--fg-3)">'+(a.status==="Retired"?"Retired":"Stock · "+esc(a.loc))+'</span>'+(h?'<span class="sub">Was '+esc(h)+'</span>':''))+'</td>'+
      '<td><div class="tags">'+aTag(a)+(dup[a.id]?'<span class="a-tag a-tag--error">Serial reused</span>':'')+'</div></td><td class="go">'+IC.chev+'</td></tr>'}).join(""):noneRow(7,"No assets match.");
}
RENDER["asset-table"]=renderAssetTable;
function renderAssetPage(){
  var c=function(st){return S.assets.filter(function(a){return a.status===st}).length};
  var tot=S.assets.length,as=c("Assigned"),st=c("In stock"),rt=c("Returned"),rp=c("In repair");
  drawTiles("#asset-tiles",[
    ["#assets","all",IC.laptop,tot+" assets on file","Every device, including stock and returns."],
    ["#assets","assigned",IC.check,as+" assigned","On someone's name right now."],
    ["#assets","stock",IC.box,st+" in stock","Spares IT can issue without buying."],
    ["#assets",rt?"returned":"repair",IC.wrench,(rt+rp)+" returned or in repair","Check before they go back to stock."]
  ],function(k){F.asset=k;Q.asset="";$("#asset-q").value="";renderAssetTable();scrollToEl("#asset-tabs")});
  heroMeta("#asset-hero-meta",[tot+" assets",as+" assigned",st+" in stock",rt+" returned",rp+" in repair"]);
  renderAssetTable();
}

/* ---------- people ---------- */
var PF=[["all","All",function(){return true}],["active","Active",function(p){return p.status==="Active"}],["exited","Exited",function(p){return p.status==="Exited"}],["noemail","No official email",function(p){return !p.email}],["nokit","No kit",function(p){return !kitOf(p.id).length}]];
function deskOf(p){return S.settings.desks[p.name]||(p.email?"Staff":"No sign-in")}
function pTag(p){return p.status==="Exited"?'<span class="a-tag a-tag--error">Exited</span>':'<span class="a-tag a-tag--success">Active</span>'}
function renderPeopleTable(){
  var tid="people-table";
  $("#"+tid+" thead").innerHTML=thead(tid,[{l:"Person",k:"name"},{l:"Employee ID",k:"id"},{l:"Location"},{l:"Manager"},{l:"Desk",k:"desk"},{l:"Assets",k:"assets"},{l:"Status",k:"status"},{l:""}]);
  drawPills("#people-tabs",PF,F.people,S.people,function(f){F.people=f;renderPeopleTable()});
  var f=PF.filter(function(x){return x[0]===F.people})[0];
  var list=S.people.filter(f[2]).filter(function(p){return matchQ(Q.people,[p.name,p.id,p.title,p.email,p.dept,p.loc,p.mgr])});
  list=sortBy(list,tid,{name:function(p){return p.name},id:function(p){return p.id},desk:function(p){return deskOf(p)},assets:function(p){return kitOf(p.id).length},status:function(p){return p.status}});
  $("#"+tid+" tbody").innerHTML=list.length?list.map(function(p){var k=kitOf(p.id).length;var ex=p.status==="Exited"&&k;
    return '<tr class="row'+(ex?' mine-turn':'')+'" tabindex="0" data-open="person:'+p.id+'"><td>'+avCell(p.name,p.title||"No job title")+'</td><td class="num">'+esc(p.id)+'</td><td>'+esc(p.loc)+'</td><td class="dim">'+dash(p.mgr)+'</td><td>'+esc(deskOf(p))+'</td><td class="num">'+(k?'<b>'+k+'</b>':'<span style="color:var(--fg-3)">0</span>')+(ex?'<span class="sub">Still assigned</span>':'')+'</td><td>'+pTag(p)+'</td><td class="go">'+IC.chev+'</td></tr>'}).join(""):noneRow(8,"Nobody matches.");
}
RENDER["people-table"]=renderPeopleTable;
function renderPeoplePage(){
  var act=S.people.filter(function(p){return p.status==="Active"}).length,ex=S.people.filter(function(p){return p.status==="Exited"});
  var exk=ex.filter(function(p){return kitOf(p.id).length}).length,noe=S.people.filter(function(p){return !p.email}).length;
  var withKit=S.people.filter(function(p){return kitOf(p.id).length}).length;
  drawTiles("#people-tiles",[
    ["#people","all",IC.people,S.people.length+" people on file","Active and exited, Dubai and Uganda."],
    ["#people","active",IC.check,withKit+" hold company kit","At least one asset on their name."],
    ["#people","exited",IC.exit,exk?exk+" left with kit":"Nobody left with kit","Exited, with assets still on their name."],
    ["#people","noemail",IC.mail,noe+" without official email","On file, but they cannot sign in."]
  ],function(k){F.people=k;renderPeopleTable();scrollToEl("#people-tabs")});
  heroMeta("#people-hero-meta",[S.people.length+" people",act+" active",ex.length+" exited","Dubai and Uganda"]);
  renderPeopleTable();
}

/* ---------- new joiners ---------- */
var JST={hr:["With HR",""],mgr:["With manager",""],it:["With IT","warning"],sign:["Waiting for signature","info"],joined:["Joined","success"]};
var JORDER=["it","sign","mgr","hr","joined"];
function jTag(j){var s=JST[j.st];return '<span class="a-tag'+(s[1]?' a-tag--'+s[1]:'')+'">'+s[0]+'</span>'}
var JF=[["all","All",function(){return true}],["hr","With HR",function(j){return j.st==="hr"}],["mgr","With manager",function(j){return j.st==="mgr"}],["it","With IT",function(j){return j.st==="it"}],["sign","Waiting for signature",function(j){return j.st==="sign"}],["joined","Joined",function(j){return j.st==="joined"}]];
function renderJoinTable(){
  var tid="join-table";
  $("#"+tid+" thead").innerHTML=thead(tid,[{l:"Joiner ID"},{l:"Name",k:"name"},{l:"Manager",k:"mgr"},{l:"Works from"},{l:"Kit"},{l:"Status",k:"status"},{l:""}]);
  drawPills("#join-tabs",JF,F.join,S.joiners,function(f){F.join=f;renderJoinTable()});
  var f=JF.filter(function(x){return x[0]===F.join})[0];
  var list=S.joiners.filter(f[2]).filter(function(j){return matchQ(Q.join,[j.id,j.name,j.pos,j.mgr,j.email,j.loc])});
  list=SORT[tid]?sortBy(list,tid,{name:function(j){return j.name},mgr:function(j){return j.mgr},status:function(j){return JORDER.indexOf(j.st)}}):list.slice().sort(function(a,b){return JORDER.indexOf(a.st)-JORDER.indexOf(b.st)});
  $("#"+tid+" tbody").innerHTML=list.length?list.map(function(j){
    return '<tr class="row'+(j.st==="it"?' mine-turn':'')+'" tabindex="0" data-open="join:'+j.id+'"><td class="num">'+esc(j.id)+'<span class="sub">Starts '+esc(j.start)+'</span></td><td>'+avCell(j.name,j.pos||"Position to confirm")+'</td><td class="dim">'+esc(j.mgr)+'</td><td>'+esc(j.from)+' · '+esc(j.loc)+'</td><td><div class="tags">'+(j.kit.length?j.kit.map(function(k){return '<span class="a-tag">'+esc(ITEM_LABEL[k])+'</span>'}).join(""):'<span style="color:var(--fg-3)">Manager picks</span>')+'</div></td><td>'+jTag(j)+'</td><td class="go">'+IC.chev+'</td></tr>'}).join(""):noneRow(7,F.join==="it"?"Nobody is with IT. Joiners arrive here after the manager picks the kit.":"No joiners here.");
}
RENDER["join-table"]=renderJoinTable;
function renderJoinPage(){
  var c=function(s){return S.joiners.filter(function(j){return j.st===s}).length};
  var it=c("it"),prog=S.joiners.filter(function(j){return j.st!=="joined"}).length;
  drawTiles("#join-tiles",[
    ["#joiners","hr",IC.person,c("hr")+" with HR","HR is adding the person and position."],
    ["#joiners","mgr",IC.people,c("mgr")+" with managers","The manager picks the laptop and kit."],
    ["#joiners","it",IC.laptop,it?it+" waiting for you":"Nothing with IT","Record a serial per item, then send the link."],
    ["#joiners","sign",IC.sign,c("sign")+" waiting for signature","The employee signs form AXAF0726015."]
  ],function(k){F.join=k;renderJoinTable();scrollToEl("#join-tabs")});
  heroMeta("#join-hero-meta",[prog+" in progress",it+" with IT","HR → Manager → IT → Employee signs"]);
  $$('.nav [data-nav="joiners"],.mnav [data-nav="joiners"]').forEach(function(a){a.innerHTML="New joiners"+(it?'<span class="nav-n">'+it+'</span>':'')});
  var d=$("#dock-join-n");d.hidden=!it;d.textContent=it;
  renderJoinTable();
}

/* ---------- infrastructure ---------- */
var INF_IC={Office:IC.room,Floor:IC.floor,Room:IC.room,Network:IC.globe,"Wi-Fi":IC.wifi,Server:IC.server,Circuit:IC.globe};
var NETW=["Network","Wi-Fi","Server","Circuit"];
var IF=[["all","All",function(){return true}],["sites","Offices and floors",function(x){return x.type==="Office"||x.type==="Floor"}],["rooms","Rooms",function(x){return x.type==="Room"}],["net","Network and servers",function(x){return NETW.indexOf(x.type)!==-1}]];
function iTag(x){return '<span class="a-tag'+(x.status==="In service"?' a-tag--success':x.status==="Down"?' a-tag--error':' a-tag--warning')+'">'+esc(x.status)+'</span>'}
function renderInfraTable(){
  var tid="infra-table";
  $("#"+tid+" thead").innerHTML=thead(tid,[{l:"Name",k:"name"},{l:"ID",k:"id"},{l:"Type",k:"type"},{l:"Site",k:"site"},{l:"Host / IP"},{l:"Status",k:"status"},{l:"Owner"},{l:""}]);
  drawPills("#infra-tabs",IF,F.infra,S.infra,function(f){F.infra=f;renderInfraTable()});
  var f=IF.filter(function(x){return x[0]===F.infra})[0];
  var list=S.infra.filter(f[2]).filter(function(x){return matchQ(Q.infra,[x.id,x.name,x.type,x.site,x.host,x.ip,x.owner,x.city])});
  list=sortBy(list,tid,{name:function(x){return x.name},id:function(x){return x.id},type:function(x){return x.type},site:function(x){return x.site},status:function(x){return x.status}});
  $("#"+tid+" tbody").innerHTML=list.length?list.map(function(x){
    return '<tr class="row" tabindex="0" data-open="infra:'+x.id+'"><td><div class="cell"><span class="ti n">'+(INF_IC[x.type]||IC.room)+'</span><div class="it-main"><b>'+esc(x.name)+'</b><span>'+esc(x.city)+(x.notes?' · '+esc(x.notes):'')+'</span></div></div></td><td class="num">'+esc(x.id)+'</td><td>'+esc(x.type)+'</td><td class="dim">'+dash(x.site)+'</td><td>'+(x.host||x.ip?esc([x.host,x.ip].filter(Boolean).join(" · ")):'<span style="color:var(--fg-3)">—</span>')+'</td><td>'+iTag(x)+'</td><td class="dim">'+dash(x.owner)+'</td><td class="go">'+IC.chev+'</td></tr>'}).join(""):noneRow(8,"Nothing matches.");
}
RENDER["infra-table"]=renderInfraTable;
function renderInfraPage(){
  var c=function(fn){return S.infra.filter(fn).length};
  var rooms=c(IF[2][2]),sites=c(IF[1][2]),net=c(IF[3][2]),down=c(function(x){return x.status!=="In service"});
  drawTiles("#infra-tiles",[
    ["#infra","all",IC.room,S.infra.length+" records on file","Offices, floors, rooms and network."],
    ["#infra","sites",IC.floor,sites+" offices and floors","Where every room and device sits."],
    ["#infra","rooms",IC.room,rooms+" rooms","Cabins, storerooms and workstations."],
    ["#infra","net",IC.wifi,net?net+" network and servers":"No network on file","Wi-Fi, servers and circuits."]
  ],function(k){F.infra=k;renderInfraTable();scrollToEl("#infra-tabs")});
  heroMeta("#infra-hero-meta",[S.infra.length+" records",rooms+" rooms",down?down+" need attention":"All in service","Alpha X office, Dubai"]);
  renderInfraTable();
}

/* ---------- reports ---------- */
var KF=[["all","All",function(p){return true}],["kit","With kit",function(p){return kitOf(p.id).length>0}],["nokit","No kit",function(p){return !kitOf(p.id).length}]];
function renderKitTable(){
  var tid="kit-table";
  $("#"+tid+" thead").innerHTML=thead(tid,[{l:"Person",k:"name"},{l:"Employee ID",k:"id"},{l:"Location"},{l:"Items",k:"items"},{l:"Asset details"},{l:""}]);
  drawPills("#kit-tabs",KF,F.kit,S.people,function(f){F.kit=f;renderKitTable()});
  var f=KF.filter(function(x){return x[0]===F.kit})[0];
  var list=S.people.filter(f[2]).filter(function(p){return matchQ(Q.kit,[p.name,p.id].concat(kitOf(p.id).map(function(a){return a.id+" "+a.serial+" "+a.type})))});
  list=sortBy(list,tid,{name:function(p){return p.name},id:function(p){return p.id},items:function(p){return kitOf(p.id).length}});
  $("#"+tid+" tbody").innerHTML=list.length?list.map(function(p){var k=kitOf(p.id);
    return '<tr class="row" tabindex="0" data-open="person:'+p.id+'"><td>'+avCell(p.name,p.title||"No job title")+'</td><td class="num">'+esc(p.id)+'</td><td>'+esc(p.loc)+'</td><td class="num">'+(k.length?'<b>'+k.length+'</b>':'<span style="color:var(--fg-3)">0</span>')+'</td><td class="wr" style="min-width:320px;font-size:13px">'+(k.length?k.map(function(a){return '<div>'+esc(a.type)+' <span class="mono">'+esc(a.id)+'</span>'+(a.serial?' · <span style="color:var(--fg-3)">'+esc(a.serial)+'</span>':'')+'</div>'}).join(""):'<span style="color:var(--fg-3)">No kit assigned</span>')+'</td><td class="go">'+IC.chev+'</td></tr>'}).join(""):noneRow(6,"Nobody matches.");
}
RENDER["kit-table"]=renderKitTable;
var ACTK={added:"Added",assign:"Assigned",request:"Request",joiner:"Joiner",person:"Person",change:"Change",delete:"Deleted",backup:"Backup"};
var ACF=[["all","All",function(){return true}],["added","Added",function(e){return e.k==="added"}],["assign","Assigned and returned",function(e){return e.k==="assign"}],["request","Requests",function(e){return e.k==="request"}],["joiner","Joiners",function(e){return e.k==="joiner"}],["person","People",function(e){return e.k==="person"}],["change","Changes",function(e){return e.k==="change"||e.k==="delete"||e.k==="backup"}]];
function actHtml(list){return list.map(function(e){return '<div class="tle'+(e.k==="delete"?' note':'')+'"><span class="dot">'+(e.k==="delete"?TL_EDIT:TICK12)+'</span><div class="wh"><b>'+esc(e.t)+'</b><span>'+esc(ACTK[e.k]||"Change")+' · '+esc(e.by)+(e.ref?' · '+esc(e.ref):'')+'</span></div><span class="at">'+esc(e.at)+'</span></div>'}).join("")||'<div class="tle note"><span class="dot">'+TL_EDIT+'</span><div class="wh"><b>Nothing here yet</b><span>Changes appear as soon as they are saved.</span></div><span class="at">—</span></div>'}
function renderActivity(){
  drawPills("#act-tabs",ACF,F.act,S.activity,function(f){F.act=f;renderActivity()});
  var f=ACF.filter(function(x){return x[0]===F.act})[0];
  $("#act-list").innerHTML=actHtml(S.activity.filter(f[2]).slice(0,40));
  $("#home-activity").innerHTML=actHtml(S.activity.slice(0,8));
}
function renderBackups(){
  var tid="backup-table";
  $("#"+tid+" thead").innerHTML=thead(tid,[{l:"File"},{l:"Written",k:"at"},{l:"By"},{l:"Size"},{l:""}]);
  var list=sortBy(S.backups,tid,{at:function(b){return dnum(b.at)}});
  $("#"+tid+" tbody").innerHTML=list.map(function(b){return '<tr class="row" tabindex="0" data-open="backup:'+esc(b.f)+'"><td><div class="cell"><span class="ti n">'+IC.db+'</span><div class="it-main"><b>'+esc(b.f)+'</b><span>data/backups</span></div></div></td><td>'+esc(b.at)+'</td><td class="dim">'+esc(b.by)+'</td><td class="num">'+esc(b.size)+'</td><td class="go">'+IC.chev+'</td></tr>'}).join("");
}
RENDER["backup-table"]=renderBackups;
function renderReportsPage(){
  var withKit=S.people.filter(function(p){return kitOf(p.id).length}).length;
  drawTiles("#rep-tiles",[
    ["#reports","#kit-band",IC.report,withKit+" people hold kit","Who holds what right now, by person."],
    ["#reports","#act-band",IC.log,S.activity.length+" changes logged","Every add, issue, return and setting change."],
    ["#reports","#backup-band",IC.db,S.backups.length+" backups on file","Restore the register from any dated backup."],
    ["#reports","export",IC.download,"Export the register","Every table in one JSON file."]
  ],function(k){if(k==="export"){exportJSON();return}scrollToEl(k)});
  heroMeta("#rep-hero-meta",[withKit+" people with kit",S.activity.length+" changes logged","Last backup "+S.backups[0].at]);
  renderKitTable();renderActivity();renderBackups();
}
function exportJSON(){var data={exported:nowStamp(),people:S.people,assets:S.assets,infrastructure:S.infra,joiners:S.joiners,requests:S.reqs,vendors:S.vendors,activity:S.activity};download("alphax-registry-"+todayISO()+".json",JSON.stringify(data,null,2),"application/json","Register exported as JSON.")}

/* ---------- overview ---------- */
function renderHome(){
  var you=S.reqs.filter(needsYou).length,st=S.assets.filter(function(a){return a.status==="In stock"}).length,jit=S.joiners.filter(function(j){return j.st==="it"}).length,al=alerts();
  drawTiles("#home-tiles",[
    ["#requests","you",IC.clock,you?you+" waiting for you":"Nothing waiting for you","Issue from stock, buy, or hand back."],
    ["#assets","stock",IC.box,st+" in stock","Spares IT can issue without buying."],
    ["#joiners","it",IC.join,jit?jit+" joiner"+(jit===1?"":"s")+" with IT":"No joiners with IT","Record a serial per item, then send the link."],
    ["#home","alerts",IC.warn,plural(al.length,"check")+" to fix","Reused serials, kit on leavers, missing spares."]
  ],function(k,href){
    if(k==="alerts"){scrollToEl("#alerts-band");return}
    if(href==="#requests"){F.req=k;renderReqTable();goTo("requests","#req-tabs")}
    else if(href==="#assets"){F.asset=k;Q.asset="";$("#asset-q").value="";renderAssetTable();goTo("assets","#asset-tabs")}
    else if(href==="#joiners"){F.join=k;renderJoinTable();goTo("joiners","#join-tabs")}
  });
  renderHomeReqs();
  var tid="alert-table";
  $("#"+tid+" thead").innerHTML=thead(tid,[{l:"Check"},{l:"Affects"},{l:"Priority",k:"sev"},{l:""}]);
  var sl=sortBy(al,tid,{sev:function(a){return ["error","warning",""].indexOf(a.sev)}});
  $("#"+tid+" tbody").innerHTML=sl.length?sl.map(function(a){return '<tr class="row'+(a.sev==="error"?' mine-turn':'')+'" tabindex="0" data-open="alert:'+a.id+'"><td class="wr" style="min-width:380px"><div class="cell"><span class="ti n">'+a.icon+'</span><div class="it-main"><b>'+esc(a.title)+'</b><span style="white-space:normal;max-width:none">'+esc(a.desc)+'</span></div></div></td><td class="dim wr" style="min-width:200px">'+esc(a.affects)+'</td><td>'+sevTag(a.sev)+'</td><td class="go">'+IC.chev+'</td></tr>'}).join(""):noneRow(4,"All checks pass. Nothing needs your attention.");
  renderFleet();
}
RENDER["alert-table"]=renderHome;
function renderFleet(){
  var tid="fleet-table";
  $("#"+tid+" thead").innerHTML=thead(tid,[{l:"Device type",k:"type"},{l:"On file",k:"tot"},{l:"Assigned",k:"as"},{l:"In stock",k:"st"},{l:"Returned or in repair"},{l:"Share of the fleet"},{l:""}]);
  var rows=TYPES.map(function(t){var l=S.assets.filter(function(a){return a.type===t&&a.status!=="Retired"});return {type:t,tot:l.length,as:l.filter(function(a){return a.status==="Assigned"}).length,st:l.filter(function(a){return a.status==="In stock"}).length,ot:l.filter(function(a){return a.status==="Returned"||a.status==="In repair"}).length,a:l[0]}}).filter(function(r){return r.tot});
  var all=S.assets.filter(function(a){return a.status!=="Retired"}).length||1;
  rows=SORT[tid]?sortBy(rows,tid,{type:function(r){return r.type},tot:function(r){return r.tot},as:function(r){return r.as},st:function(r){return r.st}}):rows.sort(function(a,b){return b.tot-a.tot});
  $("#"+tid+" tbody").innerHTML=rows.map(function(r){var w=function(n){return (n/all*100).toFixed(2)+"%"};
    return '<tr class="row" tabindex="0" data-open="type:'+r.type+'"><td><div class="cell">'+art(r.type,"",r.a&&r.a.name)+'<div class="it-main"><b>'+esc(r.type)+'</b><span>'+Math.round(r.tot/all*100)+'% of the fleet</span></div></div></td><td class="num"><b>'+r.tot+'</b></td><td class="num">'+r.as+'</td><td class="num">'+(r.st?r.st:'<span style="color:var(--fg-3)">0</span>')+'</td><td class="num">'+(r.ot||'<span style="color:var(--fg-3)">0</span>')+'</td><td style="width:220px"><span class="bar" aria-hidden="true"><i class="a" style="width:'+w(r.as)+'"></i><i class="s" style="width:'+w(r.st)+'"></i><i class="r" style="width:'+w(r.ot)+'"></i></span></td><td class="go">'+IC.chev+'</td></tr>'}).join("");
}
RENDER["fleet-table"]=renderFleet;
function openType(t){F.asset="all";Q.asset=t;$("#asset-q").value=t;renderAssetTable();goTo("assets","#asset-tabs")}

function renderAll(){renderHome();renderReqPage();renderAssetPage();renderPeoplePage();renderJoinPage();renderInfraPage();renderReportsPage();renderSettingsHero();renderNotifs()}
/* search boxes */
[["req-q","req",function(){renderReqTable()}],["asset-q","asset",function(){renderAssetTable()}],["people-q","people",function(){renderPeopleTable()}],["join-q","join",function(){renderJoinTable()}],["infra-q","infra",function(){renderInfraTable()}],["kit-q","kit",function(){renderKitTable()}]].forEach(function(x){$("#"+x[0]).addEventListener("input",function(){Q[x[1]]=this.value.trim();x[2]()})});
