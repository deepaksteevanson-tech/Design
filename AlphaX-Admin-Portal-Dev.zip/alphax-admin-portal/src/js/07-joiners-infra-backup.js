/* =====================================================================
   Popups and actions: new joiners (IT allocation, mark ready, joined), infrastructure, backups and restore
   Concatenated in file-name order by scripts/build.mjs inside one IIFE
   ("use strict"), so every top-level name here is shared with the other files.
   ===================================================================== */

/* ---------- new joiners ---------- */
function chainJoin(j){
  var TICK='<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>';
  var lab={done:"Done",now:"Now",todo:"Next"};
  var st={hr:["now","todo","todo","todo"],mgr:["done","now","todo","todo"],it:["done","done","now","todo"],sign:["done","done","done","now"],joined:["done","done","done","done"]}[j.st];
  var steps=[["1 · HR","Person and position"],["2 · Manager",first(j.mgr)+" picks the kit"],["3 · You","Serial or asset ID"],["4 · Employee","Signs AXAF0726015"]];
  return '<div class="chain" aria-label="Joiner path">'+steps.map(function(x,i){var k=st[i];return '<div class="ch '+k+'"><span class="k"><i>'+(k==="done"?TICK:"")+'</i>'+lab[k]+'</span><b>'+esc(x[0])+'</b><span>'+esc(x[1])+'</span></div>'}).join("")+'</div>';
}
function jNext(j){return {hr:"HR is still adding the position and start date. Then it goes to "+j.mgr+".",mgr:j.mgr+" is choosing the laptop and kit. It reaches you after that.",it:"Record a spare or a serial on every item, then mark it ready. "+first(j.name)+" gets the signing link"+(j.email?" at "+j.email:"")+".",sign:"Waiting for "+first(j.name)+" to sign form AXAF0726015. Then mark them joined.",joined:first(j.name)+" signed the handover and is on People."}[j.st]}
function openJoiner(j){
  if(!j)return;
  var alloc="";
  if(j.st==="it"){
    alloc='<div class="dsub">Kit to record · stock in '+esc(j.loc)+'</div><div class="alloc" id="jalloc">'+j.kit.map(function(k){var t=ITEM_TYPE[k];var sp=stockFor(t,j.loc).slice(0,4);var cur=j.alloc[k]||"";
      return '<div class="ar" data-k="'+k+'"><b>'+esc(ITEM_LABEL[k])+'</b><div><div class="opts">'+sp.map(function(a,i){return '<label class="pill-r"><input type="radio" name="al-'+k+'" value="'+a.id+'"'+((cur===a.id||(!cur&&i===0))?' checked':'')+'><span>'+esc(a.id)+' · '+esc(a.name)+'</span></label>'}).join("")+
        '<label class="pill-r"><input type="radio" name="al-'+k+'" value="__serial"'+(!sp.length||(cur&&cur.indexOf("AST-")!==0)?' checked':'')+'><span>'+(sp.length?"New, type the serial":"No spare · type the serial")+'</span></label></div>'+
        '<input class="a-input" style="margin-top:8px" data-serial="'+k+'" placeholder="Serial of a new '+esc(ITEM_LABEL[k].toLowerCase())+'" value="'+esc(cur&&cur.indexOf("AST-")!==0?cur:"")+'"'+(sp.length&&!(cur&&cur.indexOf("AST-")!==0)?' hidden':'')+'><div class="err-t" data-err="al-'+k+'" hidden style="font-size:12px;color:var(--error);margin-top:6px">Pick a spare or type a serial.</div></div></div>'}).join("")+'</div>';
  }
  var issued=(j.issued||[]).map(function(id){return asset(id)}).filter(Boolean);
  var details=nextStrip(jNext(j))+'<dl class="dl">'+row("Joiner ID",'<code>'+esc(j.id)+'</code>')+(j.emp?row("Employee ID",'<code>'+esc(j.emp)+'</code>'):"")+row("Position",dash(j.pos))+row("Department",dash(j.dept))+row("Manager",esc(j.mgr))+row("Location",esc(j.loc))+row("Works from",esc(j.from)+(j.from==="Office"?' <span style="color:var(--fg-3)">· office desks already have monitors</span>':''))+row("Start date",esc(j.start))+row("Work email",j.email?esc(j.email):'<span style="color:var(--fg-3)">No official email · IT copies the signing link</span>')+
    row("Kit",j.kit.length?j.kit.map(function(k){return '<span class="a-tag">'+esc(ITEM_LABEL[k])+'</span>'}).join(" "):'<span style="color:var(--fg-3)">The manager picks it</span>')+row("Status",jTag(j))+'</dl>'+alloc+
    (issued.length?'<div class="dsub">Issued on the handover</div><div class="klist">'+issued.map(function(a){return '<button type="button" data-k="asset:'+a.id+'">'+aArt(a,"xs")+'<span class="nm"><b>'+esc(a.id)+' · '+esc(a.name)+'</b><span>'+esc(a.serial||"No serial")+'</span></span><span class="go">'+IC.chev+'</span></button>'}).join("")+'</div>':'');
  var fut={hr:[["Manager picks kit",""],["IT records serials",""],["Employee signs","AXAF0726015"]],mgr:[["IT records serials",""],["Employee signs","AXAF0726015"]],it:[["Employee signs","AXAF0726015"],["Joined","On People with their kit"]],sign:[["Joined","On People with their kit"]],joined:[]}[j.st];
  var body='<div class="dhero"><span class="av" style="width:56px;height:56px;font-size:20px">'+initials(j.name)+'</span><div><h4>'+esc(j.name)+'</h4><p>'+esc(j.pos||"Position to confirm")+' · starts '+esc(j.start)+' · '+esc(j.loc)+'</p></div></div>'+chainJoin(j)+tabs([["Details",details],["Timeline",timelineHtml(j.events,fut,j.st==="joined")]]);
  var foot;
  if(j.st==="it")foot='<button class="a-btn a-btn--secondary" type="button" id="jn-edit">'+IC.edit+'Edit</button><span style="flex:1"></span><button class="a-btn a-btn--secondary" type="button" id="jn-msg">'+IC.chat+'Message '+esc(first(j.mgr))+'</button><button class="a-btn a-btn--primary" type="button" id="jn-ready">'+IC.mail+'Mark ready · send signing link</button>';
  else if(j.st==="sign")foot='<button class="a-btn a-btn--secondary" type="button" id="jn-copy">'+IC.copy+'Copy signing link</button><span style="flex:1"></span><button class="a-btn a-btn--primary" type="button" id="jn-join">'+IC.sign+'Signed · mark joined</button>';
  else if(j.st==="joined")foot='<span class="foot-note">'+esc(first(j.name))+' is on People.</span><span style="flex:1"></span><button class="a-btn a-btn--primary" type="button" id="jn-person">'+IC.person+'Open '+esc(first(j.name))+'</button>';
  else foot='<button class="a-btn a-btn--secondary" type="button" id="jn-edit">'+IC.edit+'Edit</button><span style="flex:1"></span><button class="a-btn a-btn--secondary" type="button" id="jn-remind">'+IC.bell+'Remind '+(j.st==="hr"?"HR":esc(first(j.mgr)))+'</button>'+(j.st==="hr"?'<button class="a-btn a-btn--primary" type="button" id="jn-send">'+IC.send+'Send to '+esc(first(j.mgr))+'</button>':'');
  openDrawer('<code>'+esc(j.id)+'</code> New joiner',body,foot);
  bindK($("#dr-body"));
  $$("#jalloc .ar").forEach(function(rw){var k=rw.getAttribute("data-k");$$('input[type=radio]',rw).forEach(function(rb){rb.addEventListener("change",function(){$('[data-serial="'+k+'"]',rw).hidden=rb.value!=="__serial";$('[data-err="al-'+k+'"]',rw).hidden=true})})});
  on("jn-edit",function(){openJoinerForm(j)});
  on("jn-msg",function(){msgTo(j.mgr,"Hi "+first(j.mgr)+", about "+j.name+" ("+j.id+"): ")});
  on("jn-remind",function(){var who=j.st==="hr"?"HR":j.mgr;j.events.push(["Reminder sent",nowStamp(),"IT reminded "+who,"note"]);save();toast("Reminder sent to "+who+".","success");openJoiner(j)});
  on("jn-send",function(){if(!j.pos){toast("Add the position first. Open Edit.","error");return}j.st="mgr";j.events.push(["HR completed",nowStamp(),"Sent to "+j.mgr+" to choose the kit"]);log("joiner",j.id+" ("+j.name+") sent to "+j.mgr,j.id);refresh();openJoiner(j);toast(j.name+" sent to "+j.mgr+".","success")});
  on("jn-copy",function(){var link=S.settings.team+"/handover.html?j="+j.id;try{navigator.clipboard.writeText(link)}catch(e){}toast("Signing link copied: "+link)});
  on("jn-person",function(){if(j.emp)openPerson(j.emp)});
  on("jn-ready",function(){
    var ok=true,picks={};
    $$("#jalloc .ar").forEach(function(rw){var k=rw.getAttribute("data-k");var v=radioVal("al-"+k,rw);var s=$('[data-serial="'+k+'"]',rw).value.trim();var e=$('[data-err="al-'+k+'"]',rw);
      if(v&&v!=="__serial"){picks[k]=v;e.hidden=true}else if(s){var c=serialClash(s);if(c){e.textContent="Already on "+c.id+".";e.hidden=false;ok=false}else{picks[k]=s;e.hidden=true}}else{e.textContent="Pick a spare or type a serial.";e.hidden=false;ok=false}});
    var used={};Object.keys(picks).forEach(function(k){var v=picks[k];if(used[v]){ok=false;toast(v+" is picked twice.","error")}used[v]=1});
    if(!ok)return;
    var emp=nextId("EMP-",S.people.filter(function(x){return /^EMP-\d{4}$/.test(x.id)}));
    S.people.push({id:emp,name:j.name,title:j.pos,dept:j.dept||"",loc:j.loc,mgr:j.mgr,email:j.email,status:"Active",phone:"",joined:j.start,notes:"New joiner "+j.id});
    var ids=[];Object.keys(picks).forEach(function(k){var v=picks[k];var a;
      if(v.indexOf("AST-")===0){a=asset(v)}else{a={id:nextId("AST-",S.assets),type:ITEM_TYPE[k],brand:"",name:ITEM_LABEL[k],model:"",serial:v,loc:j.loc,warranty:"",notes:"Recorded on "+j.id,status:"In stock",holder:"",events:[["Identified as new",nowStamp(),"Serial recorded on "+j.id]]};S.assets.push(a)}
      a.holder=emp;a.status="Assigned";addAssetEvent(a,"Issued to "+j.name,j.id+" · newbee kit, waiting for signature");ids.push(a.id)});
    j.emp=emp;j.issued=ids;j.alloc=picks;j.st="sign";
    j.events.push(["IT ready",nowStamp(),ids.join(", ")+" recorded · signing link emailed"+(j.email?" to "+j.email:"")]);
    log("joiner",j.id+" ("+j.name+") ready · "+ids.join(", ")+" issued · signing link sent",j.id);log("person",emp+" ("+j.name+") added to People",emp);
    refresh();openJoiner(j);toast(j.name+" is ready. Signing link sent.","success");
  });
  on("jn-join",function(){openTModal({tone:"ok",icon:OK_IC,title:"Mark "+j.name+" as joined?",text:"Only after they signed Company Asset & Inventory Acknowledgement Form AXAF0726015. The signed form stays on the record.",yes:"Mark joined",onYes:function(){j.st="joined";j.events.push(["Employee signed",nowStamp(),"AXAF0726015 signed"]);j.events.push(["Joined",nowStamp(),j.emp+" on People"]);log("joiner",j.id+" ("+j.name+") signed AXAF0726015 and joined",j.id);refresh();closeTModal();openJoiner(j);toast(j.name+" has joined.","success")}})});
}
function openJoinerForm(j){
  var edit=!!j;var nid=edit?j.id:nextId("JOIN-",S.joiners);
  var body='<form class="rf" id="jf" novalidate>'+(edit?'':'<div class="rf-note info">'+IC.info.replace('<svg','<svg width="18" height="18"')+'<span>This is the HR step. When you save, it goes to the manager automatically to choose the laptop and kit.</span></div>')+
    '<div class="frow">'+fld("jf-name","Full name",edit?j.name:"",{req:true,err:"Type the full name."})+fld("jf-id","Joiner ID",nid,{ro:true})+'</div>'+
    '<div class="frow">'+fld("jf-pos","Position",edit?j.pos:"",{req:true,err:"Add the position."})+fld("jf-dept","Department / team",edit?j.dept:"",{ph:"Development, Account, Business, Legal, Management office or IT"})+'</div>'+
    radioField("jf-mgr","Manager",MANAGERS,edit?j.mgr:"",true)+radioField("jf-loc","Location",["Dubai","Uganda"],edit?j.loc:"Dubai",true)+radioField("jf-from","Works from",["Office","Home"],edit?j.from:"Office",true)+
    (edit&&(j.st==="mgr"||j.st==="it")?'<div><div class="rf-q">Kit</div><div class="pills">'+ITEMS.slice(0,7).map(function(it){return '<label class="radio-r sq"><input type="checkbox" name="jf-kit" value="'+it[0]+'"'+(j.kit.indexOf(it[0])!==-1?' checked':'')+'><i></i><span>'+esc(it[1])+'</span></label>'}).join("")+'</div></div>':'')+
    '<div class="frow">'+fld("jf-start","Start date",edit?isoOf(j.start):"",{type:"date",req:true,err:"Pick the start date."})+fld("jf-email","Work email",edit?j.email:"",{opt:true,ph:"Leave blank if they have no official email",err:"Use an @alphax.ae address."})+'</div></form>';
  openDrawer(edit?'Edit <code>'+j.id+'</code>':'HR: add newbee',body,'<button class="a-btn a-btn--secondary" type="button" id="jf-cancel">'+(edit?'Back':'Cancel')+'</button><span style="flex:1"></span><button class="a-btn a-btn--primary" type="button" id="jf-save">'+(edit?'Save changes':IC.send+'Send to manager')+'</button>');
  on("jf-cancel",function(){if(edit)openJoiner(j);else closeDrawer()});
  on("jf-save",function(){
    var f=$("#jf");var name=$("#jf-name").value.trim(),pos=$("#jf-pos").value.trim(),mgr=radioVal("jf-mgr",f),loc=radioVal("jf-loc",f),from=radioVal("jf-from",f),start=$("#jf-start").value,email=$("#jf-email").value.trim().toLowerCase();
    var ok=formErr("jf-name",!name)&formErr("jf-pos",!pos)&formErr("jf-mgr",!mgr)&formErr("jf-loc",!loc)&formErr("jf-from",!from)&formErr("jf-start",!start)&formErr("jf-email",!!email&&!/@alphax\.ae$/.test(email));
    if(!ok){var e=$('.err-t:not([hidden])',f);if(e)e.scrollIntoView({behavior:"smooth",block:"center"});return}
    var v={name:name,pos:pos,dept:$("#jf-dept").value.trim(),mgr:mgr,loc:loc,from:from,start:fmtISO(start),email:email};
    if(edit){Object.keys(v).forEach(function(k){j[k]=v[k]});var kit=$$('input[name="jf-kit"]:checked',f).map(function(c){return c.value});if($$('input[name="jf-kit"]',f).length)j.kit=kit;j.events.push(["Updated",nowStamp(),"Edited by "+ME.name,"note"]);log("joiner",j.id+" ("+j.name+") updated",j.id);refresh();openJoiner(j);toast(j.id+" saved.","success")}
    else{var n={id:nid,kit:[],st:"mgr",alloc:{},events:[["Added by HR",nowStamp(),"Added by "+ME.name+" on behalf of HR"],["HR completed",nowStamp(),"Sent to "+mgr+" to choose the kit"]]};Object.keys(v).forEach(function(k){n[k]=v[k]});S.joiners.push(n);log("joiner",nid+" ("+name+") added · sent to "+mgr,nid);refresh();openJoiner(n);toast(name+" sent to "+mgr+".","success")}
  });
}
$$('[data-act="add-joiner"]').forEach(function(b){b.addEventListener("click",function(){openJoinerForm(null)})});

/* ---------- infrastructure ---------- */
function openInfra(id){
  var x=infraById(id);if(!x)return;
  var inside=S.infra.filter(function(y){return y.site===x.name});
  var details='<dl class="dl">'+row("ID",'<code>'+esc(x.id)+'</code>')+row("Type",esc(x.type))+row("Site",dash(x.site))+row("Office",esc(x.city))+row("Hostname",dash(x.host))+row("IP",x.ip?'<code>'+esc(x.ip)+'</code>':dash(""))+row("Status",iTag(x))+row("Owner",dash(x.owner))+row("Notes",dash(x.notes))+'</dl>'+
    (inside.length?'<div class="dsub">Inside '+esc(x.name)+'</div><div class="klist">'+inside.map(function(y){return '<button type="button" data-inf="'+y.id+'"><span class="ti n">'+(INF_IC[y.type]||IC.room)+'</span><span class="nm"><b>'+esc(y.name)+'</b><span>'+esc(y.id)+' · '+esc(y.type)+'</span></span><span class="go">'+IC.chev+'</span></button>'}).join("")+'</div>':'');
  var ev=[["Added to the register","9 Oct 2026 · 10:20","Imported from the office plan"]].concat(S.activity.filter(function(e){return e.ref===x.id}).reverse().map(function(e){return [e.t,e.at,e.by]}));
  var body='<div class="dhero"><span class="ti n" style="width:56px;height:56px;border-radius:16px">'+(INF_IC[x.type]||IC.room)+'</span><div><h4>'+esc(x.name)+'</h4><p>'+esc(x.type)+' · '+esc(x.site||x.city)+'</p></div></div>'+tabs([["Details",details],["Timeline",timelineHtml(ev,[],true)]]);
  openDrawer('<code>'+esc(x.id)+'</code> Infrastructure',body,(CAN_DELETE?'<button class="a-btn a-btn--secondary" type="button" id="dr-del">'+IC.trash+'Delete</button>':'')+'<span style="flex:1"></span><button class="a-btn a-btn--primary" type="button" id="in-edit">'+IC.edit+'Edit</button>');
  $$("[data-inf]").forEach(function(b){b.addEventListener("click",function(){openInfra(b.getAttribute("data-inf"))})});
  on("in-edit",function(){openInfraForm(x)});
  on("dr-del",function(){if(inside.length){toast("Move or delete the "+plural(inside.length,"record")+" inside "+x.name+" first.","error");return}confirmDelete("infra",x.id,x.name,function(){S.infra=S.infra.filter(function(y){return y.id!==x.id})})});
}
function openInfraForm(x){
  var edit=!!x;var nid=edit?x.id:nextId("INF-",S.infra);
  var sites=S.infra.filter(function(y){return y.type==="Office"||y.type==="Floor"||(y.type==="Room"&&/Command Center$/.test(y.name))}).map(function(y){return y.name});
  var body='<form class="rf" id="if" novalidate><div class="frow">'+fld("if-name","Name",edit?x.name:"",{req:true,ph:"e.g. Cabin M-9, 1st Floor or Office Wi-Fi",err:"Add a name."})+fld("if-id","ID",nid,{ro:true})+'</div>'+
    radioField("if-type","Type",["Office","Floor","Room","Network","Wi-Fi","Server","Circuit"],edit?x.type:"",true)+
    radioField("if-site","Site",["None"].concat(sites),edit?(x.site||"None"):"",true)+
    radioField("if-city","Office",["Dubai","Uganda"],edit?x.city:"Dubai",true)+
    '<div class="frow">'+fld("if-host","Hostname",edit?x.host:"",{opt:true})+fld("if-ip","IP",edit?x.ip:"",{opt:true,ph:"e.g. 10.0.1.20",err:"Use an IPv4 address like 10.0.1.20."})+'</div>'+
    radioField("if-status","Status",["In service","Planned","Down"],edit?x.status:"In service",true)+
    '<div class="frow">'+fld("if-owner","Owner",edit?x.owner:"IT Support")+'<div></div></div>'+fld("if-notes","Notes",edit?x.notes:"",{area:true,opt:true})+'</form>';
  openDrawer(edit?'Edit <code>'+x.id+'</code>':'Add infrastructure',body,'<button class="a-btn a-btn--secondary" type="button" id="if-cancel">'+(edit?'Back':'Cancel')+'</button><span style="flex:1"></span><button class="a-btn a-btn--primary" type="button" id="if-save">'+(edit?'Save changes':IC.plus+'Add infrastructure')+'</button>');
  on("if-cancel",function(){if(edit)openInfra(x.id);else closeDrawer()});
  on("if-save",function(){var f=$("#if");var name=$("#if-name").value.trim(),type=radioVal("if-type",f),site=radioVal("if-site",f),city=radioVal("if-city",f),status=radioVal("if-status",f),ip=$("#if-ip").value.trim();
    var ok=formErr("if-name",!name)&formErr("if-type",!type)&formErr("if-site",!site)&formErr("if-city",!city)&formErr("if-status",!status)&formErr("if-ip",!!ip&&!/^\d{1,3}(\.\d{1,3}){3}$/.test(ip));
    if(!ok){var e=$('.err-t:not([hidden])',f);if(e)e.scrollIntoView({behavior:"smooth",block:"center"});return}
    var v={name:name,type:type,site:site==="None"?"":site,city:city,host:$("#if-host").value.trim(),ip:ip,status:status,owner:$("#if-owner").value.trim(),notes:$("#if-notes").value.trim()};
    if(edit){Object.keys(v).forEach(function(k){x[k]=v[k]});log("change",x.id+" ("+x.name+") updated",x.id);refresh();openInfra(x.id);toast(x.id+" saved.","success")}
    else{var n={id:nid};Object.keys(v).forEach(function(k){n[k]=v[k]});S.infra.push(n);log("added",nid+" ("+name+") added to infrastructure",nid);refresh();openInfra(nid);toast(name+" added.","success")}
  });
}
$$('[data-act="add-infra"]').forEach(function(b){b.addEventListener("click",function(){openInfraForm(null)})});

/* ---------- backups ---------- */
(function(){
  var h=$("#backup-band .band-h");
  var acts=document.createElement("div");acts.className="acts";
  acts.innerHTML='<button class="a-btn a-btn--ghost a-btn--md" type="button" id="bk-reset">Reset demo data</button><label class="a-btn a-btn--secondary a-btn--md" style="position:relative;overflow:hidden">'+IC.upload+'Restore from file<input type="file" id="bk-file" accept=".json,application/json" style="position:absolute;inset:0;opacity:0;cursor:pointer"></label><button class="a-btn a-btn--primary a-btn--md kit-req" type="button" id="bk-now">Back up now '+IC.download+'</button>';
  h.appendChild(acts);
})();
function backupNow(){var d=new Date();var f="registry-"+todayISO()+"-"+String(d.getHours()).padStart(2,"0")+String(d.getMinutes()).padStart(2,"0")+".json";var data=JSON.stringify(S);
  S.backups.unshift({f:f,at:nowStamp(),by:"Downloaded by "+first(ME.name),size:Math.max(1,Math.round(data.length/1024))+" KB"});log("backup","Backup "+f+" written and downloaded");save();download(f,data,"application/json","Backup "+f+" saved.");renderAll()}
on("bk-now",backupNow);
on("bk-reset",function(){openTModal({title:"Reset the demo data?",text:"Every change you made in this preview goes back to the register as it was on 26 Oct 2026, 09:26. This only affects this browser.",yes:"Reset",onYes:function(){S=seed();store("ax-admin-notifs",null);save();renderAll();closeTModal();toast("Demo data reset.")}})});
$("#bk-file").addEventListener("change",function(){var fi=this.files&&this.files[0];this.value="";if(!fi)return;var rd=new FileReader();rd.onload=function(){var d;try{d=JSON.parse(rd.result)}catch(e){toast("That file is not a register backup.","error");return}
  if(!d||!d.people||!d.assets){toast("That file is not a register backup.","error");return}
  openTModal({title:"Restore from "+fi.name+"?",text:"The register is replaced with "+plural(d.people.length,"person","people")+" and "+plural(d.assets.length,"asset")+" from this file. A backup of the current register is written first.",yes:"Restore",onYes:function(){var keep=S.backups;var n=seed();Object.keys(n).forEach(function(k){if(d[k]!==undefined)n[k]=d[k]});if(d.infrastructure)n.infra=d.infrastructure;if(d.requests)n.reqs=d.requests;S=n;S.backups=[{f:"before-restore-"+todayISO()+".json",at:nowStamp(),by:"Automatic before restore",size:"—"}].concat(keep);log("backup","Register restored from "+fi.name);save();renderAll();closeTModal();toast("Register restored from "+fi.name+".","success")}})};rd.readAsText(fi)});
function openBackup(f){var b=S.backups.filter(function(x){return x.f===f})[0];if(!b)return;
  var body='<div class="dhero"><span class="ti n" style="width:56px;height:56px;border-radius:16px">'+IC.db+'</span><div><h4>'+esc(b.f)+'</h4><p>data/backups · '+esc(b.size)+'</p></div></div><dl class="dl">'+row("Written",esc(b.at))+row("By",esc(b.by))+row("Size",esc(b.size))+row("Holds","People, assets, infrastructure, joiners, requests, vendors and the activity log")+'</dl>'+nextStrip("To restore on the server, replace data/registry.json with this file and keep the app running. Here, Restore replaces the preview data.");
  openDrawer('Backup',body,'<span style="flex:1"></span><button class="a-btn a-btn--secondary" type="button" id="bk-dl">'+IC.download+'Download</button><button class="a-btn a-btn--primary" type="button" id="bk-rs">Restore this backup</button>');
  on("bk-dl",function(){download(b.f,JSON.stringify(S),"application/json",b.f+" saved.")});
  on("bk-rs",function(){openTModal({title:"Restore "+b.f+"?",text:"Only Ultimate IT can restore. In this preview the register goes back to "+b.at+" on the live server.",yes:"Restore",onYes:function(){log("backup","Restore requested from "+b.f);save();renderAll();closeTModal();closeDrawer();toast("Restore of "+b.f+" queued on the server.")}})});
}
