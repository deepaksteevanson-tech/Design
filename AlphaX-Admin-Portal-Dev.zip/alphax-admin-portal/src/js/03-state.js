/* =====================================================================
   State: item and type dictionaries, seed() for requests, joiners, activity, vendors, settings, backups; persistence (localStorage "ax-admin-v1"); lookups; request status model (RST)
   Concatenated in file-name order by scripts/build.mjs inside one IIFE
   ("use strict"), so every top-level name here is shared with the other files.
   ===================================================================== */

/* ---------- the register (seeded from the live register, 26 Oct 2026 09:26; sample requests marked in the footer) ---------- */
var ITEMS=[["laptop","Laptop"],["keyboard","Keyboard"],["mouse","Mouse"],["monitor","Monitor"],["headset","Headset"],["webcam","Webcam"],["dock","Dock / hub"],["usb","USB"],["hdd","Hard drive"],["tablet","Tablet"],["phone","Phone"],["other","Other peripheral"]];
var ITEM_LABEL={};ITEMS.forEach(function(i){ITEM_LABEL[i[0]]=i[1]});
var ITEM_TYPE={laptop:"Laptop",keyboard:"Keyboard",mouse:"Mouse",monitor:"Monitor",headset:"Headset",webcam:"Webcam",dock:"Accessory",usb:"Accessory",hdd:"Storage",tablet:"Tablet",phone:"Phone",other:"Other"};
var TYPES=["Laptop","Monitor","Keyboard","Mouse","Tablet","Phone","Headset","Webcam","Accessory","Storage","Other"];
var KIND={kit:"New kit",replacement:"Replacement",service:"Service"};

function seed(){
  var people=PEOPLE0.map(function(p){return {id:p[0],name:p[1],title:p[2],dept:p[3],loc:p[4],mgr:p[5],email:p[6],status:p[7],phone:p[1]==="Maher Al-Bunni"?"+971 52 472 3329":"",joined:"",notes:""}});
  var byId={};people.forEach(function(p){byId[p.id]=p});
  var assets=ASSETS0.map(function(a){var h=byId[a[1]];return {id:a[0],holder:a[1]||"",type:a[2],brand:a[3],name:a[4],model:a[5],serial:a[6],status:a[7],loc:h?h.loc:"Dubai",warranty:"",notes:a[7]==="In stock"?(a[4].indexOf("sealed")!==-1?"Sealed pack":"Spare, not in use"):"",events:null}});
  var infra=INFRA0.map(function(r){return {id:r[0],name:r[1],type:r[2],site:r[3],host:r[4],ip:r[5],status:r[6],owner:r[7],city:"Dubai",notes:""}});
  var reqs=[
    {id:"REQ-0122",who:"Rafsal KK",emp:"EMP-019",kind:"replacement",items:["laptop"],ref:"Apple MacBook Pro 14-inch, M4 Pro, 24 GB",reason:"Current laptop takes several minutes to build the design system and runs out of memory with Figma and the dev server open.",files:["build-time-log.png"],cost:"AED 8,999",needBy:"10 Nov 2026",date:"25 Oct 2026",office:"Dubai",mgr:"Jerrin Varghese",st:"mgr",sample:true,
     events:[["Request sent","25 Oct 2026 · 16:20","To IT, CC Jerrin Varghese for approval"]]},
    {id:"REQ-0121",who:"Megha Mohan",emp:"EMP-030",kind:"kit",items:["monitor","dock"],ref:"Dell U2723QE + Dell WD19S dock",reason:"Second screen for reviewing app screens side by side with Figma at the office desk.",files:["dell-quote.pdf"],cost:"AED 2,890",needBy:"3 Nov 2026",date:"24 Oct 2026",office:"Dubai",mgr:"Jerrin Varghese",st:"mgr",sample:true,
     events:[["Request sent","24 Oct 2026 · 10:05","To IT, CC Jerrin Varghese for approval"]]},
    {id:"REQ-0120",who:"Susana Zapata",emp:"EMP-0047",kind:"kit",items:["monitor"],ref:"Any 24 to 27-inch monitor",reason:"Joined on 19 Oct with a laptop only. Needs a second screen for dashboards at the Dubai office desk.",files:[],cost:"From stock",needBy:"30 Oct 2026",date:"23 Oct 2026",office:"Dubai",mgr:"Mike Karavidas",st:"you",sample:true,
     events:[["Request sent","23 Oct 2026 · 11:40","To IT, CC Mike Karavidas"],["Manager approved","23 Oct 2026 · 15:02","Mike Karavidas tapped Approve in the email"]]},
    {id:"REQ-0119",who:"Sambrit Bidari",emp:"EMP-008",kind:"kit",items:["headset"],ref:"Jabra Evolve2 40",reason:"Daily calls with the Uganda team. The open office is too loud without a headset.",files:[],cost:"AED 420",needBy:"—",date:"23 Oct 2026",office:"Dubai",mgr:"Jerrin Varghese",st:"mgr",sample:true,
     events:[["Request sent","23 Oct 2026 · 09:41","To IT, CC Jerrin Varghese for approval"]]},
    {id:"REQ-0118",who:"Jerrin Varghese",emp:"EMP-017",kind:"kit",items:["headset"],ref:"Jabra Evolve2 40",reason:"Daily client calls from the Dubai office desk.",files:[],cost:"AED 420",needBy:"—",date:"22 Oct 2026",office:"Dubai",mgr:"Anna Chatziioannou",st:"you",sample:true,
     events:[["Request sent","22 Oct 2026 · 09:14","To IT, CC Anna Chatziioannou"],["Manager approved","22 Oct 2026 · 11:02","Anna Chatziioannou tapped Approve in the email"],["In review","22 Oct 2026 · 14:30","IT is checking unassigned stock in Dubai"]]},
    {id:"REQ-0116",who:"Mohammed Nafih",emp:"EMP-014",kind:"kit",items:["keyboard","mouse"],ref:"Logitech MX Keys S + MX Master 3S",reason:"Ergonomic set for long research write-ups. Current keyboard is shared.",files:[],cost:"AED 760",needBy:"—",date:"20 Oct 2026",office:"Dubai",mgr:"Jerrin Varghese",st:"you",sample:true,
     events:[["Request sent","20 Oct 2026 · 11:12","To IT, CC Jerrin Varghese for approval"],["Manager approved","21 Oct 2026 · 09:30","Jerrin Varghese approved and sent it to Admin"]]},
    {id:"REQ-0115",who:"Jerrin Varghese",emp:"EMP-017",kind:"service",assetId:"AST-0046",items:["tablet"],title:"Service · Mi Tab",issue:"Battery / charging",ref:"",reason:"Battery drops from full to 20% in under two hours, and it gets warm while charging.",files:["battery-health.png"],cost:"Under warranty",needBy:"—",date:"18 Oct 2026",office:"Dubai",mgr:null,st:"repair",sample:true,
     events:[["Request sent","18 Oct 2026 · 10:05","Service request sent to IT"],["In review","18 Oct 2026 · 15:20","IT confirmed battery health at 71%"],["In repair","20 Oct 2026 · 11:00","Sent to Xiaomi service centre, Dubai · ETA 28 Oct"]]},
    {id:"REQ-0114",who:"Rao Iqbal",emp:"EMP-016",kind:"kit",items:["webcam"],ref:"Logitech Brio 500",reason:"Client demos from the meeting room need a clearer camera.",files:["brio-500-quote.pdf"],cost:"AED 450",needBy:"28 Oct 2026",date:"12 Oct 2026",office:"Dubai",mgr:"Spiros Pilafas",st:"delivery",sample:true,vendor:"Jumbo Electronics",
     events:[["Request sent","12 Oct 2026 · 10:10","To IT, CC Spiros Pilafas"],["Manager approved","12 Oct 2026 · 12:44","Spiros Pilafas tapped Approve in the email"],["Sent to Procurement","13 Oct 2026 · 09:05","No webcam in stock in Dubai · To ymohamad@alphax.ae"],["Quotations uploaded","15 Oct 2026 · 14:20","Yahia uploaded 2 quotations (Jumbo, noon)"],["CEO approved","16 Oct 2026 · 09:12","Waleed Al Aryan sealed the Jumbo quotation"],["Paid","19 Oct 2026 · 11:30","Sabareesh Kumar recorded payment · PO-2026-041"],["Waiting for delivery","19 Oct 2026 · 11:31","Courier Aramex · expected 28 Oct"]]},
    {id:"REQ-0113",who:"Saeed Mohammad",emp:"EMP-020",kind:"kit",items:["keyboard","mouse"],ref:"Logitech MK470 combo",reason:"Works from the Kampala office. Laptop keyboard only, long reports every week.",files:[],cost:"UGX 310,000",needBy:"—",date:"10 Oct 2026",office:"Uganda",mgr:"Spiros Pilafas",st:"pay",sample:true,vendor:"Local supplier, Kampala",
     events:[["Request sent","10 Oct 2026 · 08:55","To IT, CC Spiros Pilafas"],["Manager approved","10 Oct 2026 · 10:02","Spiros Pilafas tapped Approve in the email"],["Sent to Procurement","11 Oct 2026 · 09:40","No keyboard or mouse in stock in Uganda"],["Quotations uploaded","14 Oct 2026 · 13:15","Yahia uploaded 1 quotation"],["CEO approved","20 Oct 2026 · 16:45","Waleed Al Aryan sealed the quotation"],["Waiting for payment","20 Oct 2026 · 16:46","With Finance (skumar@alphax.ae)"]]},
    {id:"REQ-0112",who:"Oumaima Jbeli",emp:"EMP-032",kind:"kit",items:["monitor"],ref:"LG UltraFine 27-inch 5K",reason:"Colour-accurate screen for brand and print work.",files:["lg-ultrafine-spec.pdf"],cost:"AED 5,200",needBy:"31 Oct 2026",date:"15 Oct 2026",office:"Dubai",mgr:"Jerrin Varghese",st:"proc",sample:true,
     events:[["Request sent","15 Oct 2026 · 14:02","To IT, CC Jerrin Varghese for approval"],["Manager approved","15 Oct 2026 · 16:40","Jerrin Varghese approved and sent it to Admin"],["Approved by Admin","17 Oct 2026 · 10:15","No 5K monitor in stock · sent to Procurement"],["With procurement","17 Oct 2026 · 10:16","Yahia is collecting quotations"]]},
    {id:"REQ-0111",who:"Jerrin Varghese",emp:"EMP-017",kind:"kit",items:["monitor","dock"],ref:"Dell U2723QE + WD19S dock",reason:"Second screen for design system QA at the office desk.",files:["dell-u2723qe-quote.pdf"],cost:"AED 2,890",needBy:"—",date:"15 Oct 2026",office:"Dubai",mgr:"Anna Chatziioannou",st:"ceo",sample:true,
     events:[["Request sent","15 Oct 2026 · 10:41","To IT, CC Anna Chatziioannou"],["Manager approved","15 Oct 2026 · 12:05","Anna Chatziioannou tapped Approve in the email"],["Sent to Procurement","16 Oct 2026 · 09:26","No spare 27-inch monitor with a dock in Dubai"],["Quotations uploaded","17 Oct 2026 · 15:48","Yahia uploaded 2 quotations (Jumbo, noon)"],["Waiting for CEO approval","20 Oct 2026 · 08:55","Comparison sheet emailed to CEO Waleed with Approve"]]},
    {id:"REQ-0108",who:"Saba Mohamad",emp:"EMP-028",kind:"kit",items:["webcam"],ref:"Logitech Brio 500",reason:"Better picture on client calls.",files:[],cost:"AED 450",needBy:"—",date:"9 Oct 2026",office:"Dubai",mgr:"Jerrin Varghese",st:"declined",sample:true,
     events:[["Request sent","9 Oct 2026 · 12:30","To IT, CC Jerrin Varghese for approval"],["Declined by manager","9 Oct 2026 · 15:05","Already available in the team · Use the meeting-room camera for client calls"]]},
    {id:"REQ-0105",who:"Rafsal KK",emp:"EMP-019",kind:"kit",items:["monitor"],ref:"Dell monitor",reason:"Second screen for the IT desk.",files:[],cost:"From stock",needBy:"—",date:"6 Oct 2026",office:"Dubai",mgr:"Spiros Pilafas",st:"done",fromStock:true,issued:["AST-0054"],sample:true,
     events:[["Request sent","6 Oct 2026 · 09:00","To IT, CC Spiros Pilafas"],["Manager approved","6 Oct 2026 · 09:40","Spiros Pilafas tapped Approve in the email"],["Issued from stock","6 Oct 2026 · 11:15","AST-0054 Dell Monitor issued to Rafsal KK"]]},
    {id:"REQ-0104",who:"Jay Riche",emp:"EMP-0038",kind:"kit",items:["tablet"],ref:"iPad Air 11-inch",reason:"For reading documents at home.",files:[],cost:"AED 2,599",needBy:"—",date:"2 Oct 2026",office:"Dubai",mgr:"Anna Chatziioannou",st:"notvalid",sample:true,
     events:[["Request sent","2 Oct 2026 · 13:20","To IT, CC Anna Chatziioannou"],["Manager approved","2 Oct 2026 · 16:00","Anna Chatziioannou tapped Approve in the email"],["Not valid","3 Oct 2026 · 09:10","Not a business need · Personal reading device"]]},
    {id:"REQ-0009",who:"Iyad Al Sharif",emp:"EMP-0037",kind:"kit",items:["other"],other:"Test devices for product delivery",ref:"",reason:"Need those devices for testing the products that we gonna deliver",files:[],cost:"—",needBy:"—",date:"24 Oct 2026",office:"Dubai",mgr:null,st:"you",
     events:[["Request sent","24 Oct 2026 · 13:05","To IT · REQ-0009 on the live register"],["In review","24 Oct 2026 · 15:30","No matching stock · send to Procurement"]]}
  ];
  var joiners=[
    {id:"JOIN-0001",name:"Muhammad Jamil",pos:"Full Stack Developer",dept:"Development",mgr:"Mike Karavidas",loc:"Dubai",from:"Office",start:"7 Oct 2026",email:"mjamil@alphax.ae",kit:["laptop","keyboard"],st:"mgr",alloc:{},
     events:[["Added by HR","9 Oct 2026 · 10:02","Person and position recorded"],["HR completed","9 Oct 2026 · 10:08","Sent to Mike Karavidas to choose the kit"]]},
    {id:"JOIN-0002",name:"Amira Boukhemkham",pos:"Business Development Director",dept:"Business",mgr:"Waleed Al Aryan",loc:"Dubai",from:"Office",start:"23 Oct 2026",email:"ab@alphax.ae",kit:["laptop","keyboard","mouse"],st:"it",alloc:{},
     events:[["Added by HR","23 Oct 2026 · 17:25","Person and position recorded"],["HR completed","23 Oct 2026 · 17:31","Sent to Waleed Al Aryan to choose the kit"],["Updated","23 Oct 2026 · 17:35","Work email added"],["Manager completed","26 Oct 2026 · 09:20","Laptop, keyboard and mouse · moved to With IT"]]},
    {id:"JOIN-0003",name:"Layla Haddad",pos:"Marketing Executive",dept:"Business",mgr:"Anna Chatziioannou",loc:"Dubai",from:"Office",start:"9 Nov 2026",email:"",kit:[],st:"hr",alloc:{},sample:true,
     events:[["Added by HR","26 Oct 2026 · 08:50","Person recorded · position and start date still to confirm"]]}
  ];
  var A=function(k,t,at,ref,by){return {k:k,t:t,at:at,ref:ref||"",by:by||"Deepak Steevanson"}};
  var activity=[
    A("added","AST-0085 (Apple Neo 13inc/8GB/256GB) added to the register · unassigned / in stock","26 Oct 2026 · 09:26","AST-0085"),
    A("joiner","Amira Boukhemkham moved to With IT","26 Oct 2026 · 09:20","JOIN-0002","Waleed Al Aryan"),
    A("joiner","JOIN-0002 (Amira Boukhemkham) updated","23 Oct 2026 · 17:35","JOIN-0002","Sarah A"),
    A("joiner","JOIN-0002 (Amira Boukhemkham) · HR completed, sent to Waleed Al Aryan","23 Oct 2026 · 17:31","JOIN-0002","Sarah A"),
    A("request","REQ-0111 comparison sheet emailed to CEO Waleed","20 Oct 2026 · 08:55","REQ-0111","Yahia Mohamad"),
    A("added","AST-0084 (Mac laptop) added to the register · assigned to Susana Zapata","19 Oct 2026 · 10:10","AST-0084"),
    A("person","EMP-0047 (Susana Zapata) added to People","19 Oct 2026 · 09:45","EMP-0047"),
    A("change","Pointed the Procurement inbox at ymohamad@alphax.ae and the Finance inbox at skumar@alphax.ae","19 Oct 2026 · 09:32"),
    A("request","REQ-0112 approved by Admin · sent to Procurement","17 Oct 2026 · 10:15","REQ-0112"),
    A("person","EMP-0046 (Vishakha Heralal) added to People","9 Oct 2026 · 12:14","EMP-0046"),
    A("person","Restored Noor Imad Abu Zahieh as Exited (4 Aug 2026)","9 Oct 2026 · 11:45","EMP-027"),
    A("change","Restored exited people from a previous save: Noor Imad Abu Zahieh (EMP-027)","9 Oct 2026 · 11:42"),
    A("person","EMP-006 (Lama Abu-Muhanna) updated","9 Oct 2026 · 11:33","EMP-006"),
    A("person","Waleed Al Aryan recorded as CEO of Alpha X","9 Oct 2026 · 11:32","EMP-0044"),
    A("person","EMP-0044 (Waleed Al Aryan) updated","9 Oct 2026 · 11:25","EMP-0044"),
    A("change","Added Maher Al-Bunni contact number +971 52 472 3329","9 Oct 2026 · 10:52","EMP-015"),
    A("change","Pointed manager aliases and notice inboxes at official directory emails","9 Oct 2026 · 10:22"),
    A("change","Updated people names and work emails from the Alpha X directory","9 Oct 2026 · 10:20"),
    A("joiner","JOIN-0001 (Muhammad Jamil) · HR completed, sent to Mike Karavidas","9 Oct 2026 · 10:08","JOIN-0001","Sarah A"),
    A("assign","AST-0054 (Dell Monitor) issued to Rafsal KK from stock · REQ-0105","6 Oct 2026 · 11:15","AST-0054")
  ];
  var vendors=[
    {id:"VEN-001",name:"Jumbo Electronics",pay:"Account transfer",payTo:"Account details held by Finance",notes:"Dubai stores. Delivers to the office in 2 to 3 days.",sample:true},
    {id:"VEN-002",name:"noon",pay:"Payment link",payTo:"noon Business checkout link per order",notes:"Fast for peripherals. Keep the invoice PDF on the request.",sample:true}
  ];
  var settings={
    team:"https://inventory.alphaxdev.online",
    inbox:{hr:"hr@alphax.ae, legal@alphax.ae",it:"it@alphax.ae, dsteevanson@alphax.ae",proc:"ymohamad@alphax.ae",fin:"skumar@alphax.ae",ceo:"waleed@alphax.ae",anna:"ac@alphax.ae",mike:"mk@alphax.ae",spiros:"sp@alphax.ae"},
    smtp:{host:"",port:"587",login:"",sendAs:"AlphaX IT Register <it@alphax.ae>",saved:false},
    google:"",
    desks:{"Deepak Steevanson":"IT · Ultimate","Rafsal KK":"IT","Waleed Al Aryan":"CEO","Sarah A":"HR","Yahia Mohamad":"Procurement","Sabareesh Kumar":"Finance","Anna Chatziioannou":"Manager","Mike Karavidas":"Manager","Spiros Pilafas":"Manager","Jerrin Varghese":"Manager"}
  };
  var backups=[
    {f:"registry-2026-10-26-0926.json",at:"26 Oct 2026 · 09:26",by:"Automatic after save",size:"412 KB"},
    {f:"registry-2026-10-23-1735.json",at:"23 Oct 2026 · 17:35",by:"Automatic after save",size:"409 KB"},
    {f:"registry-2026-10-19-1010.json",at:"19 Oct 2026 · 10:10",by:"Automatic after save",size:"406 KB"},
    {f:"registry-2026-10-09-1214.json",at:"9 Oct 2026 · 12:14",by:"Downloaded by Deepak",size:"398 KB"}
  ];
  return {v:1,people:people,assets:assets,infra:infra,reqs:reqs,joiners:joiners,activity:activity,vendors:vendors,settings:settings,backups:backups,saved:"26 Oct 2026 · 09:26"};
}
var KEY="ax-admin-v1";
var S=store(KEY);
if(!S||S.v!==1)S=seed();
function save(){S.saved=nowStamp();store(KEY,S);var f=$("#foot-saved");if(f)f.textContent=S.saved.replace(" · ",", ")}
function log(k,t,ref){S.activity.unshift({k:k,t:t,at:nowStamp(),ref:ref||"",by:ME.name})}

/* ---------- lookups ---------- */
function person(id){return S.people.filter(function(p){return p.id===id})[0]}
function personByName(n){return S.people.filter(function(p){return p.name===n})[0]}
function asset(id){return S.assets.filter(function(a){return a.id===id})[0]}
function req(id){return S.reqs.filter(function(r){return r.id===id})[0]}
function joiner(id){return S.joiners.filter(function(j){return j.id===id})[0]}
function infraById(id){return S.infra.filter(function(x){return x.id===id})[0]}
function holderName(a){var p=a.holder?person(a.holder):null;return p?p.name:""}
function kitOf(pid){return S.assets.filter(function(a){return a.holder===pid&&(a.status==="Assigned"||a.status==="In repair")})}
function nextId(prefix,list,pad){var mx=0;list.forEach(function(x){var m=String(x.id).match(/(\d+)$/);if(m&&String(x.id).indexOf(prefix)===0)mx=Math.max(mx,+m[1])});return prefix+String(mx+1).padStart(pad||4,"0")}
function stockFor(type,office){return S.assets.filter(function(a){return a.status==="In stock"&&a.type===type&&(!office||a.loc===office)})}
function serialClash(serial,exceptId){var s=String(serial||"").trim().toUpperCase();if(!s)return null;return S.assets.filter(function(a){return a.id!==exceptId&&String(a.serial||"").trim().toUpperCase()===s})[0]||null}

/* ---------- request status (admin view) ---------- */
var RST={
  mgr:["With manager",""],
  you:["Waiting for you","warning"],
  repair:["In repair","info"],
  ready:["Ready for collection","info"],
  proc:["With procurement","info"],
  ceo:["Waiting for CEO approval","info"],
  pay:["Waiting for payment","info"],
  delivery:["Waiting for delivery","info"],
  done:["Delivered","success"],
  notvalid:["Not valid","error"],
  declined:["Declined by manager","error"]
};
var RORDER=["you","delivery","ready","repair","mgr","proc","ceo","pay","done","notvalid","declined"];
function rLabel(r){if(r.st==="done"&&r.kind==="service")return "Returned to "+first(r.who);if(r.st==="done"&&r.kind==="replacement")return "Replacement delivered";return RST[r.st][0]}
function rTag(r){var s=RST[r.st];return '<span class="a-tag'+(s[1]?' a-tag--'+s[1]:'')+'">'+esc(rLabel(r))+'</span>'}
function rClosed(r){return r.st==="done"||r.st==="notvalid"||r.st==="declined"}
function rTitle(r){if(r.title)return r.title;return r.items.map(function(k){return k==="other"&&r.other?r.other:ITEM_LABEL[k]}).join(" + ")}
function rArtType(r){var a=r.assetId?asset(r.assetId):null;return a?a.type:(ITEM_TYPE[r.items[0]]||"Other")}
/* what is in stock for each item on the request, at the request's office */
function rStock(r){return r.items.map(function(k){var t=ITEM_TYPE[k];return {k:k,type:t,list:k==="other"?[]:stockFor(t,r.office)}})}
function rAllInStock(r){var s=rStock(r);return s.length&&s.every(function(x){return x.list.length>0})}
function rStockTag(r){
  if(r.kind==="service")return '<span class="a-tag">Repair</span>';
  if(r.fromStock)return '<span class="a-tag a-tag--success">From stock</span>';
  if(r.st!=="you"&&r.st!=="mgr")return '<span class="a-tag">'+(rClosed(r)?"—":"Buy")+'</span>';
  var s=rStock(r);var hit=s.filter(function(x){return x.list.length}).length;
  if(hit===s.length)return '<span class="a-tag a-tag--success">In stock</span>';
  if(hit)return '<span class="a-tag a-tag--warning">'+hit+' of '+s.length+' in stock</span>';
  return '<span class="a-tag a-tag--warning">No stock</span>';
}
function rNext(r){
  var w=first(r.who);
  return {
    mgr:"Waiting for "+(r.mgr||"the manager")+" to approve. It reaches you after that.",
    you:r.kind==="service"?"Diagnose the device. Fix it at the IT desk or send it to the service centre.":(rAllInStock(r)?"Matching stock in "+r.office+". Issue it and the request is delivered; Procurement is not emailed.":"No matching stock in "+r.office+". Approve it and send it to Procurement, or close it as not valid."),
    repair:"With the service centre. Mark it ready when the device is back at the IT desk.",
    ready:"Ready at the IT desk. Mark it returned when "+w+" collects it.",
    proc:"Yahia Mohamad is collecting quotations from the vendor book.",
    ceo:"Comparison sheet is with CEO Waleed. He seals one quotation.",
    pay:"Sealed. Finance (Sabareesh Kumar) is recording the payment.",
    delivery:"Paid. When the courier delivers, mark it delivered: the register gives it an Asset ID and issues it to "+w+".",
    done:r.kind==="service"?"Back with "+w+". Closed.":"Delivered to "+w+". Closed.",
    notvalid:"Closed by IT as not valid. "+w+" was told why.",
    declined:"Declined by "+(r.mgr||"the manager")+" before it reached IT."
  }[r.st];
}
function needsYou(r){return r.st==="you"||r.st==="delivery"||r.st==="ready"}
