/* =====================================================================
   Shell: theme + density, toasts, notifications, routing (#hash), popup (drawer), tabs, timeline, decision modal, sortable tables, filter pills, overview tiles, downloads
   Concatenated in file-name order by scripts/build.mjs inside one IIFE
   ("use strict"), so every top-level name here is shared with the other files.
   ===================================================================== */

/* ---------- theme (Alpha DS: one sun/moon button, light by default, choice saved) ---------- */
var root=document.documentElement;
var SUN='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';
var MOON='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>';
function isDark(){var a=root.getAttribute("data-theme");return a?a==="dark":matchMedia("(prefers-color-scheme: dark)").matches}
function paintThemeBtn(){$("#themeIcon").innerHTML=isDark()?SUN:MOON;$("#themeLabel").textContent=isDark()?"Light mode":"Dark mode"}
$("#themeBtn").addEventListener("click",function(){var n=isDark()?"light":"dark";root.setAttribute("data-theme",n);store("ax-theme",n);paintThemeBtn()});
root.setAttribute("data-theme",store("ax-theme")==="dark"?"dark":"light");
paintThemeBtn();
/* density (Asset App v76-v78): Compact scales the UI to 87.5% at 1024px and wider */
var D_SMALL='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 14h6v6M20 10h-6V4M14 10l7-7M3 21l7-7"/></svg>';
var D_BIG='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/></svg>';
function paintDensity(){var c=root.getAttribute("data-density")==="compact";$("#densityIcon").innerHTML=c?D_BIG:D_SMALL;$("#densityLabel").textContent=c?"Default density":"Compact density"}
$("#density-row").addEventListener("click",function(){var c=root.getAttribute("data-density")!=="compact";if(c)root.setAttribute("data-density","compact");else root.removeAttribute("data-density");store("ax-density",c?"compact":"default");paintDensity()});
if(store("ax-density")==="compact")root.setAttribute("data-density","compact");paintDensity();

/* ---------- toasts (DS a-toast) ---------- */
var TOAST_IC={success:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>',error:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',"default":'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v4h1"/></svg>'};
function toast(msg,kind){var k=kind==="success"||kind==="error"?kind:"default";var t=document.createElement("div");t.className="a-toast a-toast--"+k;t.setAttribute("role","status");t.innerHTML='<div class="tt"><span class="ti">'+TOAST_IC[k]+'</span><div class="tx"><b>'+esc(msg)+'</b></div></div>';$("#toasts").appendChild(t);setTimeout(function(){t.style.transition="opacity .3s";t.style.opacity="0";setTimeout(function(){t.remove()},320)},3600)}

/* ---------- notifications ---------- */
var NOTIFS=store("ax-admin-notifs")||[
  {id:"n1",ref:"REQ-0116",kind:"req",t:"Jerrin approved REQ-0116",d:"Keyboard + mouse for Mohammed Nafih. Waiting for you: check stock in Dubai.",at:"21 Oct · 09:30",unread:true},
  {id:"n2",ref:"JOIN-0002",kind:"team",t:"Amira Boukhemkham is with IT",d:"Waleed chose a laptop, keyboard and mouse. Record a serial or asset ID on each item.",at:"26 Oct · 09:20",unread:true},
  {id:"n3",ref:"REQ-0120",kind:"req",t:"Mike approved REQ-0120",d:"Monitor for Susana Zapata. 8 spare Dell monitors in Dubai.",at:"23 Oct · 15:02",unread:true},
  {id:"n4",ref:"alert-dup",kind:"asset",t:"Serial S9N0LP00T92438C is on two assets",d:"AST-0055 and AST-0058 share one serial. New saves cannot reuse it.",at:"26 Oct · 09:26",unread:true},
  {id:"n5",ref:"REQ-0114",kind:"req",t:"REQ-0114 is paid",d:"Logitech Brio 500 for Rao Iqbal. Aramex expected 28 Oct.",at:"19 Oct · 11:31",unread:false},
  {id:"n6",ref:"REQ-0111",kind:"req",t:"REQ-0111 is with CEO Waleed",d:"Comparison sheet for a monitor and dock. Waleed seals one quotation.",at:"20 Oct · 08:55",unread:false},
  {id:"n7",ref:"",kind:"team",t:"Backup written",d:"registry-2026-10-26-0926.json after the last save.",at:"26 Oct · 09:26",unread:false}
];
var NICO={req:IC.keyboard,asset:IC.laptop,team:IC.people};
var notif=$("#notif");
function saveNotifs(){store("ax-admin-notifs",NOTIFS)}
function notify(kind,ref,t,d){NOTIFS.unshift({id:"n"+Date.now(),ref:ref,kind:kind,t:t,d:d,at:nowStamp().replace(/ 20\d\d/,""),unread:false});saveNotifs();renderNotifs()}
function renderNotifs(){
  var un=NOTIFS.filter(function(n){return n.unread}).length;$("#notif-badge").hidden=!un;
  var nn=$("#notif-n");nn.textContent=un;nn.hidden=!un;
  $("#notif-list").innerHTML=NOTIFS.slice(0,14).map(function(n){return '<button class="ni '+n.kind+(n.unread?' unread':'')+'" type="button" data-n="'+n.id+'" role="menuitem"><span class="ic">'+NICO[n.kind]+'</span><span><b>'+esc(n.t)+'</b><small>'+esc(n.d)+'</small></span><span class="dt">'+esc(n.at)+'</span><i class="dot'+(n.unread?'':' off')+'"></i></button>'}).join("");
  $$("#notif-list .ni").forEach(function(b){b.addEventListener("click",function(){var n=NOTIFS.filter(function(x){return x.id===b.getAttribute("data-n")})[0];n.unread=false;saveNotifs();renderNotifs();closeNotif();openRef(n.ref)})});
}
function openRef(ref){
  if(!ref)return;
  if(ref.indexOf("REQ-")===0){var r=req(ref);if(r)openRequest(r)}
  else if(ref.indexOf("JOIN-")===0){var j=joiner(ref);if(j)openJoiner(j)}
  else if(ref.indexOf("AST-")===0){if(asset(ref))openAsset(ref)}
  else if(ref.indexOf("EMP-")===0){if(person(ref))openPerson(ref)}
  else if(ref.indexOf("INF-")===0){if(infraById(ref))openInfra(ref)}
  else if(ref.indexOf("alert-")===0){var al=alerts().filter(function(a){return a.id===ref})[0];if(al)openAlert(al)}
}
function closeNotif(){notif.classList.remove("open");$("#notif-btn").setAttribute("aria-expanded","false")}
$("#notif-btn").addEventListener("click",function(e){e.stopPropagation();var o=!notif.classList.contains("open");closeProf();notif.classList.toggle("open",o);this.setAttribute("aria-expanded",String(o))});
$("#notif-read").addEventListener("click",function(){NOTIFS.forEach(function(n){n.unread=false});saveNotifs();renderNotifs()});
document.addEventListener("click",function(e){if(!notif.contains(e.target))closeNotif()});

/* ---------- header over the banner ---------- */
function syncTop(){var clear=document.body.classList.contains("on-hero")&&window.scrollY<24&&!$("#mnav").classList.contains("open");$(".top").classList.toggle("clear",clear)}
window.addEventListener("scroll",syncTop,{passive:true});

/* ---------- routing ---------- */
var VIEWS=["home","requests","assets","people","joiners","infra","reports","settings","help","signin"];
var curView="home";
function go(v,opts){
  var view=VIEWS.indexOf(v)!==-1?v:"home";curView=view;
  if($("#drawer").classList.contains("show"))closeDrawer();if($("#tscrim").classList.contains("show"))closeTModal();
  $$(".view").forEach(function(s){s.classList.toggle("on",s.id==="view-"+view)});
  $$("[data-nav]").forEach(function(a){a.classList.toggle("on",a.getAttribute("data-nav")===view)});
  document.body.classList.toggle("on-signin",view==="signin");
  document.body.classList.toggle("on-hero",view!=="signin");syncTop();
  $("#mnav").classList.remove("open");$("#menu-btn").setAttribute("aria-expanded","false");
  if(!(opts&&opts.keepScroll))window.scrollTo({top:0,behavior:"auto"});
}
function onHash(){var h=(location.hash||"#home").slice(1);go(h)}
window.addEventListener("hashchange",onHash);
/* go to a page and scroll to one of its sections */
function goTo(view,sel){if(curView!==view){location.hash=view;setTimeout(function(){scrollToEl(sel)},120)}else scrollToEl(sel)}
function scrollToEl(sel){setTimeout(function(){var t=$(sel);if(t)window.scrollTo({top:t.getBoundingClientRect().top+window.scrollY-84,behavior:"smooth"})},80)}
$$("[data-go]").forEach(function(b){b.addEventListener("click",function(){var v=b.getAttribute("data-go");if(("#"+v)===location.hash)go(v);else location.hash=v})});
$$("[data-scroll]").forEach(function(a){a.addEventListener("click",function(e){e.preventDefault();goTo(a.getAttribute("href").slice(1),a.getAttribute("data-scroll"))})});
$("#menu-btn").addEventListener("click",function(){var m=$("#mnav");var o=!m.classList.contains("open");m.classList.toggle("open",o);this.setAttribute("aria-expanded",String(o));syncTop()});
$("#logout").addEventListener("click",function(){closeProf();location.hash="signin";toast("Signed out of the design preview.")});
var prof=$("#prof-wrap");
function closeProf(){prof.classList.remove("open");$("#prof-btn").setAttribute("aria-expanded","false")}
$("#prof-btn").addEventListener("click",function(e){e.stopPropagation();closeNotif();var o=!prof.classList.contains("open");prof.classList.toggle("open",o);this.setAttribute("aria-expanded",String(o))});
document.addEventListener("click",function(e){if(!prof.contains(e.target))closeProf()});
$$(".prof-menu a").forEach(function(a){a.addEventListener("click",closeProf)});

/* ---------- popup ---------- */
var lastFocus=null;
function openDrawer(title,body,foot){
  if(!$("#drawer").classList.contains("show"))lastFocus=document.activeElement;
  $("#dr-title").innerHTML=title;$("#dr-body").innerHTML=body;$("#dr-body").scrollTop=0;$("#dr-foot").innerHTML=foot||"";
  $("#scrim").classList.add("show");var d=$("#drawer");d.classList.add("show");d.setAttribute("aria-hidden","false");
  document.body.style.overflow="hidden";bindTabs($("#dr-body"));$("#dr-close").focus();
}
function closeDrawer(){$("#scrim").classList.remove("show");var d=$("#drawer");d.classList.remove("show");d.setAttribute("aria-hidden","true");document.body.style.overflow="";if(lastFocus&&lastFocus.focus&&document.contains(lastFocus))lastFocus.focus()}
$("#dr-close").addEventListener("click",closeDrawer);$("#scrim").addEventListener("click",closeDrawer);
document.addEventListener("keydown",function(e){if(e.key==="Escape"){if($("#tscrim").classList.contains("show")){closeTModal();return}closeDrawer();$("#ask-panel").classList.remove("show");$("#msg-panel").classList.remove("show")}});
function row(k,v){return '<dt>'+k+'</dt><dd>'+v+'</dd>'}
function dash(v){return v?esc(v):'<span style="color:var(--fg-3)">—</span>'}
function tabs(list,start){start=start||0;return '<div class="dtabs" role="tablist">'+list.map(function(t,i){return '<button type="button" role="tab" data-tab="'+i+'" class="'+(i===start?'on':'')+'" aria-selected="'+(i===start)+'">'+esc(t[0])+'</button>'}).join("")+'</div>'+list.map(function(t,i){return '<div data-pane="'+i+'"'+(i===start?'':' hidden')+'>'+t[1]+'</div>'}).join("")}
function bindTabs(rt){
  var panes=$$("[data-pane]",rt);
  $$(".dtabs button",rt).forEach(function(b){b.addEventListener("click",function(){var k=b.getAttribute("data-tab");$$(".dtabs button",rt).forEach(function(x){var on=x===b;x.classList.toggle("on",on);x.setAttribute("aria-selected",String(on))});panes.forEach(function(pn){pn.hidden=pn.getAttribute("data-pane")!==k});rt.scrollTop=0})});
}
function nextStrip(text){return '<div class="nstep"><div class="eyebrow">Next step</div><div><span>'+IC.step+'</span><span>'+esc(text)+'</span></div></div>'}
function timelineHtml(events,futures,closed){
  var nowIdx=-1;events.forEach(function(e,i){if(e[3]!=="note")nowIdx=i});
  var done=events.map(function(e,i){var note=e[3]==="note";var now=i===nowIdx&&!closed;return '<div class="tle'+(now?' now':'')+(note?' note':'')+'"><span class="dot">'+(note?TL_EDIT:now?'<i class="nowdot"></i>':TICK12)+'</span><div class="wh"><b>'+esc(e[0])+'</b><span>'+esc(e[2]||"")+'</span></div><span class="at">'+esc(e[1])+'</span></div>'}).join("");
  var todo=(futures||[]).map(function(st){return '<div class="tle todo"><span class="dot"></span><div class="wh"><b>'+esc(st[0])+'</b><span>'+esc(st[1]||"")+'</span></div><span class="at">—</span></div>'}).join("");
  return '<div class="tl">'+done+todo+'</div>';
}
function on(id,fn){var el=$("#"+id);if(el)el.addEventListener("click",fn)}

/* ---------- decision / confirm modal (400px) ---------- */
var tYes=null;
var OK_IC='<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>';
var NO_IC='<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';
var WARN28='<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 9v4M12 17h.01"/><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/></svg>';
function openTModal(o){
  $("#t-ic").className="mi "+(o.tone||"");$("#t-ic").innerHTML=o.icon||WARN28;$("#t-title").textContent=o.title;$("#t-text").textContent=o.text||"";$("#t-body").innerHTML=o.body||"";
  $("#t-no").textContent=o.no||"Cancel";
  var y=$("#t-yes");y.className="a-btn a-btn--primary";y.textContent=o.yes;y.disabled=false;tYes=o.onYes;
  $("#tscrim").classList.add("show");(o.focus?$(o.focus):$("#t-no")).focus();
  if(o.after)o.after();
}
function closeTModal(){$("#tscrim").classList.remove("show");tYes=null}
$("#t-no").addEventListener("click",closeTModal);
$("#tscrim").addEventListener("click",function(e){if(e.target===this)closeTModal()});
$("#t-yes").addEventListener("click",function(){if(tYes)tYes()});
function pills(name,opts,checked){return '<div class="pills" role="radiogroup">'+opts.map(function(o){return '<label class="radio-r"><input type="radio" name="'+name+'" value="'+esc(o)+'"'+(o===checked?' checked':'')+'><i></i><span>'+esc(o)+'</span></label>'}).join("")+'</div><div class="err-t" data-err="'+name+'" hidden>Choose one.</div>'}
function radioVal(name,rt){var c=$('input[name="'+name+'"]:checked',rt);return c?c.value:""}

/* ---------- sortable tables (DS data table: brand up/down icon; click = ascending, again = descending) ---------- */
var SORT={},RENDER={};
function thead(tid,cols){var s=SORT[tid];return '<tr>'+cols.map(function(c){if(!c.k)return '<th>'+esc(c.l)+'</th>';var a=s&&s.key===c.k?(s.dir==="asc"?"ascending":"descending"):"none";return '<th class="sort" data-sort="'+c.k+'" aria-sort="'+a+'"><button type="button">'+esc(c.l)+SORT_SVG+'</button></th>'}).join("")+'</tr>'}
function sortBy(list,tid,get){var st=SORT[tid];if(!st||!get[st.key])return list;var g=get[st.key];
  return list.slice().sort(function(a,b){var x=g(a),y=g(b);var c=(typeof x==="number"&&typeof y==="number")?x-y:String(x).localeCompare(String(y),"en",{numeric:true,sensitivity:"base"});return st.dir==="asc"?c:-c})}
document.addEventListener("click",function(e){var b=e.target.closest&&e.target.closest("th.sort button");if(!b)return;
  var th=b.closest("th"),tbl=th.closest("table"),id=tbl.id,k=th.getAttribute("data-sort"),cur=SORT[id];
  SORT[id]={key:k,dir:cur&&cur.key===k&&cur.dir==="asc"?"desc":"asc"};
  if(RENDER[id])RENDER[id]();
});
/* whole row opens the popup */
function openRow(tr){var k=tr.getAttribute("data-open");if(!k)return;var p=k.split(":");var t=p[0],id=p.slice(1).join(":");
  if(t==="req")openRequest(req(id));else if(t==="asset")openAsset(id);else if(t==="person")openPerson(id);else if(t==="join")openJoiner(joiner(id));else if(t==="infra")openInfra(id);else if(t==="alert")openRef(id);else if(t==="type")openType(id);else if(t==="backup")openBackup(id);else if(t==="vendor")openVendor(id);else if(t==="desk")openDesk(id)}
document.addEventListener("click",function(e){var tr=e.target.closest&&e.target.closest("tr.row[data-open]");if(tr&&!e.target.closest("th"))openRow(tr)});
document.addEventListener("keydown",function(e){if(e.key!=="Enter"&&e.key!==" ")return;var tr=e.target.closest&&e.target.closest("tr.row[data-open]");if(tr&&e.target===tr){e.preventDefault();openRow(tr)}});
function noneRow(cols,text){return '<tr class="none-row"><td colspan="'+cols+'">'+esc(text)+'</td></tr>'}
/* filter pills with a count bubble; "All" first and default */
function drawPills(sel,defs,cur,list,onPick){
  var box=$(sel);if(!box)return;
  box.innerHTML=defs.map(function(f){var n=list.filter(f[2]).length;return '<button type="button" role="tab" data-f="'+f[0]+'" class="'+(f[0]===cur?'on':'')+'" aria-selected="'+(f[0]===cur)+'">'+esc(f[1])+'<span class="n">'+n+'</span></button>'}).join("");
  $$("[data-f]",box).forEach(function(b){b.addEventListener("click",function(){onPick(b.getAttribute("data-f"))})});
}
function matchQ(q,parts){if(!q)return true;q=q.toLowerCase();return parts.join(" ").toLowerCase().indexOf(q)!==-1}
/* overview tiles: one filled container, whole tile is the link */
function tileHtml(t){return '<a class="tile" href="'+t[0]+'" data-tile="'+(t[1]||"")+'"><span class="ti">'+t[2]+'</span><h3>'+esc(t[3])+'</h3><p>'+esc(t[4])+'</p></a>'}
function drawTiles(sel,list,onPick){var box=$(sel);if(!box)return;box.innerHTML=list.map(tileHtml).join("");$$("[data-tile]",box).forEach(function(a){a.addEventListener("click",function(e){e.preventDefault();onPick(a.getAttribute("data-tile"),a.getAttribute("href"))})})}
function heroMeta(sel,parts){var el=$(sel);if(el)el.innerHTML=parts.map(function(p){return '<span>'+esc(p)+'</span>'}).join("<i></i>")}
function avCell(name,sub){return '<div class="cell"><span class="av">'+initials(name)+'</span><div class="it-main"><b>'+esc(name)+'</b><span>'+esc(sub||"")+'</span></div></div>'}
var DL=null;try{if(window.claude&&window.claude.use)window.claude.use("downloads").then(function(d){DL=d}).catch(function(){})}catch(e){}
function download(name,text,type,okMsg){
  if(DL){DL.save({filename:name,data:text}).then(function(){if(okMsg)toast(okMsg,"success")}).catch(function(e){var c=e&&e.code;if(c==="declined")return;toast(c==="rate_limited"?"A save is already waiting for your answer.":"Downloads are not available in this view.","error")});return}
  try{var b=new Blob([text],{type:type||"text/plain"});var u=URL.createObjectURL(b);var a=document.createElement("a");a.href=u;a.download=name;document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(u);a.remove()},500);if(okMsg)toast(okMsg,"success")}catch(e){toast("Downloads are not available in this view.","error")}
}
function csv(rows){return rows.map(function(r){return r.map(function(c){c=String(c==null?"":c);return /[",\n]/.test(c)?'"'+c.replace(/"/g,'""')+'"':c}).join(",")}).join("\n")}
