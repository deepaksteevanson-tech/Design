/* =====================================================================
   Settings: desks and access, vendor book, notice addresses, sending mailbox, Google sign-in, team address
   Concatenated in file-name order by scripts/build.mjs inside one IIFE
   ("use strict"), so every top-level name here is shared with the other files.
   ===================================================================== */

/* ---------- settings (docs shell, same as Help & Support) ---------- */
var SETS=[
  {id:"desks",title:"Desks and access",who:"Who sees which tabs after sign-in"},
  {id:"vendors",title:"Vendor book",who:"Suppliers Procurement quotes from"},
  {id:"inboxes",title:"Notice addresses",who:"Who receives each notice"},
  {id:"mailbox",title:"Sending mailbox",who:"The account that sends the mail"},
  {id:"google",title:"Google sign-in",who:"@alphax.ae Workspace accounts"},
  {id:"address",title:"Team address",who:"The one link everyone opens"}
];
var DESKS=["IT · Ultimate","IT","CEO","HR","Manager","Procurement","Finance","Staff"];
var DESK_NOTE={"IT · Ultimate":"Full register, database, backups and delete","IT":"Full register, no delete","CEO":"Full register below Ultimate, seals quotations","HR":"Overview, People, New joiners, own kit and requests","Manager":"Own kit, team approvals, new joiner kit","Procurement":"Stock, Requests, Vendors","Finance":"Payments only","Staff":"Own kit and the request form"};
var curSet="desks";
function renderSettingsHero(){heroMeta("#set-hero-meta",[Object.keys(S.settings.desks).length+" people on special desks",plural(S.vendors.length,"vendor")+" on file",S.settings.smtp.saved?"Mailbox connected":"No sending mailbox yet"]);if($("#set-body")&&$("#set-body").innerHTML)showSet(curSet,true)}
function renderSetList(){
  $("#set-list").innerHTML=SETS.map(function(m){return '<button type="button" data-set="'+m.id+'">'+esc(m.title)+'<small>'+esc(m.who)+'</small></button>'}).join("");
  $$("#set-list button").forEach(function(b){b.addEventListener("click",function(){showSet(b.getAttribute("data-set"))})});
  var wrap=$("#set-select-wrap"),list=$("#set-list-m"),btn=$("#set-select");
  list.innerHTML=SETS.map(function(m){return '<button type="button" role="option" data-opt="'+m.id+'">'+esc(m.title)+'</button>'}).join("");
  function closeSel(){wrap.classList.remove("open");list.hidden=true;btn.setAttribute("aria-expanded","false")}
  btn.addEventListener("click",function(e){e.stopPropagation();var o=list.hidden;list.hidden=!o;wrap.classList.toggle("open",o);btn.setAttribute("aria-expanded",String(o))});
  $$("button",list).forEach(function(b){b.addEventListener("click",function(){showSet(b.getAttribute("data-opt"));closeSel()})});
  document.addEventListener("click",function(e){if(!wrap.contains(e.target))closeSel()});
}
function showSet(id,keep){
  var m=SETS.filter(function(x){return x.id===id})[0]||SETS[0];curSet=m.id;var i=SETS.indexOf(m);
  $$("#set-list button").forEach(function(b){b.classList.toggle("on",b.getAttribute("data-set")===m.id)});
  $("#set-select-text").textContent=m.title;$$("#set-list-m button").forEach(function(b){b.classList.toggle("on",b.getAttribute("data-opt")===m.id)});
  var lead={desks:"Sign-in decides the desk. Tabs a desk does not have are hidden. Everyone else with an @alphax.ae email is Staff.",vendors:"Jumbo, noon and other suppliers live here with payment type and pay-to. New quotations pick a vendor so Finance always sees the same pay-to details.",inboxes:"Who receives mail when HR, a manager or IT finishes a step, and when someone requests kit. This is not the sending mailbox.",mailbox:"An address alone cannot send. Add the mailbox login. Microsoft 365 uses smtp.office365.com, Gmail uses smtp.gmail.com (port 587). If MFA is on, use an app password.",google:"Optional. Create an OAuth client ID (Web application) in Google Cloud for @alphax.ae and paste it here. Authorised JavaScript origins must include the team address.",address:"This HTTPS link works on office Wi-Fi, home internet and mobile. Web, desktop and phone apps open this same address so they share one database."}[m.id];
  var html='<div class="page-h"><div class="eyebrow" style="margin-bottom:10px">Settings · '+(i+1)+' of '+SETS.length+'</div><h1>'+esc(m.title)+'</h1><p class="lead">'+esc(lead)+'</p></div><div class="sec">';
  var st=S.settings;
  if(m.id==="desks"){html+='<div class="tbl-w"><table class="tbl atbl w800" id="desk-table"><thead></thead><tbody></tbody></table></div>'}
  if(m.id==="vendors"){html+='<div class="band-h" style="margin-bottom:16px;grid-template-columns:minmax(0,1fr) auto"><div></div><div class="acts"><button class="a-btn a-btn--primary" type="button" id="vd-add">'+IC.plus+'Add vendor</button></div></div><div class="tbl-w"><table class="tbl atbl w800" id="vendor-table"><thead></thead><tbody></tbody></table></div>'}
  if(m.id==="inboxes"){var I=st.inbox;html+='<form class="fpan" id="ib-f" novalidate><div class="srow">'+fld("ib-hr","HR inbox",I.hr)+fld("ib-it","IT inbox",I.it)+'</div><div class="srow">'+fld("ib-proc","Procurement inbox",I.proc,{help:"No-stock purchase mail goes here."})+fld("ib-fin","Finance inbox",I.fin,{help:"Waiting for payment mail goes here."})+'</div><div class="srow">'+fld("ib-ceo","Waleed (CEO)",I.ceo,{help:"Comparison sheets with Approve."})+fld("ib-anna","Anna",I.anna)+'</div><div class="srow">'+fld("ib-mike","Mike",I.mike)+fld("ib-spiros","Spiros",I.spiros)+'</div><div class="form-foot"><p class="note">Separate several addresses with a comma. Only @alphax.ae addresses.</p><button class="a-btn a-btn--primary a-btn--md" type="submit">Save notice addresses</button></div></form>'}
  if(m.id==="mailbox"){var M=st.smtp;html+='<form class="fpan" id="mb-f" novalidate>'+(M.saved?'<div class="rf-note info">'+IC.info.replace('<svg','<svg width="18" height="18"')+'<span>Mailbox saved. Notices are sent from '+esc(M.sendAs||M.login)+'.</span></div>':'<div class="rf-note">'+IC.warn.replace('<svg','<svg width="18" height="18"')+'<span>Auto email is off because this register has no mailbox to send from. Notices stay in the register for Open in mail.</span></div>')+'<div class="srow">'+fld("mb-host","SMTP host",M.host,{ph:"smtp.office365.com or smtp.gmail.com",err:"Add the SMTP host."})+fld("mb-port","Port",M.port)+'</div><div class="srow">'+fld("mb-login","Mailbox login",M.login,{ph:"it@alphax.ae or notifications@alphax.ae",err:"Use an @alphax.ae mailbox."})+fld("mb-as","Send as",M.sendAs,{opt:true})+'</div><div class="srow">'+fld("mb-pw","Password",M.saved?"••••••••••":"",{type:"password",ph:"App password if MFA is on",err:"Add the password."})+'<div></div></div><div class="form-foot"><button class="a-btn a-btn--secondary a-btn--md" type="button" id="mb-test">Send test email to Deepak</button><button class="a-btn a-btn--primary a-btn--md" type="submit">Save mailbox</button></div></form>'}
  if(m.id==="google"){html+='<form class="fpan" id="gg-f" novalidate>'+fld("gg-id","Google client ID",st.google,{ph:"xxxx.apps.googleusercontent.com",err:"A client ID ends with .apps.googleusercontent.com",help:"Origins: "+esc(st.team)+" and http://127.0.0.1:43147. A lasting HTTPS address works better than a temporary tunnel."})+'<div class="form-foot"><p class="note">Gmail.com accounts are always rejected.</p><button class="a-btn a-btn--primary a-btn--md" type="submit">Save Google sign-in</button></div></form>'}
  if(m.id==="address"){html+='<div class="fpan"><div class="a-field"><label for="ad-url">Official team address</label><div class="copyline"><input class="a-input" id="ad-url" value="'+esc(st.team)+'"><button class="a-btn a-btn--secondary" type="button" id="ad-copy">'+IC.copy+'Copy</button></div><span class="a-help">This machine checks it every 20 seconds and brings the link back if Cloudflare drops it. Opening 127.0.0.1 on another computer is error -102.</span><div class="err-t" data-err="ad-url" hidden>Use an https:// address.</div></div><div class="form-foot"><p class="note">Emails and Copy link use this instead of a temporary tunnel.</p><button class="a-btn a-btn--primary a-btn--md" type="button" id="ad-save">Save official address</button></div></div>'}
  html+='</div>';
  var prev=SETS[i-1],next=SETS[i+1];
  html+='<div class="sec" style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap">'+(prev?'<button class="a-btn a-btn--secondary" type="button" data-set-go="'+prev.id+'">← '+esc(prev.title)+'</button>':'<span></span>')+(next?'<button class="a-btn a-btn--secondary" type="button" data-set-go="'+next.id+'">'+esc(next.title)+' →</button>':'')+'</div>';
  $("#set-body").innerHTML=html;
  $$("[data-set-go]").forEach(function(b){b.addEventListener("click",function(){showSet(b.getAttribute("data-set-go"));var t=$("#set-panel").getBoundingClientRect().top+window.scrollY-72;window.scrollTo({top:t,behavior:"smooth"})})});
  if(m.id==="desks")renderDesks();
  if(m.id==="vendors"){renderVendors();on("vd-add",function(){openVendorForm(null)})}
  var ib=$("#ib-f");if(ib)ib.addEventListener("submit",function(e){e.preventDefault();var bad=false;["hr","it","proc","fin","ceo","anna","mike","spiros"].forEach(function(k){var v=$("#ib-"+k).value.trim();var okv=v.split(",").every(function(x){return /@alphax\.ae$/.test(x.trim())});formErr("ib-"+k,!okv,"Only @alphax.ae addresses.");if(!okv)bad=true});if(bad)return;["hr","it","proc","fin","ceo","anna","mike","spiros"].forEach(function(k){st.inbox[k]=$("#ib-"+k).value.trim()});log("change","Notice addresses updated");save();renderAll();toast("Notice addresses saved.","success")});
  var mb=$("#mb-f");if(mb){mb.addEventListener("submit",function(e){e.preventDefault();var host=$("#mb-host").value.trim(),login=$("#mb-login").value.trim(),pw=$("#mb-pw").value;var ok=formErr("mb-host",!host)&formErr("mb-login",!/@alphax\.ae$/.test(login))&formErr("mb-pw",!pw);if(!ok)return;st.smtp={host:host,port:$("#mb-port").value.trim()||"587",login:login,sendAs:$("#mb-as").value.trim(),saved:true};log("change","Sending mailbox set to "+login);save();renderAll();showSet("mailbox");toast("Mailbox saved. Send a test email to check it.","success")});
    on("mb-test",function(){if(!st.smtp.saved){toast("Save the mailbox first.","error");return}toast("Test email sent to "+ME.email+".","success")})}
  var gg=$("#gg-f");if(gg)gg.addEventListener("submit",function(e){e.preventDefault();var v=$("#gg-id").value.trim();if(!formErr("gg-id",!/\.apps\.googleusercontent\.com$/.test(v)))return;st.google=v;log("change","Google sign-in client ID saved");save();toast("Google sign-in is on for @alphax.ae accounts.","success")});
  on("ad-copy",function(){try{navigator.clipboard.writeText($("#ad-url").value)}catch(e){}toast("Team address copied.")});
  on("ad-save",function(){var v=$("#ad-url").value.trim();if(!formErr("ad-url",!/^https:\/\//.test(v)))return;st.team=v;log("change","Official team address set to "+v);save();toast("Official address saved.","success")});
}
function renderDesks(){
  var tid="desk-table";if(!$("#"+tid))return;
  $("#"+tid+" thead").innerHTML=thead(tid,[{l:"Person",k:"name"},{l:"Desk",k:"desk"},{l:"What they see"},{l:"Can delete"},{l:""}]);
  var list=Object.keys(S.settings.desks).map(function(n){return {name:n,desk:S.settings.desks[n],p:personByName(n)}});
  list=SORT[tid]?sortBy(list,tid,{name:function(x){return x.name},desk:function(x){return DESKS.indexOf(x.desk)}}):list.sort(function(a,b){return DESKS.indexOf(a.desk)-DESKS.indexOf(b.desk)});
  $("#"+tid+" tbody").innerHTML=list.map(function(x){return '<tr class="row" tabindex="0" data-open="desk:'+esc(x.name)+'"><td>'+avCell(x.name,x.p?x.p.email:"")+'</td><td><span class="a-tag">'+esc(x.desk)+'</span></td><td class="dim wr" style="min-width:260px">'+esc(DESK_NOTE[x.desk])+'</td><td>'+(x.desk==="IT · Ultimate"?'<span class="a-tag a-tag--success">Yes</span>':'<span style="color:var(--fg-3)">No</span>')+'</td><td class="go">'+IC.chev+'</td></tr>'}).join("");
}
RENDER["desk-table"]=renderDesks;
function openDesk(name){var cur=S.settings.desks[name];
  openTModal({tone:"ok",icon:IC.key.replace('<svg','<svg width="28" height="28"'),title:"Desk for "+name,text:"Takes effect the next time "+first(name)+" signs in.",body:pills("dk",DESKS.concat(["Remove special desk"]),cur),yes:"Save desk",onYes:function(){var v=radioVal("dk",$("#t-body"));if(!v)return;if(v==="Remove special desk")delete S.settings.desks[name];else S.settings.desks[name]=v;if(v==="IT · Ultimate"&&name!==ME.name)toast("Two people now have IT · Ultimate.","default");log("change",name+" desk set to "+(v==="Remove special desk"?"Staff":v));save();closeTModal();renderAll();renderDesks();toast(name+": "+(v==="Remove special desk"?"Staff":v)+".","success")}});
}
function renderVendors(){
  var tid="vendor-table";if(!$("#"+tid))return;
  $("#"+tid+" thead").innerHTML=thead(tid,[{l:"Vendor",k:"name"},{l:"Payment",k:"pay"},{l:"Pay to"},{l:"Notes"},{l:"ID"},{l:""}]);
  var list=sortBy(S.vendors,tid,{name:function(v){return v.name},pay:function(v){return v.pay}});
  $("#"+tid+" tbody").innerHTML=list.length?list.map(function(v){return '<tr class="row" tabindex="0" data-open="vendor:'+v.id+'"><td><div class="cell"><span class="ti n">'+IC.store+'</span><div class="it-main"><b>'+esc(v.name)+'</b><span>'+(v.sample?"Sample vendor":"Vendor book")+'</span></div></div></td><td><span class="a-tag">'+esc(v.pay)+'</span></td><td class="dim wr" style="min-width:200px">'+esc(v.payTo)+'</td><td class="dim wr" style="min-width:220px">'+dash(v.notes)+'</td><td class="num">'+esc(v.id)+'</td><td class="go">'+IC.chev+'</td></tr>'}).join(""):noneRow(6,"No vendors on file. Add Jumbo, noon or any supplier once.");
}
RENDER["vendor-table"]=renderVendors;
function openVendor(id){var v=S.vendors.filter(function(x){return x.id===id})[0];if(v)openVendorForm(v)}
function openVendorForm(v){
  var edit=!!v;var nid=edit?v.id:nextId("VEN-",S.vendors,3);
  var body='<form class="rf" id="vf" novalidate><div class="frow">'+fld("vf-name","Vendor",edit?v.name:"",{req:true,ph:"Jumbo, noon…",err:"Add the vendor name."})+fld("vf-id","ID",nid,{ro:true})+'</div>'+radioField("vf-pay","Payment type",["Cash","Account transfer","Payment link"],edit?v.pay:"",true)+fld("vf-to","Pay to",edit?v.payTo:"",{req:true,ph:"Account name and number, or the payment link",err:"Add where Finance pays."})+fld("vf-notes","Notes",edit?v.notes:"",{area:true,opt:true})+'</form>';
  openDrawer(edit?'Vendor <code>'+v.id+'</code>':'Add vendor',body,(edit&&CAN_DELETE?'<button class="a-btn a-btn--secondary" type="button" id="dr-del">'+IC.trash+'Delete</button>':'')+'<span style="flex:1"></span><button class="a-btn a-btn--secondary" type="button" id="vf-cancel">Cancel</button><button class="a-btn a-btn--primary" type="button" id="vf-save">'+(edit?'Save changes':'Save vendor')+'</button>');
  on("vf-cancel",closeDrawer);
  on("dr-del",function(){confirmDelete("vendor",v.id,v.name,function(){S.vendors=S.vendors.filter(function(x){return x.id!==v.id})});setTimeout(renderVendors,50)});
  on("vf-save",function(){var f=$("#vf");var name=$("#vf-name").value.trim(),pay=radioVal("vf-pay",f),to=$("#vf-to").value.trim();var ok=formErr("vf-name",!name)&formErr("vf-pay",!pay)&formErr("vf-to",!to);if(!ok)return;
    var o={name:name,pay:pay,payTo:to,notes:$("#vf-notes").value.trim()};
    if(edit){Object.keys(o).forEach(function(k){v[k]=o[k]});v.sample=false;log("change","Vendor "+name+" updated")}else{o.id=nid;S.vendors.push(o);log("change","Vendor "+name+" added to the vendor book")}
    save();renderAll();renderVendors();closeDrawer();toast(name+" saved in the vendor book.","success")});
}
