/* =====================================================================
   Ask the register (FAQ), Messages (office chat), sign-in showcase, floating-button sync, boot
   Concatenated in file-name order by scripts/build.mjs inside one IIFE
   ("use strict"), so every top-level name here is shared with the other files.
   ===================================================================== */

/* ---------- Ask the register (admin answers) ---------- */
var FAQ=[
  {k:/procure|buy|purchase|no stock|yahia|quot/,a:"Open the request. If the stock check shows a matching spare <b>in that office</b>, tap <b>Issue from stock</b>: it is delivered and Procurement is not emailed. If nothing matches, tap <b>Send to Procurement</b>. Mail goes To ymohamad@alphax.ae; Yahia quotes it, CEO Waleed seals one quotation, Finance pays, and you <b>Mark delivered</b> when the courier arrives."},
  {k:/joiner|newbee|handover|sign|axaf/,a:"New joiners run HR → manager → IT → employee. When a joiner is <b>With IT</b>, open the row, pick a spare or type the serial for every item and tap <b>Mark ready</b>. The register adds them to People, issues the kit and emails the signing link. After they sign AXAF0726015, tap <b>Signed · mark joined</b>."},
  {k:/delete|remove|ultimate/,a:"Only <b>IT · Ultimate</b> (Deepak) can delete. Delete asks you to type the ID. A person can only be deleted with no kit on their name; everyone else marks people Exited and returns kit to stock. The last backup keeps a copy."},
  {k:/backup|restore|json|registry/,a:"The live file is <b>data/registry.json</b>. A dated backup is written on every save. Open <b>Reports → Backup and export</b> to download one, back up now, or restore from a file. On the server, replace data/registry.json from data/backups and keep the app running."},
  {k:/return|exit|leav|collect/,a:"Open the asset and tap <b>Return to stock</b>, or open an exited person and tap <b>Return all kit</b>. Collected items show as <b>Returned · check</b> until you move them to stock or retire them. Exiting a person never collects kit by itself."},
  {k:/serial|duplicate|reuse/,a:"Every device needs its own serial. The register flags reused serials on Overview under <b>Needs your attention</b>, and new saves cannot reuse one. Open each asset, read the sticker and correct the wrong card."},
  {k:/stock|spare|add/,a:"Tap <b>Add to stock</b> on Overview or Assets. No person is needed: asset ID, what it is, type, office, brand, model and serial. It shows as In stock until you issue it. Stock is per office, so a spare in Uganda never covers Dubai."},
  {k:/desk|role|access|who sees/,a:"Sign-in decides the desk. Change desks in <b>Settings → Desks and access</b>. IT · Ultimate has everything plus delete; IT has no delete; CEO seals quotations; HR adds people and joiners; Procurement has stock, requests and vendors; Finance records payments only."},
  {k:/mail|smtp|notice|inbox/,a:"Notices go to the addresses in <b>Settings → Notice addresses</b>. Nothing is sent until a <b>Sending mailbox</b> is saved with its login and an app password. Use Send test email to check it."},
  {k:/repair|service|broken/,a:"Service requests come straight to IT. Open it and tap <b>Send for repair</b>; the asset shows In repair. When it is back, tap <b>Ready for collection</b>, then <b>Mark returned</b> when the person collects it."},
  {k:/infra|room|wifi|server|ip/,a:"<b>Infrastructure</b> holds offices, floors, rooms, Wi-Fi, servers and circuits with host and IP. Only IT sees it. Tap <b>Add infrastructure</b> and pick the site it sits in."},
  {k:/address|link|url|127|tunnel/,a:"Everyone opens <code>https://inventory.alphaxdev.online</code>. Set it in <b>Settings → Team address</b>. 127.0.0.1 only works on the host machine."}
];
function ask(q){
  var lg=$("#ask-log");lg.insertAdjacentHTML("beforeend",'<div class="bub me">'+esc(q)+'</div>');
  var hit=null;var ql=q.toLowerCase();for(var i=0;i<FAQ.length;i++){if(FAQ[i].k.test(ql)){hit=FAQ[i];break}}
  var a=hit?hit.a:"I only know this register's process notes. Try asking about stock versus buy, new joiners, returns, deleting, backups, desks or mail.";
  setTimeout(function(){lg.insertAdjacentHTML("beforeend",'<div class="bub">'+a+'<small>From the process notes · I cannot change records</small></div>');lg.scrollTop=lg.scrollHeight},250);
  lg.scrollTop=lg.scrollHeight;
}
/* each floating button mirrors its panel: open = close (x) button (Asset App v80) */
(function(){function sync(){[["#ask-btn","#ask-panel"],["#msg-btn","#msg-panel"]].forEach(function(x){var b=$(x[0]),o=$(x[1]).classList.contains("show");b.classList.toggle("open",o);b.setAttribute("aria-expanded",String(o));b.setAttribute("aria-label",o?"Close "+(x[0]==="#ask-btn"?"Ask the register":"Messages"):(x[0]==="#ask-btn"?"Ask the register":"Messages"))})}
["#ask-panel","#msg-panel"].forEach(function(id){new MutationObserver(sync).observe($(id),{attributes:true,attributeFilter:["class"]})});sync()})();
$("#ask-btn").addEventListener("click",function(){var p=$("#ask-panel");var o=!p.classList.contains("show");p.classList.toggle("show",o);this.setAttribute("aria-expanded",String(o));$("#msg-panel").classList.remove("show");if(o)$("#ask-q").focus()});
$("#ask-form").addEventListener("submit",function(e){e.preventDefault();var q=$("#ask-q").value.trim();if(!q)return;$("#ask-q").value="";ask(q)});
$$("#ask-chips button").forEach(function(b){b.addEventListener("click",function(){ask(b.textContent)})});

/* ---------- Messages (people in the office) ---------- */
var threads={};
var seeded={
  "Jerrin Varghese":[{me:false,t:"Hi Deepak, I approved REQ-0116 for Nafih. Do we have an MX Keys set in stock, or does it go to Yahia?",ts:"21 Oct 09:34"}],
  "Waleed Al Aryan":[{me:false,t:"Amira starts this week. Laptop, keyboard and mouse please, she works from the office.",ts:"26 Oct 09:21"}],
  "Yahia Mohamad":[{me:false,t:"Quotations for REQ-0112 come Thursday. The 5K panel is back-ordered at Jumbo.",ts:"22 Oct 14:05"}]
};
function msgPeople(){return S.people.filter(function(p){return p.status==="Active"&&p.email&&p.name!==ME.name}).map(function(p){return p.name}).sort()}
function renderPeopleList(q){
  q=(q||"").toLowerCase();var list=msgPeople();
  /* people with a conversation first */
  list.sort(function(a,b){var x=threads[a]||seeded[a]?0:1,y=threads[b]||seeded[b]?0:1;return x-y||a.localeCompare(b)});
  $("#msg-people").innerHTML=list.filter(function(p){return !q||p.toLowerCase().indexOf(q)!==-1}).map(function(p){
    var th=threads[p]||seeded[p];var last=th&&th.length?th[th.length-1].t:"Tap to chat";var desk=S.settings.desks[p];
    return '<button class="pp" type="button" data-person="'+esc(p)+'"><span class="av">'+initials(p)+'</span><span class="nm"><b>'+esc(p)+(desk?'<em class="role">'+esc(desk)+'</em>':'')+'</b><span>'+esc(last)+'</span></span></button>';
  }).join("")||'<div class="none" style="padding:16px;color:var(--fg-3);font-size:13px">Nobody in the office matches that.</div>';
  $$("#msg-people .pp").forEach(function(b){b.addEventListener("click",function(){openThread(b.getAttribute("data-person"))})});
}
var curPerson=null;
function openThread(p){
  curPerson=p;if(!threads[p])threads[p]=(seeded[p]||[]).slice();
  $("#msg-panel").classList.add("thread");$("#msg-title").textContent=p;$("#msg-sub").textContent=S.settings.desks[p]||"In the office";
  renderThread();$("#msg-in").focus();
}
function renderThread(){
  var th=threads[curPerson]||[];var lg=$("#msg-log");
  lg.innerHTML=th.length?th.map(function(m){return '<div class="bub'+(m.me?" me":"")+'">'+esc(m.t)+'<small>'+esc(m.ts)+'</small></div>'}).join(""):'<div class="bub" style="align-self:center;color:var(--fg-3)">Start the conversation with '+esc(first(curPerson))+'. Messages stay in the register and are not emailed.</div>';
  lg.scrollTop=lg.scrollHeight;
}
$("#msg-form").addEventListener("submit",function(e){e.preventDefault();var v=$("#msg-in").value.trim();if(!v||!curPerson)return;threads[curPerson].push({me:true,t:v,ts:"Just now"});$("#msg-in").value="";renderThread()});
$("#msg-back").addEventListener("click",function(){$("#msg-panel").classList.remove("thread");$("#msg-title").textContent="Messages";$("#msg-sub").textContent="People in the office";renderPeopleList($("#msg-q").value)});
$("#msg-new").addEventListener("click",function(){$("#msg-q").value="";renderPeopleList("");$("#msg-q").focus()});
$("#msg-q").addEventListener("input",function(){renderPeopleList(this.value)});
$("#msg-btn").addEventListener("click",function(){var p=$("#msg-panel");var o=!p.classList.contains("show");p.classList.toggle("show",o);this.setAttribute("aria-expanded",String(o));$("#ask-panel").classList.remove("show");$("#msg-dot").hidden=true;if(o&&!p.classList.contains("thread"))renderPeopleList($("#msg-q").value)});
$("#msg-dot").hidden=false;

/* ---------- sign-in showcase ---------- */
var SI={
  login:{t:"Sign in",l:"Use your @alphax.ae work email and password, or Sign in with Google. Other domains cannot sign in.",b:"Sign in",pw:true},
  change:{t:"Change password",l:"Type your work email and current password. We email a verification link and a 6-digit code. The new password is saved only after that email is used.",b:"Email me a verification code",pw:true},
  forgot:{t:"Forgot password",l:"Type your @alphax.ae work email. We send a verification link and a 6-digit code to that inbox. Check junk if it is not there.",b:"Email me a verification code",pw:false}
};
var siMode="login";
function setSi(m){siMode=m;var d=SI[m];$("#si-title").textContent=d.t;$("#si-lead").textContent=d.l;$("#si-btn").textContent=d.b;$("#si-pw-wrap").hidden=!d.pw;$("#si-err").classList.remove("show");
  $$("[data-si]").forEach(function(a){var k=a.getAttribute("data-si");a.textContent=(m===k)?"Back to sign in":{change:"Change password",forgot:"Forgot password?"}[k]})}
$$("[data-si]").forEach(function(a){a.addEventListener("click",function(){var k=a.getAttribute("data-si");setSi(siMode===k?"login":k)})});
$("#si-form").addEventListener("submit",function(e){
  e.preventDefault();var em=$("#si-email").value.trim().toLowerCase();var err=$("#si-err");
  if(!em){err.textContent="Type your work email.";err.classList.add("show");return}
  if(!/@alphax\.ae$/.test(em)){err.textContent="Use your @alphax.ae work email. Other domains cannot sign in.";err.classList.add("show");return}
  if(siMode==="login"){if(!$("#si-pw").value){err.textContent="Type your password.";err.classList.add("show");return}var name=(S.people.filter(function(p){return p.email===em})[0]||{}).name;var desk=name&&S.settings.desks[name];
    if(!desk||["IT · Ultimate","IT","CEO"].indexOf(desk)===-1){err.textContent="This desk is for IT and the CEO. "+(name?name+" signs in to the Asset App instead.":"That email is not on People.");err.classList.add("show");return}
    toast("Signed in as "+em+" (design preview).","success");location.hash="home";return}
  err.classList.remove("show");toast("If that work email is on file, we sent a verification email with a link and a 6-digit code.","success");setSi("login");
});
$("#si-google").addEventListener("click",function(){var err=$("#si-err");if(S.settings.google){toast("Google sign-in opens here once the live app is wired.");return}err.textContent="IT has not connected Google sign-in yet. Add the client ID in Settings → Google sign-in.";err.classList.add("show")});

/* ---------- boot ---------- */
heroMeta("#help-hero-meta",[MODULES.length+" topics","Every desk, flow and approval in the register","Quick answers in Ask the register"]);
renderSetList();showSet("desks");
renderAll();renderModList();showModule("map");renderPeopleList("");
$("#foot-saved").textContent=S.saved.replace(" · ",", ");
onHash();
