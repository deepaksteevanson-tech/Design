/* =====================================================================
   Popups and actions: requests (issue from stock, procurement, delivery, service), assets (assign, return, retire, delete, add to stock), people
   Concatenated in file-name order by scripts/build.mjs inside one IIFE
   ("use strict"), so every top-level name here is shared with the other files.
   ===================================================================== */

/* =====================================================================
   POPUPS AND ADMIN ACTIONS
   ===================================================================== */
function msgTo(name,text){closeDrawer();closeTModal();var p=$("#msg-panel");p.classList.add("show");$("#msg-btn").setAttribute("aria-expanded","true");$("#ask-panel").classList.remove("show");openThread(name);if(text)$("#msg-in").value=text;$("#msg-in").focus()}
function refresh(){save();renderAll()}

/* ---------- request popup ---------- */
function chainReq(r){
  var TICK='<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>';
  var X='<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  var lab={done:"Done",now:"Now",todo:"Next",stop:"Stopped",skip:"Not needed"};
  var steps,st;
  if(r.kind==="service"){
    steps=[["1 · Request",first(r.who)+" asked"],["2 · You","Diagnose at the IT desk"],["3 · Service centre","Repair or parts"],["4 · Handed back","Collected at the IT desk"]];
    st={you:["done","now","todo","todo"],repair:["done","done","now","todo"],ready:["done","done","done","now"],done:["done","done","done","done"],notvalid:["done","stop","skip","skip"]}[r.st]||["done","now","todo","todo"];
  }else{
    steps=[["1 · Request",first(r.who)+" asked"],["2 · Manager",r.mgr||"Approve in the email"],["3 · You","IT checks stock"],["4 · Procurement","Yahia → CEO → Finance"],["5 · Delivered","Issued to "+first(r.who)]];
    st={mgr:["done","now","todo","todo","todo"],you:["done","done","now","todo","todo"],proc:["done","done","done","now","todo"],ceo:["done","done","done","now","todo"],pay:["done","done","done","now","todo"],delivery:["done","done","done","done","now"],done:["done","done","done",r.fromStock?"skip":"done","done"],notvalid:["done","done","stop","skip","skip"],declined:["done","stop","skip","skip","skip"]}[r.st];
  }
  return '<div class="chain'+(steps.length===5?' c5':'')+'" aria-label="Approval path">'+steps.map(function(x,i){var k=st[i];return '<div class="ch '+k+'"><span class="k"><i>'+(k==="done"?TICK:k==="stop"?X:"")+'</i>'+lab[k]+'</span><b>'+esc(x[0])+'</b><span>'+esc(x[1])+'</span></div>'}).join("")+'</div>';
}
function rFutures(r){
  if(r.kind==="service"){var sv=[["you","Diagnose","Fix it at the IT desk or send it out."],["repair","In repair","With the service centre."],["ready","Ready for collection","At the IT desk."],["done","Returned to "+first(r.who),"Card updated."]];var i=sv.map(function(x){return x[0]}).indexOf(r.st);return rClosed(r)?[]:sv.slice(i+1).map(function(x){return [x[1],x[2]]})}
  var all=[["mgr","Manager approval",(r.mgr||"The manager")+" taps Approve in the email."],["you","IT checks stock","Issue from stock, or approve and send to Procurement."],["proc","With procurement","Yahia quotes the product."],["ceo","CEO approval","Waleed seals one quotation."],["pay","Payment","Finance records the payment."],["delivery","Delivery","Courier and delivery date on the trail."],["done","Delivered","Issued to "+first(r.who)+" with an Asset ID."]];
  if(rClosed(r))return [];var i2=all.map(function(x){return x[0]}).indexOf(r.st);return all.slice(i2+1).map(function(x){return [x[1],x[2]]});
}
function openRequest(r,startTab){
  if(!r)return;
  var p=person(r.emp);var dev=r.assetId?asset(r.assetId):null;
  var stockHtml="";
  if(r.kind!=="service"&&(r.st==="you"||r.st==="mgr")){
    stockHtml='<div class="dsub">Stock in '+esc(r.office)+'</div><div class="klist">'+rStock(r).map(function(s){
      return s.list.length?'<div>'+art(s.type,"xs")+'<span class="nm"><b>'+esc(ITEM_LABEL[s.k])+' · '+plural(s.list.length,"spare")+'</b><span>'+esc(s.list.map(function(a){return a.id}).join(", "))+'</span></span><span class="a-tag a-tag--success">In stock</span></div>'
        :'<div>'+art(s.type,"xs")+'<span class="nm"><b>'+esc(s.k==="other"&&r.other?r.other:ITEM_LABEL[s.k])+'</b><span>Nothing unassigned in '+esc(r.office)+'</span></span><span class="a-tag a-tag--warning">Buy</span></div>'}).join("")+'</div>';
  }
  var details=nextStrip(rNext(r))+'<dl class="dl">'+
    row("Requested by",'<span style="display:inline-flex;align-items:center;gap:10px"><span class="av">'+initials(r.who)+'</span><span>'+esc(r.who)+'<br><span style="color:var(--fg-3);font-size:12px">'+esc(p?(p.title||"")+" · "+(p.email||"No official email"):"")+'</span></span></span>')+
    row("Type",'<span class="a-tag">'+esc(KIND[r.kind])+'</span>')+row("Status",rTag(r))+row("Office",esc(r.office))+
    (dev?row("Device",esc(dev.name)+'<br><span style="color:var(--fg-3);font-size:12px">'+esc(dev.id)+' · '+esc(dev.serial||"No serial")+'</span>'):row("Items",r.items.map(function(k){return '<span class="a-tag">'+esc(k==="other"&&r.other?r.other:ITEM_LABEL[k])+'</span>'}).join(" ")))+
    (r.issue?row("Issue",esc(r.issue)):"")+
    row("Product reference",dash(r.ref))+row("Estimated cost",dash(r.cost))+row("Needed by",dash(r.needBy))+(r.vendor?row("Vendor",esc(r.vendor)):"")+
    row("Manager",r.mgr?esc(r.mgr):'<span style="color:var(--fg-3)">CC only</span>')+
    row(r.kind==="service"?"Description":"Business justification",dash(r.reason))+
    row("Attachments",r.files&&r.files.length?r.files.map(function(f){return '<span class="a-tag">'+IC.clip+' '+esc(f)+'</span>'}).join(" "):'<span style="color:var(--fg-3)">—</span>')+
    (r.issued&&r.issued.length?row("Issued",r.issued.map(function(id){return '<code>'+esc(id)+'</code>'}).join(" ")):"")+
    (r.note?row("IT note",esc(r.note)):"")+'</dl>'+stockHtml;
  var history=timelineHtml(r.events,rFutures(r),rClosed(r));
  var body='<div class="dhero">'+art(rArtType(r),"lg",r.title)+'<div><h4>'+esc(rTitle(r))+'</h4><p>'+esc(KIND[r.kind])+' · '+esc(r.who)+' · '+esc(r.date)+'</p></div></div>'+chainReq(r)+tabs([["Details",details],["Timeline",history]],startTab==="timeline"?1:0);
  var w=first(r.who),foot="";
  var MSG='<button class="a-btn a-btn--secondary" type="button" id="rq-msg">'+IC.chat+'Message '+esc(w)+'</button>';
  if(r.st==="you"&&r.kind==="service"){
    foot='<button class="a-btn a-btn--secondary" type="button" id="rq-nv">Not valid</button><span style="flex:1"></span>'+MSG+'<button class="a-btn a-btn--primary" type="button" id="rq-repair">'+IC.wrench+'Send for repair</button>';
  }else if(r.st==="you"){
    var all=rAllInStock(r);
    foot='<button class="a-btn a-btn--secondary" type="button" id="rq-nv">'+(r.mgr&&r.events.some(function(e){return /approved and sent it to Admin/.test(e[2])})?"Decline":"Not valid")+'</button><span style="flex:1"></span>'+
      (all?'<button class="a-btn a-btn--secondary" type="button" id="rq-proc">'+IC.cart+'Buy instead</button><button class="a-btn a-btn--primary" type="button" id="rq-issue">'+IC.box+'Issue from stock</button>'
          :MSG+'<button class="a-btn a-btn--primary" type="button" id="rq-proc">'+IC.send+'Send to Procurement</button>');
  }else if(r.st==="delivery"){
    foot='<span class="foot-note">Paid. Mark it delivered when the courier arrives.</span><span style="flex:1"></span><button class="a-btn a-btn--primary" type="button" id="rq-deliver">'+IC.check+'Mark delivered and issue</button>';
  }else if(r.st==="repair"){
    foot='<span class="foot-note">With the service centre.</span><span style="flex:1"></span>'+MSG+'<button class="a-btn a-btn--primary" type="button" id="rq-ready">'+IC.check+'Ready for collection</button>';
  }else if(r.st==="ready"){
    foot='<span class="foot-note">Waiting for '+esc(w)+' at the IT desk.</span><span style="flex:1"></span>'+MSG+'<button class="a-btn a-btn--primary" type="button" id="rq-back">'+IC.back+'Mark returned to '+esc(w)+'</button>';
  }else if(r.st==="mgr"){
    foot='<span class="foot-note">Reaches you after '+esc(first(r.mgr))+' approves.</span><span style="flex:1"></span><button class="a-btn a-btn--secondary" type="button" id="rq-remind">'+IC.bell+'Remind '+esc(first(r.mgr))+'</button>';
  }else if(r.st==="proc"||r.st==="ceo"||r.st==="pay"){
    var who={proc:"Yahia Mohamad",ceo:"Waleed Al Aryan",pay:"Sabareesh Kumar"}[r.st];
    foot='<span class="foot-note">'+esc({proc:"With Procurement.",ceo:"Waiting for the CEO seal.",pay:"With Finance."}[r.st])+'</span><span style="flex:1"></span><button class="a-btn a-btn--secondary" type="button" id="rq-remind">'+IC.bell+'Remind '+esc(first(who))+'</button><button class="a-btn a-btn--secondary" type="button" id="rq-msg2">'+IC.chat+'Message '+esc(first(who))+'</button>';
  }else{
    foot='<span class="foot-note">This request is closed.</span><span style="flex:1"></span>'+MSG;
  }
  openDrawer('<code>'+esc(r.id)+'</code> '+esc(KIND[r.kind])+' request',body,foot);
  on("rq-msg",function(){msgTo(r.who,"Hi "+w+", about "+r.id+" ("+rTitle(r)+"): ")});
  var rw=r.st==="mgr"?r.mgr:{proc:"Yahia Mohamad",ceo:"Waleed Al Aryan",pay:"Sabareesh Kumar"}[r.st];
  if(rw){on("rq-remind",function(){r.events.push(["Reminder sent",nowStamp(),"IT reminded "+rw,"note"]);save();toast("Reminder sent to "+rw+".","success");openRequest(r,"timeline")});on("rq-msg2",function(){msgTo(rw,"Hi "+first(rw)+", about "+r.id+" ("+rTitle(r)+" for "+r.who+"): ")})}
  on("rq-nv",function(){confirmNotValid(r)});
  on("rq-issue",function(){confirmIssue(r)});
  on("rq-proc",function(){confirmProcurement(r)});
  on("rq-deliver",function(){confirmDeliver(r)});
  on("rq-repair",function(){r.st="repair";r.events.push(["In repair",nowStamp(),"Sent to the service centre by IT"]);var a=asset(r.assetId);if(a){a.status="In repair";addAssetEvent(a,"Sent for repair",r.id+" · service centre")}log("request",r.id+" sent for repair",r.id);refresh();openRequest(r);toast(r.id+" sent for repair.","success")});
  on("rq-ready",function(){r.st="ready";r.events.push(["Ready for collection",nowStamp(),"Back at the IT desk, Dubai office"]);log("request",r.id+" ready for collection",r.id);notifyPerson(r,"is ready for collection at the IT desk");refresh();openRequest(r);toast(w+" has been told it is ready.","success")});
  on("rq-back",function(){r.st="done";r.events.push(["Returned to "+r.who,nowStamp(),"Collected at the IT desk · card updated"]);var a=asset(r.assetId);if(a){a.status="Assigned";addAssetEvent(a,"Back from repair","Returned to "+r.who)}log("request",r.id+" returned to "+r.who,r.id);refresh();openRequest(r);toast(r.id+" closed. Device back with "+w+".","success")});
}
function notifyPerson(r,what){/* in the live app this emails the person, CC IT and the manager */}
function confirmNotValid(r){
  var dec=r.mgr&&r.events.some(function(e){return /approved and sent it to Admin/.test(e[2])});
  openTModal({tone:"err",icon:NO_IC,title:(dec?"Decline ":"Close ")+r.id+" as not valid?",text:first(r.who)+" gets an email with your reason"+(r.mgr?", with "+r.mgr+" copied":"")+". The request closes.",
    body:'<div><div class="rf-q">Reason <span class="req">*</span></div>'+pills("nv-r",["Duplicate request","Already has this kit","Not a business need","Other"])+'</div><div class="a-field"><label for="nv-note">Message to '+esc(first(r.who))+' <span class="a-help" id="nv-h">(optional)</span></label><textarea class="a-input" id="nv-note" maxlength="300" placeholder="What to do instead"></textarea><div class="err-t" data-err="nv-note" hidden>Add a short explanation when the reason is Other.</div></div>',
    yes:dec?"Decline request":"Close as not valid",onYes:function(){
      var c=radioVal("nv-r",$("#t-body"));var note=$("#nv-note").value.trim();$('[data-err="nv-r"]').hidden=!!c;if(!c)return;
      var other=c==="Other";$('[data-err="nv-note"]').hidden=!(other&&!note);if(other&&!note){$("#nv-note").focus();return}
      r.st="notvalid";r.note=(other?"":c)+(note?(other?"":" · ")+note:"");r.events.push([dec?"Declined by Admin":"Not valid",nowStamp(),r.note]);
      log("request",r.id+" closed as not valid · "+r.note,r.id);refresh();closeTModal();openRequest(r);toast(r.id+" closed. "+first(r.who)+" has been told.");
    },after:function(){$$('input[name="nv-r"]').forEach(function(rb){rb.addEventListener("change",function(){$('[data-err="nv-r"]').hidden=true;$("#nv-h").textContent=rb.value==="Other"?"(required)":"(optional)"})})}});
}
function confirmIssue(r){
  var st=rStock(r);
  var body=st.map(function(s){return '<div><div class="rf-q">'+esc(ITEM_LABEL[s.k])+' <span class="req">*</span></div><div class="klist" data-pick="'+s.k+'">'+s.list.slice(0,6).map(function(a,i){return '<button type="button" data-aid="'+a.id+'" class="'+(i===0?'on':'')+'">'+aArt(a,"xs")+'<span class="nm"><b>'+esc(a.id)+' · '+esc(a.name)+'</b><span>'+esc(a.serial||"No serial")+' · '+esc(a.loc)+'</span></span><span class="ck">'+TICK12+'</span></button>'}).join("")+'</div></div>'}).join("");
  openTModal({tone:"ok",icon:OK_IC,title:"Issue "+r.id+" from stock?",text:"The items go on "+r.who+"'s name and the request is delivered. Procurement and Finance are not emailed.",body:body,yes:"Issue from stock",
    after:function(){$$("#t-body [data-pick]").forEach(function(g){$$("button",g).forEach(function(b){b.addEventListener("click",function(){$$("button",g).forEach(function(x){x.classList.toggle("on",x===b)})})})})},
    onYes:function(){
      var ids=$$("#t-body [data-pick]").map(function(g){var b=$("button.on",g);return b?b.getAttribute("data-aid"):null}).filter(Boolean);
      ids.forEach(function(id){var a=asset(id);a.status="Assigned";a.holder=r.emp;addAssetEvent(a,"Issued to "+r.who,r.id+" · from stock in "+a.loc);log("assign",a.id+" ("+a.name+") issued to "+r.who+" from stock · "+r.id,a.id)});
      r.st="done";r.fromStock=true;r.issued=ids;r.events.push(["Issued from stock",nowStamp(),ids.join(", ")+" issued to "+r.who]);
      refresh();closeTModal();openRequest(r);toast(r.id+" delivered from stock: "+ids.join(", ")+".","success");
    }});
}
function confirmProcurement(r){
  openTModal({tone:"ok",icon:OK_IC,title:"Send "+r.id+" to Procurement?",text:"Mail goes To ymohamad@alphax.ae. Yahia quotes "+rTitle(r).toLowerCase()+", CEO Waleed seals one quotation, then Finance pays.",
    body:'<div class="a-field"><label for="pr-note">Note for Procurement <span class="a-help">(optional)</span></label><textarea class="a-input" id="pr-note" maxlength="300" placeholder="For example: same model as AST-0031, deliver to the Dubai office"></textarea></div>',
    yes:"Send to Procurement",onYes:function(){
      var note=$("#pr-note").value.trim();r.st="proc";if(note)r.note=note;
      r.events.push(["Approved by Admin",nowStamp(),(rAllInStock(r)?"Buy instead of stock":"No matching stock in "+r.office)+" · approved by "+ME.name]);
      r.events.push(["With procurement",nowStamp(),"To ymohamad@alphax.ae"+(note?" · “"+note+"”":"")]);
      log("request",r.id+" approved and sent to Procurement",r.id);refresh();closeTModal();openRequest(r);toast(r.id+" sent to Procurement.","success");
    }});
}
function confirmDeliver(r){
  var nid=nextId("AST-",S.assets);
  var body=r.items.map(function(k,i){return '<div class="a-field"><label for="dv-'+i+'">'+esc(ITEM_LABEL[k])+' serial <span class="req" style="color:var(--brand)">*</span></label><input class="a-input" id="dv-'+i+'" placeholder="From the sticker or the box"><div class="err-t" data-err="dv-'+i+'" hidden>Type the serial number.</div></div>'}).join("");
  openTModal({tone:"ok",icon:OK_IC,title:"Mark "+r.id+" delivered?",text:"The register adds "+(r.items.length>1?"each item":"it")+" from "+nid+" and issues it to "+r.who+".",body:body,yes:"Deliver and issue",focus:"#dv-0",onYes:function(){
    var ok=true,serials=r.items.map(function(k,i){var v=$("#dv-"+i).value.trim();var clash=serialClash(v);var e=$('[data-err="dv-'+i+'"]');if(!v){e.textContent="Type the serial number.";e.hidden=false;ok=false}else if(clash){e.textContent="Already on "+clash.id+". Serials cannot be reused.";e.hidden=false;ok=false}else e.hidden=true;return v});
    if(!ok)return;
    var ids=[];var parts=String(r.ref||"").split("+");
    r.items.forEach(function(k,i){var id=nextId("AST-",S.assets);ids.push(id);var nm=(parts[i]||parts[0]||ITEM_LABEL[k]).trim();
      var a={id:id,holder:r.emp,type:ITEM_TYPE[k],brand:nm.split(" ")[0],name:nm,model:"",serial:serials[i],status:"Assigned",loc:r.office,warranty:"",notes:"Bought on "+r.id+(r.vendor?" from "+r.vendor:""),events:[["Received",nowStamp(),"Delivered for "+r.id+(r.vendor?" · "+r.vendor:"")],["Identified as "+id,nowStamp(),"Type, brand and serial recorded"],["Issued to "+r.who,nowStamp(),r.id]]};
      S.assets.push(a);log("added",id+" ("+nm+") added and issued to "+r.who+" · "+r.id,id)});
    r.st="done";r.issued=ids;r.events.push(["Product delivered",nowStamp(),ids.join(", ")+" issued to "+r.who]);
    refresh();closeTModal();openRequest(r);toast(r.id+" delivered: "+ids.join(", ")+".","success");
  }});
}

/* ---------- assets ---------- */
function addAssetEvent(a,t,d){a.events=assetEvents(a).concat([[t,nowStamp(),d]])}
function assetEvents(a){
  if(a.events)return a.events;
  var h=holderName(a);
  var ev=[["Added to the register","9 Oct 2026 · 10:20","Imported from the Alpha X asset list · "+a.loc]];
  if(a.status==="In stock")ev.push(["Unassigned / in stock","9 Oct 2026 · 10:20",a.notes||"Spare, not in use"]);
  if(h)ev.push(["Assigned to "+h,"9 Oct 2026 · 10:20",a.holder]);
  if(a.status==="Returned")ev.push(["Returned to IT","14 Oct 2026 · 12:12","Off "+h+"'s name · waiting for a check"]);
  if(a.status==="In repair")ev.push(["Sent for repair","20 Oct 2026 · 11:00","REQ-0115 · Xiaomi service centre, Dubai"]);
  return ev;
}
function openAsset(id,startTab){
  var a=asset(id);if(!a)return;
  var p=a.holder?person(a.holder):null;var dup=serialClash(a.serial,a.id);
  var openReq=S.reqs.filter(function(r){return r.assetId===a.id&&!rClosed(r)})[0];
  var details=(dup?'<div class="rf-note" style="margin-bottom:16px">'+IC.warn.replace('<svg','<svg width="18" height="18"')+'<span>Serial <b>'+esc(a.serial)+'</b> is also on <b>'+esc(dup.id)+'</b>. Check the sticker and correct one of them.</span></div>':'')+
    (openReq?'<div class="asset-busy"><span><b>'+esc(KIND[openReq.kind])+' '+esc(openReq.id)+'</b> · '+esc(rLabel(openReq))+'</span><button class="a-btn a-btn--secondary a-btn--sm" type="button" id="as-req">Open request</button></div>':'')+
    '<dl class="dl">'+
    row("Held by",p&&a.status!=="Returned"?'<span style="display:inline-flex;align-items:center;gap:10px"><span class="av">'+initials(p.name)+'</span><span>'+esc(p.name)+'<br><span style="color:var(--fg-3);font-size:12px">'+esc(p.id)+' · '+esc(p.title||"")+(p.status==="Exited"?' · Exited':'')+'</span></span></span>':'<span style="color:var(--fg-3)">'+(a.status==="Retired"?"Retired":"Unassigned · stock in "+esc(a.loc))+'</span>')+
    row("Status",aTag(a))+row("Location",esc(a.loc))+row("Device type",esc(a.type))+row("Brand",dash(a.brand))+row("Model",dash(a.model||a.name))+
    row("Serial number",a.serial?'<code>'+esc(a.serial)+'</code>':'<span style="color:var(--fg-3)">Not on file</span>')+row("Warranty expiry",dash(a.warranty))+row("Extra / notes",dash(a.notes))+'</dl>';
  var fut=a.status==="Assigned"?[["Maintain","Repairs, warranty and location stay on this card"],["Reassign or retire","Return to stock, assign to someone else, or retire"]]:a.status==="In stock"?[["Issue to the next request","IT can deliver it without buying"]]:a.status==="Returned"?[["Check and move to stock","Or retire it if it cannot be used"]]:a.status==="In repair"?[["Back from repair","Returns to its holder or to stock"]]:[];
  var body='<div class="dhero">'+aArt(a,"lg")+'<div><h4>'+esc(a.name)+'</h4><p>'+esc(a.type)+(a.brand?' · '+esc(a.brand):'')+' · '+esc(a.loc)+'</p></div></div>'+tabs([["Details",details],["Timeline",timelineHtml(assetEvents(a),fut,a.status==="Retired")]],startTab==="timeline"?1:0);
  var del=CAN_DELETE?'<button class="a-btn a-btn--secondary" type="button" id="dr-del">'+IC.trash+'Delete</button>':'';
  var lbl='<button class="a-btn a-btn--ghost" type="button" id="dr-label">'+IC.label+'Label</button>';
  var acts={
    "Assigned":'<button class="a-btn a-btn--secondary" type="button" id="as-return">'+IC.back+'Return to stock</button><button class="a-btn a-btn--primary" type="button" id="as-assign">'+IC.swap+'Reassign</button>',
    "In stock":'<button class="a-btn a-btn--secondary" type="button" id="as-retire">Retire</button><button class="a-btn a-btn--primary" type="button" id="as-assign">'+IC.person+'Assign</button>',
    "Returned":'<button class="a-btn a-btn--secondary" type="button" id="as-retire">Retire</button><button class="a-btn a-btn--primary" type="button" id="as-stock">'+IC.box+'Move to stock</button>',
    "In repair":'<button class="a-btn a-btn--primary" type="button" id="as-fixed">'+IC.check+'Back from repair</button>',
    "Retired":''
  }[a.status];
  openDrawer('<code>'+a.id+'</code> '+esc(a.type),body,del+lbl+'<span style="flex:1"></span><button class="a-btn a-btn--secondary" type="button" id="as-edit">'+IC.edit+'Edit</button>'+acts);
  on("as-req",function(){openRequest(openReq)});
  on("dr-label",function(){toast("Label for "+a.id+" sent to the IT label printer queue.")});
  on("as-edit",function(){openAssetForm(a)});
  on("as-assign",function(){openPicker(a)});
  on("as-return",function(){openTModal({icon:IC.back.replace('<svg','<svg width="28" height="28"'),title:"Return "+a.id+" to stock?",text:"It comes off "+holderName(a)+"'s name and becomes a spare in "+a.loc+" that IT can issue to the next request.",yes:"Return to stock",onYes:function(){var h=holderName(a);a.status="In stock";a.holder="";addAssetEvent(a,"Returned to stock","Off "+h+"'s name · unassigned in "+a.loc);log("assign",a.id+" ("+a.name+") returned to stock from "+h,a.id);refresh();closeTModal();openAsset(a.id);toast(a.id+" is back in stock.","success")}})});
  on("as-stock",function(){a.status="In stock";a.holder="";addAssetEvent(a,"Moved to stock","Checked after return · unassigned in "+a.loc);log("assign",a.id+" ("+a.name+") checked and moved to stock",a.id);refresh();openAsset(a.id);toast(a.id+" moved to stock.","success")});
  on("as-retire",function(){openTModal({title:"Retire "+a.id+"?",text:"Recover the device and handle the data first. Retired items are not stock and stay on file with their history.",yes:"Retire",onYes:function(){a.status="Retired";a.holder="";addAssetEvent(a,"Retired","Recovered · data handled · not stock");log("change",a.id+" ("+a.name+") retired",a.id);refresh();closeTModal();openAsset(a.id);toast(a.id+" retired.")}})});
  on("as-fixed",function(){var h=a.holder;a.status=h?"Assigned":"In stock";addAssetEvent(a,"Back from repair",h?"Returned to "+holderName(a):"Back in stock");log("assign",a.id+" back from repair",a.id);refresh();openAsset(a.id);toast(a.id+" is back from repair.","success")});
  on("dr-del",function(){confirmDelete("asset",a.id,a.id+" · "+a.name,function(){S.assets=S.assets.filter(function(x){return x.id!==a.id})})});
}
function confirmDelete(kind,id,label,doIt){
  openTModal({title:"Delete "+id+"?",text:"Only Ultimate IT can delete. This removes "+label+" from the register for everyone. The last backup keeps a copy.",body:'<div class="a-field"><label for="del-ok">Type '+esc(id)+' to confirm</label><input class="a-input" id="del-ok" autocomplete="off" placeholder="'+esc(id)+'"><div class="err-t" data-err="del-ok" hidden>Type the ID exactly.</div></div>',yes:"Delete",focus:"#del-ok",onYes:function(){
    if($("#del-ok").value.trim().toUpperCase()!==id.toUpperCase()){$('[data-err="del-ok"]').hidden=false;return}
    doIt();log("delete",label+" deleted",id);refresh();closeTModal();closeDrawer();toast(id+" deleted.")}});
}
/* person picker: assign or reassign */
function openPicker(a){
  var sel=null;
  var body='<div class="rf-asset" style="margin-bottom:16px">'+aArt(a)+'<div style="min-width:0"><b>'+esc(a.name)+'</b><span>'+esc(a.id)+' · '+esc(a.serial||"No serial")+' · '+esc(a.loc)+'</span></div></div><div class="pick-srch"><label class="tsearch" style="max-width:none;flex:none;width:100%"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg><span class="sr">Search people</span><input class="a-input" type="search" id="pk-q" placeholder="Search people on file"></label></div><div class="klist" id="pk-list"></div>';
  openDrawer((a.holder?'Reassign ':'Assign ')+'<code>'+a.id+'</code>',body,'<button class="a-btn a-btn--secondary" type="button" id="pk-back">Back</button><span style="flex:1"></span><button class="a-btn a-btn--primary" type="button" id="pk-go" disabled>Choose a person</button>');
  function draw(){var q=$("#pk-q").value.trim();var list=S.people.filter(function(p){return p.status==="Active"&&p.id!==a.holder&&matchQ(q,[p.name,p.id,p.title])});
    $("#pk-list").innerHTML=list.map(function(p){return '<button type="button" data-pid="'+p.id+'" class="'+(sel===p.id?'on':'')+'"><span class="av">'+initials(p.name)+'</span><span class="nm"><b>'+esc(p.name)+'</b><span>'+esc(p.id)+' · '+esc(p.title||"No job title")+' · '+esc(p.loc)+' · '+plural(kitOf(p.id).length,"asset")+'</span></span><span class="ck">'+TICK12+'</span></button>'}).join("")||'<div class="none">Nobody matches.</div>';
    $$("#pk-list [data-pid]").forEach(function(b){b.addEventListener("click",function(){sel=b.getAttribute("data-pid");draw();var p=person(sel);var g=$("#pk-go");g.disabled=false;g.innerHTML=IC.check+"Assign to "+esc(first(p.name))})})}
  $("#pk-q").addEventListener("input",draw);draw();
  on("pk-back",function(){openAsset(a.id)});
  on("pk-go",function(){if(!sel)return;var p=person(sel);var was=holderName(a);a.holder=p.id;a.status="Assigned";if(p.loc)a.loc=p.loc;addAssetEvent(a,"Assigned to "+p.name,was?"Moved from "+was:"Issued from stock");log("assign",a.id+" ("+a.name+") assigned to "+p.name+(was?" (was "+was+")":" from stock"),a.id);refresh();openAsset(a.id);toast(a.id+" assigned to "+p.name+".","success")});
}
function fld(id,label,val,o){o=o||{};return '<div class="a-field"'+(o.hide?' hidden':'')+' id="w-'+id+'"><label for="'+id+'">'+label+(o.req?' <span style="color:var(--brand)">*</span>':'')+(o.opt?' <span class="a-help">(optional)</span>':'')+'</label>'+(o.area?'<textarea class="a-input" id="'+id+'" placeholder="'+esc(o.ph||"")+'">'+esc(val||"")+'</textarea>':'<input class="a-input" id="'+id+'" type="'+(o.type||"text")+'" value="'+esc(val||"")+'" placeholder="'+esc(o.ph||"")+'"'+(o.ro?' readonly':'')+'>')+(o.help?'<span class="a-help">'+o.help+'</span>':'')+'<div class="err-t" data-err="'+id+'" hidden>'+esc(o.err||"Required.")+'</div></div>'}
function radioField(name,label,opts,val,req){return '<div><div class="rf-q">'+label+(req?' <span class="req">*</span>':'')+'</div>'+pills(name,opts,val)+'</div>'}
function isoOf(label){var d=new Date(label);if(!label||isNaN(d))return "";return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0")}
function formErr(id,show,msg){var e=$('[data-err="'+id+'"]');if(e){if(msg)e.textContent=msg;e.hidden=!show}return !show}
function openAddStock(){openAssetForm(null)}
function openAssetForm(a){
  var edit=!!a;var nid=edit?a.id:nextId("AST-",S.assets);
  var body='<form class="rf" id="af" novalidate>'+(edit?'':'<div class="rf-note info">'+IC.info.replace('<svg','<svg width="18" height="18"')+'<span>No person needed. It shows as In stock until you issue it from its card or a request.</span></div>')+
    '<div class="frow">'+fld("af-id","Asset ID",nid,{ro:true})+fld("af-name","What is it",edit?a.name:"",{req:true,ph:"e.g. Logitech M185 mouse, Dell 24-inch monitor",err:"Say what it is."})+'</div>'+
    radioField("af-type","Device type",TYPES,edit?a.type:"",true)+
    radioField("af-loc","Location",["Dubai","Uganda"],edit?a.loc:"Dubai",true)+
    '<div class="frow">'+fld("af-brand","Brand",edit?a.brand:"",{ph:"e.g. Dell, Logitech"})+fld("af-model","Model",edit?a.model:"",{opt:true})+'</div>'+
    '<div class="frow">'+fld("af-serial","Serial number",edit?a.serial:"",{ph:"From the sticker",help:"Serials cannot be reused across assets."})+fld("af-war","Warranty expiry",edit?isoOf(a.warranty):"",{type:"date",opt:true})+'</div>'+
    fld("af-notes","Extra / notes",edit?a.notes:"",{area:true,opt:true,ph:"Condition, box, accessories"})+'</form>';
  openDrawer(edit?'Edit <code>'+a.id+'</code>':'Add to stock',body,'<button class="a-btn a-btn--secondary" type="button" id="af-cancel">'+(edit?'Back':'Cancel')+'</button><span style="flex:1"></span><button class="a-btn a-btn--primary" type="button" id="af-save">'+(edit?'Save changes':IC.plus+'Add to stock')+'</button>');
  on("af-cancel",function(){if(edit)openAsset(a.id);else closeDrawer()});
  $$('#af input[type=radio]').forEach(function(rb){rb.addEventListener("change",function(){var e=$('[data-err="'+rb.name+'"]');if(e)e.hidden=true})});
  on("af-save",function(){
    var f=$("#af");var name=$("#af-name").value.trim(),type=radioVal("af-type",f),loc=radioVal("af-loc",f),serial=$("#af-serial").value.trim();
    var ok=formErr("af-name",!name)&formErr("af-type",!type)&formErr("af-loc",!loc);
    var clash=serialClash(serial,edit?a.id:null);ok=formErr("af-serial",!!clash,clash?"Already on "+clash.id+". Serials cannot be reused.":"")&&ok;
    if(!ok){var e=$('.err-t:not([hidden])',f);if(e)e.scrollIntoView({behavior:"smooth",block:"center"});return}
    var war=$("#af-war").value;var v={name:name,type:type,loc:loc,brand:$("#af-brand").value.trim(),model:$("#af-model").value.trim(),serial:serial,warranty:war?fmtISO(war):"",notes:$("#af-notes").value.trim()};
    if(edit){Object.keys(v).forEach(function(k){a[k]=v[k]});addAssetEvent(a,"Card updated","Edited by "+ME.name);log("change",a.id+" ("+a.name+") updated",a.id);refresh();openAsset(a.id);toast(a.id+" saved.","success")}
    else{var n={id:nid,holder:"",status:"In stock",events:[["Received into stock",nowStamp(),"Checked serial and condition · "+loc],["Identified as "+nid,nowStamp(),"Type, brand and serial recorded"]]};Object.keys(v).forEach(function(k){n[k]=v[k]});S.assets.push(n);log("added",nid+" ("+name+") added to the register · unassigned / in stock",nid);refresh();openAsset(nid);toast(nid+" added to stock in "+loc+".","success")}
  });
}
$$('[data-act="add-stock"]').forEach(function(b){b.addEventListener("click",openAddStock)});
$("#asset-export").addEventListener("click",function(){var rows=[["Asset ID","Item","Type","Brand","Model","Serial","Status","Held by","Employee ID","Location","Warranty","Notes"]].concat(S.assets.map(function(a){return [a.id,a.name,a.type,a.brand,a.model,a.serial,a.status,holderName(a),a.holder,a.loc,a.warranty,a.notes]}));download("alphax-assets-"+todayISO()+".csv","﻿"+csv(rows),"text/csv","Asset report saved. It opens in Excel.")});
$("#kit-export").addEventListener("click",function(){var rows=[["Person","Employee ID","Location","Items","Asset details"]].concat(S.people.map(function(p){var k=kitOf(p.id);return [p.name,p.id,p.loc,k.length,k.map(function(a){return a.type+" "+a.id+(a.serial?" · "+a.serial:"")}).join("; ")]}));download("alphax-kit-report-"+todayISO()+".csv","﻿"+csv(rows),"text/csv","Kit report saved. It opens in Excel.")});

/* ---------- people ---------- */
function personEvents(p){
  var ev=[["Added to People",p.joined||"9 Oct 2026 · 10:20",p.id+(p.title?" · "+p.title:"")]];
  S.activity.filter(function(e){return e.ref===p.id}).slice().reverse().forEach(function(e){if(!/added to People/.test(e.t))ev.push([e.t,e.at,e.by])});
  kitOf(p.id).forEach(function(a){ev.push(["Holds "+a.id,"",a.name])});
  if(p.status==="Exited")ev.push(["Exited",p.exitDate||"—",kitOf(p.id).length?"Kit still on their name":"No kit on their name"]);
  return ev;
}
function openPerson(id,startTab){
  var p=person(id);if(!p)return;var k=kitOf(p.id);
  var reqs=S.reqs.filter(function(r){return r.emp===p.id});
  var details=(p.status==="Exited"&&k.length?'<div class="rf-note" style="margin-bottom:16px">'+IC.warn.replace('<svg','<svg width="18" height="18"')+'<span>'+esc(first(p.name))+' has left but '+plural(k.length,"asset")+' '+(k.length===1?"is":"are")+' still on their name. Return '+(k.length===1?"it":"them")+' to stock.</span></div>':'')+
    '<dl class="dl">'+row("Employee ID",'<code>'+esc(p.id)+'</code>')+row("Job title",dash(p.title))+row("Department",dash(p.dept))+row("Location",esc(p.loc))+row("Manager",dash(p.mgr))+
    row("Work email",p.email?esc(p.email):'<span style="color:var(--fg-3)">No official email · cannot sign in</span>')+row("Phone",dash(p.phone))+row("Desk",esc(deskOf(p)))+row("Status",pTag(p))+row("Notes",dash(p.notes))+'</dl>';
  var kit=(k.length?'<div class="klist">'+k.map(function(a){return '<button type="button" data-k="asset:'+a.id+'">'+aArt(a,"xs")+'<span class="nm"><b>'+esc(a.id)+' · '+esc(a.name)+'</b><span>'+esc(a.type)+' · '+esc(a.serial||"No serial")+'</span></span>'+aTag(a)+'<span class="go">'+IC.chev+'</span></button>'}).join("")+'</div>':'<div class="klist"><div class="none">No kit on '+esc(first(p.name))+'\'s name.</div></div>')+
    (reqs.length?'<div class="dsub">Requests</div><div class="klist">'+reqs.map(function(r){return '<button type="button" data-k="req:'+r.id+'">'+art(rArtType(r),"xs",r.title)+'<span class="nm"><b>'+esc(r.id)+' · '+esc(rTitle(r))+'</b><span>'+esc(KIND[r.kind])+' · '+esc(r.date)+'</span></span>'+rTag(r)+'<span class="go">'+IC.chev+'</span></button>'}).join("")+'</div>':'');
  var body='<div class="dhero"><span class="av" style="width:56px;height:56px;font-size:20px">'+initials(p.name)+'</span><div><h4>'+esc(p.name)+'</h4><p>'+esc(p.title||"No job title")+' · '+esc(p.loc)+'</p></div></div>'+tabs([["Details",details],["Kit ("+k.length+")",kit],["Timeline",timelineHtml(personEvents(p),[],true)]],startTab==="kit"?1:0);
  var del=CAN_DELETE?'<button class="a-btn a-btn--secondary" type="button" id="dr-del">'+IC.trash+'Delete</button>':'';
  var foot=del+'<span style="flex:1"></span>'+(p.status==="Exited"&&k.length?'<button class="a-btn a-btn--secondary" type="button" id="pp-edit">'+IC.edit+'Edit</button><button class="a-btn a-btn--primary" type="button" id="pp-retall">'+IC.back+'Return all kit</button>':
    (p.status==="Exited"?'<button class="a-btn a-btn--secondary" type="button" id="pp-restore">Restore as active</button>':'<button class="a-btn a-btn--secondary" type="button" id="pp-exit">'+IC.exit+'Mark as exited</button>')+(p.email&&p.status==="Active"?'<button class="a-btn a-btn--secondary" type="button" id="pp-msg">'+IC.chat+'Message</button>':'')+'<button class="a-btn a-btn--primary" type="button" id="pp-edit">'+IC.edit+'Edit</button>');
  openDrawer('<code>'+esc(p.id)+'</code> Person',body,foot);
  bindK($("#dr-body"));
  on("pp-edit",function(){openPersonForm(p)});
  on("pp-msg",function(){msgTo(p.name,"Hi "+first(p.name)+", ")});
  on("pp-exit",function(){openTModal({icon:IC.exit.replace('<svg','<svg width="28" height="28"'),title:"Mark "+p.name+" as exited?",text:k.length?"Their "+plural(k.length,"asset")+" stay on their name until you return "+(k.length===1?"it":"them")+" to stock.":"They stay on People as Exited. They can no longer sign in.",
    body:'<div class="a-field"><label for="ex-d">Exit date</label><input class="a-input" type="date" id="ex-d" value="'+todayISO()+'"></div>',yes:"Mark as exited",onYes:function(){p.status="Exited";p.exitDate=fmtISO($("#ex-d").value)||today();log("person",p.id+" ("+p.name+") marked as exited ("+p.exitDate+")",p.id);refresh();closeTModal();openPerson(p.id);toast(p.name+" marked as exited.")}})});
  on("pp-restore",function(){p.status="Active";log("person",p.id+" ("+p.name+") restored as active",p.id);refresh();openPerson(p.id);toast(p.name+" is active again.","success")});
  on("pp-retall",function(){openTModal({icon:IC.back.replace('<svg','<svg width="28" height="28"'),title:"Return "+plural(k.length,"asset")+" to stock?",text:k.map(function(a){return a.id}).join(", ")+" come off "+p.name+"'s name and wait for a check before they go back to stock.",yes:"Return to IT",onYes:function(){k.forEach(function(a){a.status="Returned";addAssetEvent(a,"Returned to IT","Collected from "+p.name+" (exited) · waiting for a check");log("assign",a.id+" ("+a.name+") collected from "+p.name,a.id)});refresh();closeTModal();openPerson(p.id);toast(plural(k.length,"asset")+" collected from "+first(p.name)+".","success")}})});
  on("dr-del",function(){if(k.length){toast("Return "+first(p.name)+"'s kit first. Delete only works with no kit on their name.","error");return}confirmDelete("person",p.id,p.name,function(){S.people=S.people.filter(function(x){return x.id!==p.id})})});
}
function openPersonForm(p){
  var edit=!!p;var nid=edit?p.id:nextId("EMP-",S.people.filter(function(x){return /^EMP-\d{4}$/.test(x.id)}));
  var body='<form class="rf" id="pf" novalidate><div class="frow">'+fld("pf-name","Full name",edit?p.name:"",{req:true,err:"Type the full name."})+fld("pf-id","Employee ID",nid,{ro:true})+'</div>'+
    '<div class="frow">'+fld("pf-title","Job title",edit?p.title:"")+fld("pf-dept","Department / team",edit?p.dept:"",{ph:"Development, Account, Business, Legal, Management office or IT"})+'</div>'+
    radioField("pf-loc","Location",["Dubai","Uganda"],edit?p.loc:"Dubai",true)+
    radioField("pf-mgr","Manager",MANAGERS.concat(["No manager"]),edit?(p.mgr||"No manager"):"",true)+
    '<div class="frow">'+fld("pf-email","Work email",edit?p.email:"",{ph:"Leave blank if they have no official email",help:"Only @alphax.ae. Without one they stay on People but cannot sign in.",err:"Use an @alphax.ae address."})+fld("pf-phone","Phone",edit?p.phone:"",{opt:true})+'</div>'+
    '<div class="frow">'+fld("pf-join","Join date",edit?isoOf(p.joined):todayISO(),{type:"date"})+'<div></div></div>'+
    fld("pf-notes","Notes",edit?p.notes:"",{area:true,opt:true})+'</form>';
  openDrawer(edit?'Edit <code>'+p.id+'</code>':'Add person',body,'<button class="a-btn a-btn--secondary" type="button" id="pf-cancel">'+(edit?'Back':'Cancel')+'</button><span style="flex:1"></span><button class="a-btn a-btn--primary" type="button" id="pf-save">'+(edit?'Save changes':IC.plus+'Save person')+'</button>');
  on("pf-cancel",function(){if(edit)openPerson(p.id);else closeDrawer()});
  on("pf-save",function(){
    var f=$("#pf");var name=$("#pf-name").value.trim(),email=$("#pf-email").value.trim().toLowerCase(),loc=radioVal("pf-loc",f),mgr=radioVal("pf-mgr",f);
    var ok=formErr("pf-name",!name)&formErr("pf-email",!!email&&!/@alphax\.ae$/.test(email))&formErr("pf-loc",!loc)&formErr("pf-mgr",!mgr);
    if(!ok)return;
    var v={name:name,title:$("#pf-title").value.trim(),dept:$("#pf-dept").value.trim(),loc:loc,mgr:mgr==="No manager"?"":mgr,email:email,phone:$("#pf-phone").value.trim(),joined:$("#pf-join").value?fmtISO($("#pf-join").value):"",notes:$("#pf-notes").value.trim()};
    if(edit){Object.keys(v).forEach(function(k){p[k]=v[k]});log("person",p.id+" ("+p.name+") updated",p.id);refresh();openPerson(p.id);toast(p.name+" saved.","success")}
    else{var n={id:nid,status:"Active"};Object.keys(v).forEach(function(k){n[k]=v[k]});S.people.push(n);log("person",nid+" ("+name+") added to People",nid);refresh();openPerson(nid);toast(name+" added to People.","success")}
  });
}
$$('[data-act="add-person"]').forEach(function(b){b.addEventListener("click",function(){openPersonForm(null)})});
