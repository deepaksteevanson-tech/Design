# Instructions for AI coding agents (Cursor, Claude Code, Copilot)

You are working on the **AlphaX Admin portal**: one self-contained page built from `src/` by `scripts/build.mjs`.

1. Read `docs/DESIGN-RULES.md` before any UI change, and `docs/DATA-MODEL-AND-API.md` before any data change.
2. Never edit `src/styles/alphax-portal.css` (shared with the Asset App). Put new CSS at the end of `src/styles/admin.css`, using only DS tokens.
3. JS files in `src/js/` are concatenated in name order into one IIFE. Top-level names are shared; there are no imports. Plain ES5-style functions, `var`, string-built HTML with `esc()` for every value.
4. Every user-visible value goes through `esc()`. Every data change ends in `refresh()` and usually `log()`.
5. New table: `thead(tid, cols)` + `sortBy` + `RENDER[tid]=fn`, rows `class="row" tabindex="0" data-open="type:id"` and add the type to `openRow` in 04-shell.js.
6. New popup: `openDrawer(title, body, foot)` with `tabs([["Details",…],["Timeline",…]])`; confirmations via `openTModal`.
7. Check with `npm run dev` at 390, 820, 1440 and 1920 widths, light and dark; run `npm test` when Playwright is installed. No sideways page scroll, no console errors.
8. Sentence case, short plain copy. Keep tile subtexts ≈45 characters.
