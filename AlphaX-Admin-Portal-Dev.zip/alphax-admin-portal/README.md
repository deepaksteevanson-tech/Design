# AlphaX Admin portal

The admin desk of the AlphaX IT asset register (**IT · Ultimate**, signed in as Deepak Steevanson).
It looks and behaves exactly like the user/manager **Asset App** and is built only from the **Alpha Design System**.

- Live preview (private): https://claude.ai/artifact/AyJXiUjvyT2HUVGSMzB4df (version 9, 27 Oct 2026)
- Sibling user/manager portal: https://claude.ai/artifact/JEDBwjU9UrBaGxSjpdMLhM
- Alpha DS reference: https://claude.ai/artifact/CxdC2JkuSMeSzN5hArRcWp

This package is the same code as the live preview, split into readable source files.

## Quick start (Cursor or any editor)

```bash
npm run dev        # http://localhost:5173 — rebuilds and reloads on every save
npm run build      # writes dist/index.html (+ dist/artifact.html for claude.ai)
```

Node 18+ only. There are **no dependencies** to install. You can also open `dist/index.html` straight in a browser.

Optional smoke test (Playwright, checks every page at 390 / 820 / 1440 / 1920 in light and dark, and the main flows):

```bash
npm run test:install   # once
npm test
```

## Project layout

```
src/
  partials/head.html        <title>, fonts, theme + density pre-paint script
  partials/body.html        all markup: header, 9 views, popup, modal, floating buttons, dock
  styles/alphax-portal.css  shared Asset App stylesheet (Alpha DS tokens + components) — DO NOT EDIT
  styles/admin.css          admin-only rules, appended after the shared sheet
  js/01-core.js             helpers ($, $$, esc, store), icons (IC), device art (ART/art), ME
  js/02-seed-data.js        people, assets, infrastructure from the live register (26 Oct 2026)
  js/03-state.js            seed(), state S + persistence, lookups, request status model
  js/04-shell.js            theme, density, toasts, notifications, routing, popup, modal, tables, tiles
  js/05-pages.js            page renderers: Overview, Requests, Assets, People, Joiners, Infra, Reports
  js/06-requests-assets-people.js   popups and actions for requests, assets, people
  js/07-joiners-infra-backup.js     popups and actions for joiners, infrastructure, backups
  js/08-settings.js         Settings pages (desks, vendors, inboxes, mailbox, Google, team address)
  js/09-help-modules.js     Help & Support content + diagrams (copied from the Asset App)
  js/10-ask-messages-boot.js  Ask the register, Messages, sign-in, floating-button sync, boot
public/                     cover.jpg (banner photo), alphax-logo.png
scripts/build.mjs           concatenates everything into one self-contained page
scripts/dev.mjs             zero-dependency dev server with live reload
tests/smoke.mjs             Playwright smoke test
docs/                       design handoffs, rules, data model and API wiring guide
```

**How the JS fits together:** the build concatenates `src/js/*.js` in file-name order inside one IIFE with `"use strict"`. Every top-level `function` / `var` is shared across files (no imports). Keep that in mind when naming things, and keep the numeric prefixes so the order stays right (data before state, state before pages, boot last).

## Pages (hash routes)

| Route | Page | What an admin does there |
|---|---|---|
| `#home` | Overview | Tiles, requests waiting for you, live checks (reused serials, leavers with kit, missing spares, returns, missing serials), fleet by type, recent activity. Banner button: Add to stock |
| `#requests` | Requests | Issue from stock · Send to Procurement · Not valid / Decline · Mark delivered and issue · Service: repair → ready → returned |
| `#assets` | Assets | Add to stock, assign/reassign, return, move to stock, retire, back from repair, edit, label, delete; Excel (CSV) export |
| `#people` | People | Add/edit, mark exited/restore, return all kit, delete (only with no kit) |
| `#joiners` | New joiners | HR add newbee → manager kit → **IT allocates spares or serials, marks ready** → employee signs → joined |
| `#infra` | Infrastructure | Rooms, floors, Wi-Fi, servers, circuits |
| `#reports` | Reports | People kit report (CSV), activity log, backup now, restore from file, reset demo data |
| `#settings` | Settings (profile menu only) | Desks and access, vendor book, notice addresses, sending mailbox, Google sign-in, team address |
| `#help` | Help & Support (profile menu) | 16 process topics with diagrams |
| `#signin` | Sign in | Design preview of the admin sign-in |

## Rules that must not break

Read `docs/DESIGN-RULES.md` before changing UI. In short: Alpha DS tokens only, fills not strokes, same banner on every page, lists are tables, "All" filter first, sortable headers, tiles with live numbers and 2-line subtext, black-and-white device art, sparing brand colour, 780px popups with Details | Timeline, sentence case, works at 390 / 820 / 1440 / 1920 in light and dark.

## Wiring to the live register

Everything runs on demo data in `localStorage` (`ax-admin-v1`). `docs/DATA-MODEL-AND-API.md` lists every record shape and every action that changes data, so each one can be pointed at the live app's `/api/*`.

## Publishing back to claude.ai

`npm run build`, then publish `dist/artifact.html` with `cover.jpg` to the existing artifact URL above (the host adds the document skeleton). Keep the `downloads` capability.
