// Smoke test: every page at phone, tablet and desktop widths, light and dark, compact density,
// plus the main admin flows. Fails on page errors or sideways page scroll.
// One-time setup: npm run test:install     Run: npm test
import { chromium } from "playwright";
import { mkdirSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const url = "file://" + join(root, "dist", "index.html");
const out = join(root, "tests", "output"); mkdirSync(out, { recursive: true });
const VIEWS = ["home", "requests", "assets", "people", "joiners", "infra", "reports", "settings", "help"];
const problems = [];
const browser = await chromium.launch();

for (const [w, h] of [[390, 844], [820, 1180], [1440, 900], [1920, 1080]]) {
  for (const theme of ["light", "dark"]) {
    const ctx = await browser.newContext({ viewport: { width: w, height: h } });
    await ctx.addInitScript(([t, d]) => { localStorage.setItem("ax-theme", JSON.stringify(t)); localStorage.setItem("ax-density", JSON.stringify(d)); }, [theme, w === 1920 ? "compact" : "default"]);
    const page = await ctx.newPage();
    page.on("pageerror", (e) => problems.push(`${w} ${theme}: ${e.message}`));
    await page.goto(url);
    for (const v of VIEWS) {
      await page.evaluate((v) => (location.hash = v), v);
      await page.waitForTimeout(150);
      const over = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
      if (over > 0) problems.push(`${w} ${theme} #${v}: page scrolls sideways by ${over}px`);
      if (theme === "light") await page.screenshot({ path: join(out, `${w}-${v}.png`), fullPage: false });
    }
    await ctx.close();
  }
}

// flows on desktop
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
page.on("pageerror", (e) => problems.push(`flow: ${e.message}`));
await page.goto(url);
const step = async (name, fn) => { try { await fn(); } catch (e) { problems.push(`flow "${name}": ${e.message.split("\n")[0]}`); } };
await step("issue from stock", async () => {
  await page.evaluate(() => (location.hash = "requests")); await page.waitForTimeout(150);
  await page.click('.view.on tr[data-open="req:REQ-0120"]'); await page.click("#rq-issue"); await page.click("#t-yes"); await page.click("#dr-close");
});
await step("send to procurement", async () => {
  await page.click('.view.on tr[data-open="req:REQ-0116"]'); await page.click("#rq-proc"); await page.click("#t-yes"); await page.click("#dr-close");
});
await step("add to stock", async () => {
  await page.evaluate(() => (location.hash = "assets")); await page.waitForTimeout(150);
  await page.click('.view.on [data-act="add-stock"]'); await page.fill("#af-name", "Test mouse"); await page.click('input[name="af-type"][value="Mouse"]');
  await page.fill("#af-serial", "SMOKE-" + Date.now()); await page.click("#af-save"); await page.click("#dr-close");
});
await step("joiner ready and joined", async () => {
  await page.evaluate(() => (location.hash = "joiners")); await page.waitForTimeout(150);
  await page.click('.view.on tr[data-open="join:JOIN-0002"]');
  for (const k of ["keyboard", "mouse"]) { const el = await page.$(`[data-serial="${k}"]`); if (el && await el.isVisible()) await el.fill("SMOKE-" + k + Date.now()); }
  await page.click("#jn-ready"); await page.click("#jn-join"); await page.click("#t-yes"); await page.click("#dr-close");
});
await step("floating buttons", async () => {
  await page.click("#ask-btn"); if (!(await page.getAttribute("#ask-btn", "class")).includes("open")) throw new Error("Ask did not open");
  await page.click("#msg-btn"); if ((await page.getAttribute("#ask-btn", "class")).includes("open")) throw new Error("Ask did not close");
});
await browser.close();

if (problems.length) { console.error("Smoke test found problems:\n- " + problems.join("\n- ")); process.exit(1); }
console.log(`Smoke test passed. Screenshots in tests/output/`);
