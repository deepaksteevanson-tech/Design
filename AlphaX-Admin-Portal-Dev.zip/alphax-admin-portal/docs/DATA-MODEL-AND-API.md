# Data model and API wiring

All state lives in one object `S` (`src/js/03-state.js`), saved to `localStorage["ax-admin-v1"]` by `save()`.
`seed()` builds the demo state from `src/js/02-seed-data.js` (real register export, 26 Oct 2026) plus marked sample records.
Every action that changes data ends with `refresh()` (= `save()` + `renderAll()`), and most also call `log(kind, text, ref)` to add to the activity log.

## State shape

```js
S = {
  v: 1,
  people:   [Person],
  assets:   [Asset],
  infra:    [Infra],
  reqs:     [Request],
  joiners:  [Joiner],
  activity: [Activity],      // newest first
  vendors:  [Vendor],
  settings: Settings,
  backups:  [Backup],        // newest first
  saved: "26 Oct 2026 · 09:26"
}
```

| Record | Fields |
|---|---|
| **Person** | `id` (EMP-…), `name`, `title`, `dept`, `loc` ("Dubai" / "Uganda"), `mgr` (name or ""), `email` (@alphax.ae or ""), `status` ("Active" / "Exited"), `phone`, `joined`, `exitDate?`, `notes` |
| **Asset** | `id` (AST-…), `holder` (EMP id or ""), `type` (Laptop, Monitor, Keyboard, Mouse, Tablet, Phone, Headset, Webcam, Accessory, Storage, Other), `brand`, `name`, `model`, `serial` (unique), `status` ("Assigned" / "In stock" / "Returned" / "In repair" / "Retired"), `loc`, `warranty`, `notes`, `events` ([title, stamp, detail] or null → generated) |
| **Request** | `id` (REQ-…), `who`, `emp`, `kind` ("kit" / "replacement" / "service"), `items` (keys of `ITEMS`), `other?`, `title?`, `assetId?`, `issue?`, `ref`, `reason`, `files`, `cost`, `needBy`, `date`, `office`, `mgr` (name or null), `st` (see below), `fromStock?`, `issued?` ([AST ids]), `vendor?`, `note?`, `sample?`, `events` |
| **Joiner** | `id` (JOIN-…), `name`, `pos`, `dept`, `mgr`, `loc`, `from` ("Office" / "Home"), `start`, `email`, `kit` (item keys), `st` ("hr" / "mgr" / "it" / "sign" / "joined"), `alloc` ({itemKey: AST id or serial}), `emp?`, `issued?`, `events` |
| **Infra** | `id` (INF-…), `name`, `type` (Office, Floor, Room, Network, Wi-Fi, Server, Circuit), `site`, `city`, `host`, `ip`, `status` ("In service" / "Planned" / "Down"), `owner`, `notes` |
| **Activity** | `k` (added, assign, request, joiner, person, change, delete, backup), `t` (text), `at`, `ref`, `by` |
| **Vendor** | `id` (VEN-…), `name`, `pay` (Cash / Account transfer / Payment link), `payTo`, `notes` |
| **Settings** | `team` (URL), `inbox` {hr, it, proc, fin, ceo, anna, mike, spiros}, `smtp` {host, port, login, sendAs, saved}, `google` (client ID), `desks` {personName: desk} |
| **Backup** | `f` (file name), `at`, `by`, `size` |

### Request status `st` (admin view, `RST` in 03-state.js)
`mgr` With manager → `you` Waiting for you → (`proc` With procurement → `ceo` Waiting for CEO approval → `pay` Waiting for payment → `delivery` Waiting for delivery) → `done` Delivered.
Service: `you` → `repair` In repair → `ready` Ready for collection → `done` Returned.
Closed: `done`, `notvalid`, `declined`. "Needs you" = `you`, `delivery`, `ready`.
Stock checks are per office: `stockFor(type, office)` only counts `In stock` assets at that office.

## Where to connect the live API

Load: replace the `S=store(KEY)` / `seed()` start-up in `03-state.js` with a fetch of the register, then call `renderAll()`.
Save: each action below is the single place a change happens. Swap the local mutation for an API call (then `refresh()` on success, `toast(..., "error")` on failure).

| Action | Function (file) | Changes |
|---|---|---|
| Issue request from stock | `confirmIssue` (06) | assets → Assigned to requester; request → done, `issued` |
| Send to Procurement | `confirmProcurement` (06) | request → proc; mail To ymohamad@alphax.ae |
| Not valid / Decline | `confirmNotValid` (06) | request → notvalid with reason |
| Mark delivered and issue | `confirmDeliver` (06) | new assets (serials) assigned; request → done |
| Service: send for repair / ready / returned | `rq-repair` / `rq-ready` / `rq-back` handlers in `openRequest` (06) | request + asset status |
| Remind manager / Procurement / CEO / Finance | `rq-remind` in `openRequest` (06) | note event (send email in live app) |
| Assign / reassign asset | `openPicker` → `pk-go` (06) | asset.holder, status Assigned |
| Return to stock / move to stock / retire / back from repair | `as-*` handlers in `openAsset` (06) | asset.status |
| Add to stock / edit asset | `openAssetForm` (06) | new or updated asset (serial uniqueness via `serialClash`) |
| Delete asset / person / infra / vendor | `confirmDelete` (06) | removes record (Ultimate only) |
| Add / edit person | `openPersonForm` (06) | person |
| Mark exited / restore / return all kit | `pp-exit` / `pp-restore` / `pp-retall` in `openPerson` (06) | person.status; assets → Returned |
| HR add newbee / edit joiner | `openJoinerForm` (07) | joiner (→ mgr) |
| Joiner: send to manager / remind | `jn-send` / `jn-remind` in `openJoiner` (07) | joiner.st |
| Joiner: mark ready (IT) | `jn-ready` in `openJoiner` (07) | new person (EMP id), assets assigned, signing link emailed |
| Joiner: signed, mark joined | `jn-join` in `openJoiner` (07) | joiner.st = joined |
| Add / edit infrastructure | `openInfraForm` (07) | infra |
| Back up now / restore / reset | `backupNow`, `#bk-file` handler, `bk-reset` (07) | backups (server writes data/backups) |
| Desks, vendors, inboxes, mailbox, Google, team address | `openDesk`, `openVendorForm`, forms in `showSet` (08) | settings, vendors |

Downloads (CSV/JSON) use `download()` in 04-shell.js: in a claude.ai artifact they go through the `downloads` capability; on a normal site they fall back to a browser download.

## Demo-only parts to replace
- `ME` / `CAN_DELETE` in 01-core.js → the signed-in user and desk from the session.
- Notifications (`NOTIFS` in 04-shell.js) and Messages threads (`seeded` in 10) are sample content.
- Sign-in (`#signin`) only validates the email shape and desk; real auth is the live app's.
