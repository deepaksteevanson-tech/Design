# Design rules (agreed with Jerrin) — Admin portal

Source of truth: the Asset App (`docs/ADMIN-PORTAL-HANDOFF.md`, `docs/asset-app-site-notes.md`) and the Alpha DS.

## Tokens and colour
- Use only the CSS custom properties defined at the top of `src/styles/alphax-portal.css` (`--bg`, `--surface`, `--surface-2`, `--card`, `--container`, `--fg`, `--fg-3`, `--line`, `--line-2`, `--ghost`, `--ghost-h`, `--brand*`, `--info*`, `--success*`, `--warning*`, `--error*`, `--inverse*`, `--shadow`, `--shadow-lg`).
- DS alpha steps only: 48 / 20 / 8 / 6%. No `#fff`, no Tailwind greys, no filters or brightness hovers. New rules go in `admin.css` and must be built from these tokens.
- Brand colour is rare: primary buttons, selected states, counts, focus, sort icons, tile icons, avatars. Use `a-btn--dark` for a strong action that should not be brand-coloured. Neutral icon tiles use `.ti.n`.
- Light and dark must both work; `[data-theme]` + `prefers-color-scheme` are handled by the shared sheet.

## Layout
- Fills, not strokes: containers, tiles and tables use `--card` fill, radius 20, no border; internal dividers are 1px `--bg`. Hover = `--surface-2`. Form fields keep their DS input stroke.
- Same banner on every page (photo + DS overlay, eyebrow, title, dot-separated details line). Only Overview has a banner button.
- Section rhythm 48px (40px on phone). Gutters 24px (16px ≤600px). Max width 1280px.
- No sideways page scroll at 390 / 820 / 1440 / 1920. Wide tables scroll inside `.tbl-w`.
- ≤1100px: hamburger + bottom dock. Header order on phone/tablet: bell · menu · profile (profile last).

## Type
- TWK Lausanne → Inter → system, letter-spacing 0. Body 15px.
- Section titles under the banner `clamp(24px,3vw,32px)` with a 15px intro.
- Overview tiles: 20px/600 title with the live number + **2-line subtext** (13px, 48% ink; 12px on phones, still visible). Keep subtexts ≈45 characters.
- Numbered step lists (`.plist`): 15px/600 titles, 13px text.
- Profile menu: name 14px, items 13px.

## Components
- Tables: `.tbl` + `.atbl`, DS header (400 13px, 48% ink, no caps), sortable headers via `thead(tid, cols)` with `{k}` keys and `RENDER[tid]`. Whole row opens the popup (`data-open="type:id"`), chevron at the end.
- Filters: `.ttabs` pills, **All first and default**, brand count bubble; search box `.tsearch` on the same row.
- Popups: `openDrawer(title, body, foot)` — fixed 780px (or screen − 32px), Details | Timeline tabs (`tabs()`), footer buttons. Destructive = secondary button + confirmation modal (`openTModal`, 400px). Delete asks to type the ID.
- Radio/checkbox groups (`pills()`): Alpha DS a-check, 16px control, 10px to label, options inline with 24px gap, 12px between rows; one per line inside modals.
- Approval chain strip `.chain` (`.c5` for 5 steps), timeline `.tl/.tle`, tags `a-tag--success/info/warning/error`.
- Device art is black and white (`ART`), thumbnails #FCFCF4 in both themes.
- Density: Compact (`zoom:.875`, ≥1024px only) from the profile menu; every `vh` divided by `var(--vz,1)`.
- Floating buttons bottom-right: Ask (animated sparkle) above Messages; open button turns into ×.

## Writing
- Sentence case everywhere ("New joiners", "Add to stock").
- Plain, specific labels; buttons say exactly what happens; toasts confirm in past tense.
