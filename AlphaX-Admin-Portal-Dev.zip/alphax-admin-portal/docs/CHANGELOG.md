# Changelog

| Version | Date | Change |
|---|---|---|
| v1 | 26 Oct 2026 | First Admin portal: Overview, Requests, Assets, People, New joiners, Infrastructure, Reports, Settings, Help; real register data from the Super Admin export; all admin flows. |
| v2 | 26 Oct 2026 | Overview tiles on every page get a small 2-line subtext, visible on phones too. |
| v3 | 27 Oct 2026 | From Asset App v80: Compact / Default density in the profile menu; Ask stacked above Messages bottom-right; open floating button turns into ×; animated AI sparkle; `a-btn--dark` on New conversation. |
| v4 | 27 Oct 2026 | Radio and checkbox groups follow Alpha DS a-check spacing: inline, 24px between options, 12px between rows. |
| v5 | 27 Oct 2026 | Numbered step titles 15px (were picking up the 18px panel heading). |
| v6 | 27 Oct 2026 | Step text 13px. |
| v7 | 27 Oct 2026 | Settings removed from the header and phone menu; it lives in the profile menu. |
| v8 | 27 Oct 2026 | Phone and tablet header: bell · menu · profile (profile last). |
| v9 | 27 Oct 2026 | Profile menu: name 14px, menu items 13px. |
| 1.0.0 package | 28 Oct 2026 | Split into `src/` with build, dev server, Cursor rules, docs and smoke test. Same output as v9. |
