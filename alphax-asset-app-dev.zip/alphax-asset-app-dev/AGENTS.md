# Agent brief — AlphaX Asset App

- Read `.cursor/rules/alphax-design-system.mdc` (visual rules — non-negotiable) and `.cursor/rules/alphax-project.mdc` (code map) before editing.
- Plain HTML/CSS/JS + Vite. No frameworks, no CSS libraries, no new colours: only tokens from `src/styles/tokens.css`.
- Reuse existing components/classes and helpers (`$`, `$$`, `esc`, `store`, `tileHtml`, `sortBy`, `tabs`, `art`) before adding new ones.
- Finish every task with `npm run audit` passing (0 colour issues, 0 layout issues, 0 JS errors) and check 390 / 820 / 1440 widths in light + dark.
- Record notable design decisions in `docs/asset-app-site-notes.md`.
