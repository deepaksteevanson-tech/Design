import { defineConfig } from "vite";

// Plain HTML/CSS/JS app — no framework. Vite gives a dev server with hot reload and a production build in dist/.
export default defineConfig({
  server: { port: 5173, open: true },
  preview: { port: 4173 },
  build: { outDir: "dist", assetsInlineLimit: 0 }
});
