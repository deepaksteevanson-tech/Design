# Density option + floating button changes — implementation guide

For the **AlphaX Admin portal** (same look as the Asset App). These are the exact snippets from the Asset App `index.html` **v80** (27 Oct 2026). Copy them as they are; class names and tokens already exist in `alphax-portal.css` except where a block below says "add".

Covers:
1. **Density** — *Compact density / Default density* toggle in the profile menu (v76–v78)
2. **Floating buttons** — Ask stacked above Messages on the right (v79)
3. **Open button turns into a close (×) button** (v80)
4. **Animated AI sparkle** on the Ask button (v80)
5. **Dark-fill button** `a-btn--dark` for "New conversation" (v80)

Helpers assumed (same as the Asset App): `$` / `$$` query helpers, `root = document.documentElement`, and `store(key, value)` which reads/writes **JSON** in localStorage (`store(k)` reads, `store(k,v)` writes).

---

## 1. Density (Compact / Default)

### What it does
- Profile menu item under **Dark mode**, behaving exactly like it: one tap switches, and the label always names the *other* mode.
  - In Default it reads **"Compact density"** (shrink-arrows icon).
  - In Compact it reads **"Default density"** (expand-arrows icon).
- **Compact** scales the whole UI to **87.5%** with `zoom:.875` on `<html>`, so a Full HD / low-res monitor looks like Default on a Mac or 2K screen.
- Only applies at **≥1024px** wide; the menu item is hidden below that, so phones never get smaller text.
- Saved in localStorage **`ax-density`** (`"compact"` / `"default"`, JSON-encoded) and applied in the `<head>` script before first paint (no flash).
- The menu stays open after the tap so the user sees the change.

### 1a. `<head>` script (replace the existing theme script)
```html
<script>(function(){var t="auto";try{t=JSON.parse(localStorage.getItem("ax-theme"))||"auto"}catch(e){}if(t==="dark"||t==="light")document.documentElement.setAttribute("data-theme",t);var d="default";try{d=JSON.parse(localStorage.getItem("ax-density"))||"default"}catch(e){}if(d==="compact")document.documentElement.setAttribute("data-density","compact");})();</script>
```
(This also fixes the theme pre-paint: values are stored JSON-encoded by `store()`, so they must be `JSON.parse`d.)

### 1b. CSS (add)
```css
/* Density: Compact scales the whole UI to 87.5% on desktop screens (Full HD / low-res monitors).
   Viewport heights are divided by --vz so popups still fill the screen. */
@media (min-width:1024px){:root[data-density="compact"]{zoom:.875;--vz:.875}}
@media (max-width:1023px){#density-row{display:none}}
```

### 1c. Viewport-height compensation (important)
With `zoom`, `vh`/`dvh` lengths get scaled too, so a popup set to `100vh` would only fill 87.5% of the screen. **Every** `vh`/`dvh` value in the CSS must be divided by `var(--vz,1)` (it is `1` in Default, so nothing changes there):

| Before | After |
|---|---|
| `height:min(780px,calc(100dvh - 32px))` | `height:min(780px,calc(100dvh/var(--vz,1) - 32px))` |
| `max-height:calc(100vh - 60px)` | `max-height:calc(100vh/var(--vz,1) - 60px)` |
| `max-height:min(440px,60vh)` | `max-height:min(440px,60vh/var(--vz,1))` |
| `min-height:100vh` | `min-height:calc(100vh/var(--vz,1))` |

Search the stylesheet for `vh` and apply the same pattern to every hit (`alphax-portal.css` from the v76+ pack already has this done).

JS needs no changes: in zoomed pages `getBoundingClientRect()` and `window.scrollTo()` use the same (zoomed) coordinates, so `el.getBoundingClientRect().top + scrollY - offset` still lands correctly.

### 1d. Profile-menu markup (place right after the Dark mode item)
```html
<button class="pm-item" type="button" id="density-row" role="menuitem"><span class="pm-ic" id="densityIcon"></span><span id="densityLabel">Compact density</span></button>
```

### 1e. JS (place after the theme code, where `root` is defined)
```js
var D_SMALL='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 14h6v6M20 10h-6V4M14 10l7-7M3 21l7-7"/></svg>';
var D_BIG='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/></svg>';
function paintDensity(){var c=root.getAttribute("data-density")==="compact";$("#densityIcon").innerHTML=c?D_BIG:D_SMALL;$("#densityLabel").textContent=c?"Default density":"Compact density"}
$("#density-row").addEventListener("click",function(){var c=root.getAttribute("data-density")!=="compact";if(c)root.setAttribute("data-density","compact");else root.removeAttribute("data-density");store("ax-density",c?"compact":"default");paintDensity()});
if(store("ax-density")==="compact")root.setAttribute("data-density","compact");paintDensity();
```

### Test checklist
- 1920×1080: tap "Compact density" → everything shrinks, label becomes "Default density", reload keeps it.
- No sideways page scroll on any page in Compact; popups still centred and full height.
- 390px phone with `ax-density="compact"` stored → no zoom, item hidden.
- Light + dark.

---

## 2. Floating buttons: Ask above Messages (right side)

Both buttons are stacked bottom-right (Ask on top, Messages below, 12px apart). Both panels open from the right, **above** the pair, so they never cover a button. On phones/tablets (≤900px) everything moves up above the bottom dock.

### CSS (replace the existing `.fab` / `.fpanel` position rules)
```css
.fab{position:fixed;bottom:calc(24px + env(safe-area-inset-bottom,0px));width:56px;height:56px;border-radius:50%;border:0;cursor:pointer;display:grid;place-items:center;box-shadow:var(--shadow-lg);z-index:90;transition:transform .15s}
.fab:hover{transform:translateY(-2px)}
.fab.msg{right:calc(24px + env(safe-area-inset-right,0px));background:var(--brand);color:var(--brand-fg)}
.fab.ask{right:calc(24px + env(safe-area-inset-right,0px));bottom:calc(92px + env(safe-area-inset-bottom,0px));background:var(--inverse);color:var(--inverse-fg);font:500 14px var(--f-ui)}
@media (max-width:900px){.fab{bottom:calc(84px + env(safe-area-inset-bottom,0px))}.fab.ask{bottom:calc(152px + env(safe-area-inset-bottom,0px))}}

.fpanel{position:fixed;bottom:calc(160px + env(safe-area-inset-bottom,0px));width:min(380px,calc(100% - 32px));max-height:min(620px,calc(100vh/var(--vz,1) - 208px));/* …rest unchanged… */}
.fpanel.msg{right:calc(24px + env(safe-area-inset-right,0px))}
.fpanel.ask{right:calc(24px + env(safe-area-inset-right,0px))}
@media (max-width:900px){.fpanel{bottom:calc(220px + env(safe-area-inset-bottom,0px));max-height:calc(100vh/var(--vz,1) - 288px)}}
```
Maths: button 56px + 12px gap → Ask at 24+68 = **92px**; panels at 92+68 = **160px** (phone: 84 → 152 → 220).

---

## 3 + 4. Close (×) on open + animated AI sparkle

### Markup (replace both fab buttons)
The main icon gets `class="fi-main"`; a hidden `fi-x` close icon is added to each button.
```html
<button class="fab ask" type="button" id="ask-btn" aria-label="Ask the register" title="Ask the register" aria-expanded="false" aria-controls="ask-panel"><svg class="fi-main ai-spark" width="28" height="28" viewBox="0 0 32 32" aria-hidden="true"><path class="s1" d="M14 5c.9 4.6 3.4 7.1 8 8-4.6.9-7.1 3.4-8 8-.9-4.6-3.4-7.1-8-8 4.6-.9 7.1-3.4 8-8z" fill="currentColor"/><path class="s2" d="M24 3c.4 1.9 1.4 2.9 3.3 3.3-1.9.4-2.9 1.4-3.3 3.3-.4-1.9-1.4-2.9-3.3-3.3 1.9-.4 2.9-1.4 3.3-3.3z" fill="currentColor"/><path class="s3" d="M24 20c.3 1.5 1.1 2.3 2.6 2.6-1.5.3-2.3 1.1-2.6 2.6-.3-1.5-1.1-2.3-2.6-2.6 1.5-.3 2.3-1.1 2.6-2.6z" fill="currentColor"/></svg><svg class="fi-x" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg></button>

<button class="fab msg" type="button" id="msg-btn" aria-label="Messages" aria-expanded="false" aria-controls="msg-panel"><svg class="fi-main" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg><svg class="fi-x" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg><span class="dot" id="msg-dot" hidden>1</span></button>
```

### CSS (add after `.fab:hover`)
```css
/* open fab turns into a close button; Ask uses an animated AI sparkle */
.fab .fi-x{display:none}
.fab.open .fi-main{display:none}
.fab.open .fi-x{display:block;animation:fabX .2s ease-out}
.fab.open .dot{display:none}
@keyframes fabX{from{transform:rotate(-90deg);opacity:0}to{transform:none;opacity:1}}
.ai-spark{overflow:visible}
.ai-spark path{transform-box:fill-box;transform-origin:center}
.ai-spark .s1{animation:sparkMain 3.2s ease-in-out infinite}
.ai-spark .s2{animation:sparkTw 1.6s ease-in-out infinite}
.ai-spark .s3{animation:sparkTw 1.6s ease-in-out .8s infinite}
@keyframes sparkMain{0%,100%{transform:scale(1) rotate(0)}50%{transform:scale(.82) rotate(45deg)}}
@keyframes sparkTw{0%,100%{transform:scale(1);opacity:1}50%{transform:scale(.3);opacity:.2}}
.fab.ask:not(.open){animation:askGlow 3.2s ease-in-out infinite}
@keyframes askGlow{0%,100%{box-shadow:var(--shadow-lg),0 0 0 0 var(--line-2)}50%{box-shadow:var(--shadow-lg),0 0 0 6px var(--ghost-h)}}
@media (prefers-reduced-motion:reduce){.ai-spark path,.fab.ask:not(.open),.fab.open .fi-x{animation:none}}
```
- Sparkle: big star slowly pulses and turns 45°, two small stars twinkle alternately, a faint ring pulses around the button. Colours are only `currentColor` (inverse-fg) and DS alpha tokens — no new colours, passes the colour audit.
- Reduced motion → everything static.

### JS (add once, before the Ask button's click handler)
Keeps each button in sync with its panel no matter what opens/closes it (button click, Escape, the other panel, "Message IT" links…), so no other code needs to change:
```js
(function(){function sync(){[["#ask-btn","#ask-panel"],["#msg-btn","#msg-panel"]].forEach(function(x){var b=$(x[0]),o=$(x[1]).classList.contains("show");b.classList.toggle("open",o);b.setAttribute("aria-expanded",String(o));b.setAttribute("aria-label",o?"Close "+(x[0]==="#ask-btn"?"Ask the register":"Messages"):(x[0]==="#ask-btn"?"Ask the register":"Messages"))})}
["#ask-panel","#msg-panel"].forEach(function(id){new MutationObserver(sync).observe($(id),{attributes:true,attributeFilter:["class"]})});sync()})();
```
Behaviour: open panel → its button shows × (`.open`, `aria-expanded="true"`, label "Close …"); click × → closes; opening one panel closes the other and resets its button; the Messages unread badge hides while Messages is open.

---

## 5. Dark-fill button (`a-btn--dark`)

Used for **New conversation** in the Messages header ("primary with dark fill"). Use it anywhere a primary-weight action should not be brand-coloured (keeps primary colour sparing).

### CSS (add)
```css
.a-btn--dark{background:var(--inverse);color:var(--inverse-fg)}
.a-btn--dark:hover{background:transparent;border-color:var(--inverse);color:var(--fg)}
```
Light theme: #1D1D1F fill, #FCFCF4 text. Dark theme: flips to #FCFCF4 fill, #1D1D1F text. Hover: outline.

### Markup
```html
<button class="a-btn a-btn--dark a-btn--sm newc" type="button" id="msg-new">New conversation</button>
```

---

## Done-check for the Admin chat
- [ ] Head script replaced (theme + density, JSON.parse)
- [ ] Density CSS added, every `vh`/`dvh` divided by `var(--vz,1)`
- [ ] "Compact density" menu item + JS
- [ ] Fabs stacked right, panels above them (desktop 92/160, phone 152/220)
- [ ] `fi-main` / `fi-x` markup, sync JS, sparkle CSS
- [ ] `a-btn--dark` on New conversation
- [ ] Tested 1920×1080 Compact, 1440, 820, 390; light + dark; reduced motion; colour audit passes
