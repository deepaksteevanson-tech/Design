# AlphaX Admin Portal — design handoff (same look as the Asset App)

**Read this first in the new chat.** The Admin portal must look and behave exactly like the user/manager Asset App (`index.html`, v81, 27 Oct 2026). Only the *functionality* changes: different menu items, pages, data and actions for admins. Every colour, font, size, spacing, component, pattern and interaction comes from the Asset App.

## Files in this pack
| File | What it is | How to use it |
|---|---|---|
| `index.html` | The finished user/manager portal (self-contained: CSS, JS, sample data). **The visual source of truth.** | Open it to see every pattern live. Copy markup and JS patterns from it. |
| `alphax-portal.css` | The full stylesheet from `index.html`, extracted as-is (tokens, light/dark, wordmark, every component). | Paste it into the Admin page's `<style>` unchanged. Add admin-only rules **at the end**, built from the same tokens. Never edit the token blocks. |
| `alphax-logo.png` | Source of the AlphaX wordmark (navy). | Not shown directly: the wordmark is a CSS mask (`.wm`, already embedded as a data URI in the CSS) filled with the text colour. |
| `cover.jpg` | AX002UB banner photo (2000px, ~200 KB). | Same banner image on every Admin page. Keep the relative path `cover.jpg`. |
| `asset-app-site-notes.md` | Full handoff notes of the Asset App (every decision, version history, rules). | Background reading; this file is the condensed design brief. |
| `ADMIN-PORTAL-HANDOFF.md` | This file. | |
| `DENSITY-AND-FLOATING-BUTTONS.md` | Step-by-step code for the Density option, the stacked Ask/Messages buttons, close (×) on open, the AI sparkle and `a-btn--dark`. | Follow it to add these to the Admin portal. |

Live reference (private to Jerrin): https://claude.ai/artifact/JEDBwjU9UrBaGxSjpdMLhM
Alpha Design System reference: https://claude.ai/artifact/CxdC2JkuSMeSzN5hArRcWp

## Non-negotiable rules (agreed with Jerrin)
1. **Everything from Alpha DS.** Only DS tokens and DS alpha steps (48 / 20 / 8 / 6%). No #fff, no Tailwind greys, no filters or brightness hovers. Run a colour audit in light and dark before publishing.
2. **Fills, not strokes** for containers, tiles and tables: `--card` fill (#F2F2F2 light / #292C30 dark), radius 20, no border; internal dividers are 1px in the page background colour (`--bg`). Hover = `--surface-2`. Form fields keep their DS input stroke.
3. **Same banner on every page** (except Sign in): photo + DS hero overlay, transparent header over it, eyebrow + large title + details line with dot separators. Only the text changes per page. A banner button only on the Home/Overview banner.
4. **Lists are tables, not cards.** Filled table container, DS table header (400 13px, 48% ink, no caps), 20px cell padding, row hover, chevron at the end, whole row opens the popup.
5. **Filter tabs: "All" first and default.** DS switcher pills (`.ttabs`) with a brand count bubble (`.n`).
6. **Sortable columns:** 14px brand up/down icon after the label, header is a button with `aria-sort`; click = ascending, again = descending. Use the `SORT` / `sortBy()` / delegated click pattern from `index.html`.
7. **Overview tiles** (Home pattern): one filled container, 4 tiles in a row, 1px `--bg` gaps; each tile = 40px brand-soft icon tile, 20px/600 title **with the live number** ("3 need your approval"), 14px description. **No text links** inside tiles: the whole tile is clickable (sets a filter and scrolls to the table). 2×2 on phones, description hidden. Use `tileHtml()` from `index.html`.
8. **Device images black and white only** (DS neutrals); thumbnail tile #FCFCF4 in both themes. Use the `ART` / `art()` set from `index.html`.
9. **Primary colour used sparingly** (Jerrin felt the UI had too much). Brand is for: primary buttons, selected states, counts, focus, sort icons, tile icons. Don't add new brand-coloured decoration.
10. **Popups**: one fixed height (780px or screen − 32px), content scrolls inside, scrollbar space always reserved (`scrollbar-gutter:stable`, no sideways jump). Hero row (device art + title + meta) → DS line tabs **Details | Timeline** (600 weight, 20px apart, 2px brand underline drawn with inset box-shadow) → content → footer buttons. Confirmation modals 400px.
11. **Type**: TWK Lausanne → Inter → system; letter-spacing 0. 15px body; section titles under the banner 24–32px (`clamp(24px,3vw,32px)`) with a 15px intro line; tile titles 20px/600.
12. **Spacing**: 48px section rhythm (40px on phone); page gutters 24px (16px ≤600px); content max-width 1280px.
13. **Mobile and tablet must work perfectly**: test 390×844, 820×1180 and 1440 wide, light + dark; no sideways page scroll (tables scroll inside their frame); ≤1100px = hamburger + bottom dock; header order on mobile/tablet is bell · hamburger · profile (profile always last).
14. **Footer**: like the welcome ID line (13.5px, ink, 3px dot separators, 28px padding); not the DS-website footer.
15. **Sentence case** for menu and labels ("My assets", "Team requests", "New request").
16. **Screen density (added in Asset App v76)**: profile menu → *Compact density / Default density* toggle item below Dark mode (same behaviour as the Dark mode item; button `#density-row`). Compact = `zoom:.875` on `<html>` at ≥1024px, for Full HD / low-res monitors; saved in localStorage `ax-density`, applied in the `<head>` script; viewport heights divided by `--vz`. Copy the `#density-row` item, the density CSS (zoom + `--vz`) and `paintDensity()` from `index.html` v76 so both portals offer the same option.

## Tokens (already in `alphax-portal.css`)
- Light: bg/container #FCFCF4, surface #F2F2F2, surface-2 = #1D1D1F 6% over #F2F2F2, text #1D1D1F, secondary text #1D1D1F at 48%, lines #1D1D1F at 8/20%, brand #FC4A2E, brand-fg #FCFCF4, soft tints 8%.
- Dark: bg/container #1D1D1F, surface #292C30, surface-2 = #FCFCF4 6% over #292C30, text #FCFCF4 / 48%, brand #FD6E58, info #5E9BF9, success #3CDF76.
- Theme: `localStorage "ax-theme"` = light / dark / auto, set on `<html data-theme>` by the inline script in `<head>`.
- Aliases: `--card` / `--thumb` = surface, `--container` = page colour.

## Page anatomy (copy from `index.html`)
```
<header class="top">  wordmark (.wm) + "Asset App" pill → (Admin: rename pill to "Admin") · .nav menu · bell (.notif) · avatar (.prof)
<section class="view" id="view-…">
  <div class="hero"> <img class="hero-bg" src="cover.jpg"> .welcome → .eyebrow.light · <h1> · .hero-id (dot-separated live facts)
  <div class="band tight"> .tiles.tiles--4  (overview tiles)
  <div class="band"> .band-h (h2 + p) · .ttabs (filters) · .tbl-w > table.tbl (sortable th.sort)
  …more bands…
<footer class="foot">
<aside class="drawer" id="drawer">  (popup: .dhero · .dtabs · panes · footer buttons)
.dock (bottom nav ≤1100px), .toasts, .a-modal, floating .fab buttons
```
Body class `on-hero` makes the header transparent over the banner; it turns solid with blur after 24px of scroll.

## Components to reuse (class names in `alphax-portal.css`)
- Buttons `a-btn` (`--primary`, `--secondary`, `--ghost`, `--icon`; 40 default / 32 `--sm` / 48 `--md`). DS has no danger button: destructive actions are secondary + a confirmation modal.
- Banner CTA `hbtn` (Home/Overview only). Tags `a-tag` (+ `--success/--info/--warning/--error`). Counts: 18px brand bubbles (`.nav-n` menu, `.dock-n` dock, `.n` in filter pills, `.a-count` in the notifications header). Avatars `.av` (40px brand circle, #FCFCF4 initials).
- Fields `a-field` + `a-input` (40px, textarea 96px, radius 14), `a-select` + `a-list` (custom select), `a-check` (16px success circle), switch `.toggle` (DS a-switch, 40×20), `a-upload`.
- Request type switcher `.rtype` (DS a-tabsb, 36px pills). Popup tabs `.dtabs`. Filter pills `.ttabs`. Segmented control `.seg`.
- Panels: notifications `.nmenu` (360px), profile `.prof-menu` (288px), toasts `a-toast`, modals `a-modal`, timeline `.tl` / `.tle` (green done dot, brand "now" dot, dashed "todo").
- Approval chain strip `.chain` (Done / Now / Next steps) used in team-request popups — reuse for any multi-step approval.
- Help shell `.docs` / `.side` (sidebar with separators) + `.main`.

## JS patterns to reuse (in `index.html`)
`$` / `$$` helpers · `esc()` · `IC` icon set · `ART` + `art(type)` device art · `tileHtml()` + `scrollToEl()` · `SORT` + `sortBy()` + delegated `th.sort button` handler · `tabs()` for Details | Timeline · `openRequest()` drawer pattern · toast + modal helpers · hash routing (`#home`, `#kit`, …) with `on-hero` · localStorage for demo state.

## Context the Asset App already shows about admin roles (from its Help & Support)
Desks after sign-in: **IT · Ultimate** (Deepak, can delete), **IT** (no delete), **CEO** (Waleed, approves spend / seal), **HR**, **Procurement** (Yahia, stock / buying), **Finance** (Sabareesh, payment only). Modules: Overview, People, Assets, Stock, Infrastructure, New joiners, Kit requests, Office chat, Kit report, Backup. Manager approval flow: team member → manager → Admin (CEO Waleed or IT admin) → Procurement → delivered. The Admin portal is where the "Admin" and later steps happen, so its tables and popups should mirror the manager's Team requests screens (same columns style, same status tags, same chain strip), with admin actions.

## Starter prompt for the new chat
> I'm building the **AlphaX Admin portal**. It must look exactly like my user/manager Asset App — attached `index.html` (reference), `alphax-portal.css`, `alphax-logo.png`, `cover.jpg`, `ADMIN-PORTAL-HANDOFF.md` and `asset-app-site-notes.md`. Read the handoff first and follow every rule in it. Reuse the CSS unchanged and copy components/JS patterns from `index.html`; only the functionality changes. Admin functionality: [describe menu, pages and actions here].
