# AlphaX Asset App — handoff brief

Paste or attach this file at the start of a new chat, together with `index.html`, `alphax-logo.png` and `cover.jpg`. For the **Admin portal** (same look, different functionality) also read `ADMIN-PORTAL-HANDOFF.md` and use `alphax-portal.css`.

- **Live preview (artifact):** https://claude.ai/artifact/JEDBwjU9UrBaGxSjpdMLhM — version 84, 27 Oct 2026. To keep this link, a new chat should publish updates to this URL (it reads the artifact first, then publishes with `url`). Note: v55 was published from another session; always read the live artifact before publishing.
- **What it is:** a redesign of the staff/manager desk of the AlphaX IT asset portal (live app: `https://inventory.alphaxdev.online`), built as one self-contained HTML page in the Alpha Design System language. Signed-in user in the demo: Jerrin Varghese, EMP-017, Principal UI/UX & Design System Strategist, manager Anna Chatziioannou, Dubai. Since v44 Jerrin is shown as a **manager** (profile shows Desk: Manager, Your team: 6 people).
- **Dev package (28 Oct 2026):** `alphax-asset-app-dev.zip` — the same app split for Cursor/VS Code: `index.html` + `src/styles/tokens.css` + `src/styles/app.css` + `src/main.js` (ES module) + `public/` assets, Vite dev server/build, `npm run audit` (colour, layout and JS-error checks), Cursor rules in `.cursor/rules/`. Version 84 of the artifact = this package.
- **Recent changes (v82–v84):** mobile/tablet header order bell · hamburger · profile (profile last); profile menu type: name 14px/600, menu items 13px, details 12px.
- **Files:** `index.html` (everything: CSS, JS, data; the wordmark is embedded as a data-URI mask), `alphax-logo.png` (source of the wordmark, navy), `cover.jpg` (AX002UB background, 2000px, ~200 KB, referenced by relative path). `alphax-portal.css` = the stylesheet of `index.html` extracted unchanged (for the Admin portal).

## Page banner (v48, button rule v49)
Every page except Sign in opens with the same banner as Home: AX002UB photo (slow drift), DS hero overlay, transparent header over it (solid blur after 24px of scroll), small eyebrow (#FCFCF4 at 48%), large title, and a details line with 3px dot separators. Only the text changes per page. **The white "Request kit" button appears on the Home banner only**; other banners have no button.
| Page | Eyebrow | Title | Details line |
|---|---|---|---|
| Home | Manager desk · Information Technology | Welcome, Jerrin | email · EMP-017 · job title (+ Request kit button → New request) |
| My assets | Manager desk · My assets | My assets | N items on your name · N assigned · N returned to stock · N in service or replacement (live) |
| Team requests | Manager desk · Team requests | Team requests | N waiting for you · N people in your team · You → Admin → Procurement (live) |
| New request | Manager desk · New request | New request | N open requests · New kit, replacement or service · Mail goes to IT, CC Anna Chatziioannou (live) |
| Help & Support | Manager desk · Help & Support | Help & Support | 16 topics · Every desk, flow and approval in the register · Quick answers in Ask the register |
Under the banner each page follows the Home pattern: overview tiles → section heading at Home's size (24–32px title, 15px intro) → content. Body class `on-hero` controls the transparent header.

## Fills, not strokes (Jerrin's rule)
Containers use the card fill, never an outline: `--card` = #F2F2F2 light / #292C30 dark, radius 20, no border; internal dividers are 1px in the page background colour (`--bg`); hover = surface-2.
- Overview tiles, all tables, the New request form + device picker and the My recent activity container follow this. Inside filled containers, items that need to stand out sit on `--container` (#FCFCF4 / #1D1D1F): New kit item tiles (no stroke; brand stroke only when ticked), device-picker cards. Device thumbnails are #FCFCF4 in both themes. Form fields keep their DS input stroke.

## Less primary colour (v66)
Jerrin: "too much primary colour in the whole UI". **Device illustrations are black and white only** — screens #1D1D1F→#292C30, bodies #F2F2F2/#FCFCF4, details ink 48/20%; no brand, info or success colours in device art. Thumbnail tiles are #FCFCF4 in light and dark. Tile text links were removed in v75. Remaining brand uses: tile icons, sort arrows, counts, primary buttons, selected states, avatar.

## Overview tiles (Home v51→v57; My assets + Team requests v74; compact, no links v75)
Alpha DS website "tiles" pattern in **one filled container** (separate cards and outlined frames were rejected). Shared helper `tileHtml()`.
- Anatomy (v75): 24px padding (20px ≤1100px), no min-height, 8px gap, 40px brand-soft icon tile, 20px/600 title **with the live number** (16px top margin), 14px description. **No text links** — the whole tile is a link: it sets the right filter and scrolls to the table (`scrollToEl()`). 4 columns; 2 columns ≤900px; phones 2×2, 16px padding, description hidden.
- **Home:** N assets with you → My assets · N open requests → My requests table · N need your approval → Team requests "Needs your approval" · N closed → Team requests Closed.
- **My assets:** N items issued to you · N assigned to you (both → assets table) · N returned to stock → My recent activity · N in service → My requests table.
- **Team requests:** N waiting for you (or "Nothing waiting for you") → Needs your approval · N with Admin, N with Procurement → In progress · N closed → Closed.

## Sortable columns (v64, Type added v67)
DS data-table style: a 14px brand up/down icon after the header label; header is a button (keyboard focusable, `aria-sort`). First click ascending, second descending. Works together with the filters. Each table keeps its own sort.
- My assets tables (Home + My assets): **Item, Type, Status**.
- Team tables: Home — **Requested by, Item, Raised, Status**; Team requests page — **Requested by, Item, Status**.
- My requests tables (Home + My assets): **Request, Type, Status**.
- Team status sorts follow the workflow order (Waiting for you → Admin → Procurement → Delivered → Declined).

## My requests table — "Where each request is right now" (v58; on Home too since v65)
Table (not cards) on **Home** (`#home-mr-table`, last section) and **My assets** (`#mr-table`). One renderer draws both; each has its own filter and sort.
- Filters: All (first, default) · Open · Closed.
- Columns: Request ID (+ raised date) · Request (device art + title; device ID · serial, or product reference) · Type tag · Status tag (+ Buy) · Next step · chevron. Rows open the request popup on the Timeline tab.

## My assets page (renamed from "My kit" in v73; route stays `#kit`)
- Banner → tiles → "Company property issued to you" table with a **Request kit** primary button on the right (48px, same as the banner button) → "Where each request is right now" → **My recent activity** (v69): heading + subheading, one full-width filled container (`.actw`) with the 10 newest events. The acknowledgement document card is gone from the whole UI.

## Screen density (v76)
Profile menu → **Compact density / Default density** toggle item under Dark mode (v78): works like the Dark mode item — one tap switches, the label always names the other mode, shrink-arrows icon in Default, expand-arrows icon in Compact. **Compact** scales the whole UI to **87.5%** (`zoom:.875` on `<html>`) so a Full HD / low-res monitor looks like the Default view on a Mac or 2K screen. Only applies at ≥1024px wide (the option is hidden on phones and small tablets). Saved in localStorage `ax-density` and applied in the `<head>` script before first paint (no flash). Viewport-height rules divide by `--vz` (0.875 in Compact) so popups and panels still fill the screen. Sizes in this brief are Default values.

## Popups (v70–v72)
One fixed height (780px or screen − 32px); content scrolls inside; navigation closes popups. **Scrollbar space is always reserved** (`scrollbar-gutter:stable` on the popup body and every scrolling panel) so nothing jumps sideways when switching tabs. Details | Timeline tabs: **600 weight, 20px apart, 2px brand underline** (inset box-shadow, so it is not clipped). Confirmation modals 400px (screen − 32px on phone).

## Help & Support sidebar (v68)
1px `--line` separator between topics, inset 12px; items 10px vertical padding, 9px apart.

## Team tables (v63)
No "Waiting on" column. Home: Request ID · Requested by · Item · Raised · Status · chevron (min-width 860). Team requests page: Request ID (+ raised date) · Requested by · Item · Est. cost · Needed by · Status · chevron (min-width 920).

## New request page
Banner → filled form container. Request type switcher (DS a-tabsb): 40px track, 36px pills, 2px inset, brand active, inverse hover; full-width thirds on phones.

## Alpha DS compliance (v47)
Source of truth: the Alpha Design System preview artifact (https://claude.ai/artifact/CxdC2JkuSMeSzN5hArRcWp) and `claude/alpha-ds-site-update-checklist.md`.
- **Tokens:** Light: bg/container #FCFCF4, surface #F2F2F2, surface-2 = #1D1D1F 6% over #F2F2F2, text #1D1D1F, secondary text #1D1D1F at 48%, lines #1D1D1F at 8/20%, brand #FC4A2E, brand-fg #FCFCF4, soft tints 8%, warning text = ink. Dark: bg/container #1D1D1F, surface #292C30, surface-2 = #FCFCF4 6% over #292C30, text #FCFCF4 / 48%, brand #FD6E58, info #5E9BF9, success #3CDF76. Aliases `--card`/`--thumb` = surface.
- **Shadows:** DS Default and LG only. **Banner / sign-in overlay:** DS hero gradient.
- **Colour audit:** every rendered colour (all pages, menus, popups, modals, light + dark) is a DS value or DS alpha step (48/20/8/6%). Only exception: Google "G" logo colours.
- **Wordmark:** CSS mask filled with `currentColor` (PNG is navy #284156, not DS).
- **Fonts:** "TWK Lausanne", "Inter", system; letter-spacing 0.
- **Components:** buttons a-btn (40/32/48); banner CTA hbtn; avatars `.av` 40px brand; counts 18px brand bubbles; tags a-tag sm; fields a-input 40px / textarea 96px / radius 14; a-check 16px success; switch `.toggle` 40×20; a-tabsb `.rtype`; line tabs `.dtabs`; filter pills `.ttabs`; tables `.tbl`; notifications `.nmenu` 360px; profile `.prof-menu` 288px; a-toast; a-modal; a-upload; Help docs shell.

## Menu (v46, renamed v73)
Home (`#home`) · My assets (`#kit`) · Team requests (`#team`, count = waiting on you) · New request (`#requests`) · Help & Support (`#help`). Bottom dock ≤1100px: Home · My assets · Team (count) · New · Help.

## Screens
- **Header:** wordmark + "Asset App" pill · menu · bell · avatar. ≤1100px: bell · hamburger · avatar (profile always last, v82) + bottom dock.
- **Home:** banner (Request kit) → tiles → "Company property issued to you" → Requests from your team → "Where each request is right now".
- **Team requests:** banner → tiles → filters (All · Needs your approval · In progress · Closed) → detailed table → Your team (6 people) + How approval works.
- **Team approval flow:** team member → **you (manager)** → **Admin (CEO Waleed or IT admin)** → **Procurement** (Yahia) → delivered. Decline closes it before Admin. Statuses: Waiting for your approval (warning) → Waiting for admin approval (info) → With procurement (info) → Delivered (success); Declined by you (error). Popup: approval chain strip, Details | Timeline; footer Decline · Ask {name} · Approve. Approve modal: optional note. Decline modal: required reason. Decisions in localStorage `ax-team-reqs`.
- **Asset popup:** device art, Details | Timeline; footer Label · Request service · Request replacement.
- **Help & Support:** sidebar (desktop) / custom select (phone); 16 topics. **Sign in:** own photo layout. **Floating (v79–v80):** both buttons stacked bottom-right — Ask the register on top, Messages (chat) below, 12px apart; both panels open from the right above the pair. Ask shows an animated AI sparkle (twinkling stars + soft pulse ring; off with reduced motion). While a panel is open its button turns into a close (×) button. Messages "New conversation" = dark-fill button (`a-btn--dark`: inverse fill, hover outline).
- **Footer:** like the welcome ID line — 13.5px, ink, 3px dot separators.

## Request flows (own requests)
- After sending: popup with View request · Edit · Withdraw (while New). After IT starts: note + "Message IT".
- Statuses — Kit: New → In review → [Waiting for approval → In procurement process → Waiting for CEO approval → CEO approved → Waiting for payment → Waiting for delivery] → Product delivered / Reason not valid. Service: New → In review → In repair → Ready for collection → Returned to you. Replacement: New → In review → Old device collected → [buy] → Replacement delivered.
- Open question: own-request flow (IT stock check first) vs team flow (manager → Admin → Procurement).

## Other rules agreed with Jerrin
- Same banner on every page; banner button on Home only. Fills, not strokes. Lists as tables, not cards. "All" filter first and default. Device art black and white. No text links in tiles. Sentence case labels. 15px body; section titles 24–32px. 48px section rhythm (40px phone). Mobile and tablet must work perfectly (390×844, 820×1180, 1440; light + dark; no page overflow).

## Known limits / next steps
- Static demo; wiring to the live app's `/api/*` is separate.
- TWK Lausanne renders only where installed.
- DS switch "off" in dark mode shows only the knob (same as DS site).
- Sort order is not remembered between visits.
- **Admin portal:** to be built in a separate chat with the same look (see `ADMIN-PORTAL-HANDOFF.md`).
