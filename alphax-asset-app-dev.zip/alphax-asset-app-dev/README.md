# AlphaX Asset App

Staff / manager desk of the AlphaX IT asset register, built on the **Alpha Design System** (theme *alpha-x*).
Plain HTML, CSS and JavaScript with no framework. [Vite](https://vitejs.dev) provides the dev server and the build.

Same app as the live preview artifact, version 84 (27 Oct 2026). Signed-in demo user: Jerrin Varghese (manager, EMP-017).

## Quick start (Cursor / VS Code)

```bash
npm install                      # Vite + Playwright
npx playwright install chromium  # first time only, for the audit
npm run dev                      # http://localhost:5173, hot reload
```

| Command | What it does |
|---|---|
| `npm run dev` | Dev server with hot reload |
| `npm run build` | Production build in `dist/` (static files; deploy to any web server or CDN) |
| `npm run preview` | Serve `dist/` locally to check the build |
| `npm run audit` | Quality gate: colour audit (light + dark), no sideways scroll at 390 / 820 / 1440 / 1920 Compact, no JS errors. Exits 1 on failure |
| `npm run audit:dist` | Build, then audit the build |

Requires Node 18 or newer. If you already have Chrome or Chromium installed, you can skip the Playwright download with `AX_CHROMIUM=/path/to/chrome npm run audit`.

## Structure

```
index.html              markup for every view, popup, modal and panel (+ inline theme/density pre-paint script)
src/
  main.js               all behaviour (one ES module; sections marked /* ---------- … ---------- */)
  styles/
    tokens.css          Alpha DS tokens: light, dark, wordmark mask (do not add colours)
    app.css             components + layout, tokens only
public/
  cover.jpg             banner photo used on every page
  alphax-logo.png       wordmark source (drawn in DS ink via CSS mask)
scripts/audit.mjs       colour / layout / JS-error audit
docs/                   design notes, Admin-portal hand-off, density + floating-button guide
.cursor/rules/          rules Cursor's AI follows (design system + project map)
AGENTS.md               short brief for any coding agent
```

## Pages (hash routes)

| Route | Page |
|---|---|
| `#home` | Banner, overview tiles, Company property table, Requests from your team, Where each request is right now |
| `#kit` | **My assets**: tiles, assets table, My requests table, My recent activity |
| `#team` | **Team requests**: manager approval (you → Admin → Procurement) |
| `#requests` | **New request**: new kit, replacement or service |
| `#help` | **Help & Support** (16 topics) |
| `#signin` | Sign in |

## Demo data and state

Sample data is defined at the top of `src/main.js` (`ME`, `ASSETS`, `SAMPLE`, `TEAM_SAMPLE`, `PEOPLE`, `MODULES`).
Changes are saved in the browser's localStorage: `ax-theme`, `ax-density`, `ax-asset-requests`, `ax-asset-seq` and `ax-team-reqs`. Clear these keys to reset the demo.
Connecting to the live register (`https://inventory.alphaxdev.online/api/*`) is the next step: replace the sample arrays and the `store()` calls with API calls.

## Design rules (short)

Use Alpha DS colours only. Containers use fills, not strokes. Every page uses the same banner. Lists are tables, not cards. The "All" filter comes first. Tiles have no text links. Device art is black and white only. Use the primary colour sparingly. Letter-spacing is 0. Mobile and tablet must work perfectly.
The full list is in `.cursor/rules/alphax-design-system.mdc` and the full history is in `docs/asset-app-site-notes.md`.

## Fonts

The font stack is TWK Lausanne → Inter (Google Fonts) → system. TWK Lausanne is licensed and only shows where it is installed. To embed it, add the `.woff2` files with an `@font-face` rule in `tokens.css`.
