/* AlphaX Asset App — all behaviour (routing, tables, popups, requests, density, floating panels).
   Loaded as an ES module from index.html. Demo data and state live in localStorage (keys start with "ax-"). */
(function(){
"use strict";
var $=function(s,r){return (r||document).querySelector(s)};
var $$=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};
function esc(s){return String(s==null?"":s).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
function store(k,v){try{if(v===undefined){var r=localStorage.getItem(k);return r?JSON.parse(r):null}localStorage.setItem(k,JSON.stringify(v))}catch(e){return null}}

/* ---------- icons ---------- */
var IC={
  laptop:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="12" rx="2"/><path d="M2 20h20"/></svg>',
  phone:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/></svg>',
  tablet:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="2" width="16" height="20" rx="2"/><path d="M12 18h.01"/></svg>',
  dongle:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M10 7V4h4v3"/><rect x="7" y="7" width="10" height="13" rx="2"/><path d="M10 12h4M10 16h4"/></svg>',
  keyboard:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M8 14h8"/></svg>',
  mouse:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="3" width="12" height="18" rx="6"/><path d="M12 7v3"/></svg>',
  monitor:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="4" width="20" height="13" rx="2"/><path d="M8 21h8M12 17v4"/></svg>',
  hdd:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 14h18M7 17h.01"/></svg>',
  usb:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v14"/><circle cx="12" cy="20" r="1.5"/><path d="M12 7l4 2.5V12M12 10 8 12.5V15"/><circle cx="16" cy="13.5" r="1.3"/><rect x="7" y="15" width="2.5" height="2.5"/></svg>',
  headset:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M4 14v-2a8 8 0 0 1 16 0v2"/><rect x="3" y="14" width="4" height="6" rx="1.5"/><rect x="17" y="14" width="4" height="6" rx="1.5"/></svg>',
  webcam:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="10" r="7"/><circle cx="12" cy="10" r="3"/><path d="M8 21h8M12 17v4"/></svg>',
  dock:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="9" width="20" height="8" rx="2"/><path d="M6 13h.01M10 13h.01M14 13h4"/></svg>',
  other:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 8v.01M11 12h1v4h1"/></svg>',
  doc:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6"/></svg>',
  clip:'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12l-8.5 8.5a5 5 0 0 1-7-7L14 5a3.5 3.5 0 0 1 5 5l-8.5 8.5a2 2 0 0 1-3-3L15 8"/></svg>',
  step:'<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
  chev:'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>',
  tag:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12l-8 8-9-9V3h8z"/><circle cx="7.5" cy="7.5" r="1.2"/></svg>'
};

/* ---------- device artwork (product-style illustrations; the live app can swap these for photos by model) ---------- */
var ART={
 laptop:'<svg viewBox="0 0 120 80"><defs><linearGradient id="gl1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#292c30"/><stop offset="1" stop-color="#1d1d1f"/></linearGradient><linearGradient id="gl2" x1="0" x2="1"><stop offset="0" stop-color="#1d1d1f33"/><stop offset=".5" stop-color="#f2f2f2"/><stop offset="1" stop-color="#1d1d1f7a"/></linearGradient><linearGradient id="gl3" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#1d1d1f"/><stop offset=".55" stop-color="#1d1d1f"/><stop offset="1" stop-color="#292c30"/></linearGradient></defs><rect x="22" y="12" width="76" height="50" rx="4" fill="url(#gl1)"/><rect x="26" y="16" width="68" height="42" rx="2" fill="url(#gl3)"/><circle cx="60" cy="14.5" r="1" fill="#1d1d1f"/><rect x="10" y="62" width="100" height="6" rx="3" fill="url(#gl2)"/><rect x="48" y="62" width="24" height="2.5" rx="1" fill="#1d1d1f7a"/></svg>',
 phone:'<svg viewBox="0 0 120 80"><defs><linearGradient id="gp1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#292c30"/><stop offset="1" stop-color="#1d1d1f"/></linearGradient><linearGradient id="gp2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#292c30"/><stop offset="1" stop-color="#1d1d1f"/></linearGradient></defs><rect x="42" y="4" width="36" height="72" rx="7" fill="#1d1d1f"/><rect x="44.5" y="6.5" width="31" height="67" rx="5.5" fill="url(#gp2)"/><rect x="46" y="8" width="28" height="64" rx="4.5" fill="url(#gp1)"/><circle cx="60" cy="11.5" r="1.6" fill="#1d1d1f"/><rect x="80" y="22" width="1.5" height="8" rx=".7" fill="#292c30"/><rect x="80" y="33" width="1.5" height="12" rx=".7" fill="#292c30"/><rect x="52" y="68" width="16" height="1.5" rx=".7" fill="#fcfcf4" opacity=".8"/></svg>',
 tablet:'<svg viewBox="0 0 120 80"><defs><linearGradient id="gt1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#292c30"/><stop offset="1" stop-color="#1d1d1f"/></linearGradient><linearGradient id="gt2" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#292c30"/><stop offset="1" stop-color="#292c30"/></linearGradient></defs><rect x="18" y="8" width="84" height="64" rx="6" fill="#f2f2f2"/><rect x="20" y="10" width="80" height="60" rx="5" fill="url(#gt1)"/><rect x="25" y="14" width="70" height="52" rx="2" fill="url(#gt2)"/><circle cx="60" cy="12" r="1" fill="#1d1d1f"/></svg>',
 dongle:'<svg viewBox="0 0 120 80"><defs><linearGradient id="gd1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f2f2f2"/><stop offset="1" stop-color="#1d1d1f7a"/></linearGradient></defs><rect x="52" y="8" width="16" height="12" rx="1.5" fill="#1d1d1f33"/><rect x="55" y="10" width="4" height="3" fill="#1d1d1f7a"/><rect x="61" y="10" width="4" height="3" fill="#1d1d1f7a"/><rect x="44" y="20" width="32" height="50" rx="6" fill="url(#gd1)"/><rect x="48" y="30" width="24" height="6" rx="1" fill="#292c30"/><rect x="48" y="40" width="24" height="6" rx="1" fill="#292c30"/><rect x="48" y="50" width="10" height="6" rx="1" fill="#292c30"/><rect x="62" y="50" width="10" height="6" rx="3" fill="#292c30"/><circle cx="68" cy="64" r="1.5" fill="#fcfcf4"/></svg>',
 keyboard:'<svg viewBox="0 0 120 80"><defs><linearGradient id="gk1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f2f2f2"/><stop offset="1" stop-color="#1d1d1f33"/></linearGradient></defs><rect x="8" y="22" width="104" height="38" rx="5" fill="url(#gk1)"/><g fill="#fcfcf4" stroke="#1d1d1f7a" stroke-width=".6">'+(function(){var o="";for(var r=0;r<3;r++){for(var c=0;c<13;c++){o+='<rect x="'+(13+c*7.3)+'" y="'+(26+r*8)+'" width="6" height="6.5" rx="1.2"/>'}}o+='<rect x="13" y="50" width="12" height="6.5" rx="1.2"/><rect x="27" y="50" width="56" height="6.5" rx="1.2"/><rect x="85" y="50" width="22" height="6.5" rx="1.2"/>';return o})()+'</g></svg>',
 mouse:'<svg viewBox="0 0 120 80"><defs><linearGradient id="gm1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fcfcf4"/><stop offset="1" stop-color="#1d1d1f33"/></linearGradient></defs><path d="M60 8c13 0 21 9 21 24v22c0 11-9 18-21 18S39 65 39 54V32c0-15 8-24 21-24z" fill="url(#gm1)"/><path d="M60 8c13 0 21 9 21 24v22c0 11-9 18-21 18S39 65 39 54V32c0-15 8-24 21-24z" fill="none" stroke="#1d1d1f7a" stroke-width="1"/><path d="M60 10v20" stroke="#1d1d1f33" stroke-width="1"/><ellipse cx="60" cy="72" rx="18" ry="2" fill="#1d1d1f" opacity=".08"/></svg>',
 monitor:'<svg viewBox="0 0 120 80"><defs><linearGradient id="gn1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#292c30"/><stop offset=".5" stop-color="#1d1d1f"/><stop offset="1" stop-color="#1d1d1f"/></linearGradient></defs><rect x="8" y="8" width="104" height="56" rx="3" fill="#1d1d1f"/><rect x="11" y="11" width="98" height="48" rx="1.5" fill="url(#gn1)"/><rect x="50" y="64" width="20" height="8" fill="#292c30"/><rect x="36" y="72" width="48" height="3" rx="1.5" fill="#292c30"/></svg>',
 other:'<svg viewBox="0 0 120 80"><rect x="30" y="20" width="60" height="40" rx="8" fill="#1d1d1f33"/><circle cx="60" cy="40" r="10" fill="#1d1d1f7a"/></svg>'
};
ART.headset='<svg viewBox="0 0 120 80"><defs><linearGradient id="gh1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#292c30"/><stop offset="1" stop-color="#1d1d1f"/></linearGradient></defs><path d="M35 50V40a25 25 0 0 1 50 0v10" fill="none" stroke="url(#gh1)" stroke-width="5" stroke-linecap="round"/><rect x="27" y="43" width="15" height="24" rx="7" fill="url(#gh1)"/><rect x="78" y="43" width="15" height="24" rx="7" fill="url(#gh1)"/><path d="M34 66q3 9 18 9" fill="none" stroke="#292c30" stroke-width="2" stroke-linecap="round"/><rect x="50" y="72" width="9" height="5" rx="2.5" fill="#1d1d1f7a"/></svg>';
ART.webcam='<svg viewBox="0 0 120 80"><defs><linearGradient id="gw1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#292c30"/><stop offset="1" stop-color="#1d1d1f"/></linearGradient></defs><rect x="34" y="14" width="52" height="34" rx="17" fill="url(#gw1)"/><circle cx="60" cy="31" r="10" fill="#292c30"/><circle cx="60" cy="31" r="5" fill="#1d1d1f"/><circle cx="76" cy="24" r="1.6" fill="#fcfcf4"/><rect x="56" y="48" width="8" height="12" fill="#292c30"/><rect x="42" y="60" width="36" height="4" rx="2" fill="#1d1d1f7a"/></svg>';
var TYPE_ART={Laptop:'laptop',Other:'phone',Tablet:'tablet',Accessory:'dongle',Keyboard:'keyboard',Mouse:'mouse',Monitor:'monitor',Headset:'headset',Webcam:'webcam'};
var artSeq=0;
function art(type,cls){var n=++artSeq;var svg=(ART[TYPE_ART[type]]||ART.other).replace(/id="(g\w+)"/g,'id="$1_'+n+'"').replace(/url\(#(g\w+)\)/g,'url(#$1_'+n+')');return '<span class="thumb '+(cls||'')+'">'+svg+'</span>'}
var TYPE_ICON={Laptop:'laptop',Other:'phone',Tablet:'tablet',Accessory:'dongle',Keyboard:'keyboard',Mouse:'mouse',Monitor:'monitor'};

/* ---------- data: the signed-in person's kit (from the live register) ---------- */
var ME={name:"Jerrin Varghese",email:"jvarghese@alphax.ae",id:"EMP-017",title:"Principal UI/UX & Design System Strategist",manager:"Anna Chatziioannou"};
var ASSETS=[
  {id:"AST-0044",type:"Laptop",name:"Apple MacBook Pro",brand:"Apple",model:"MacBook Pro",serial:"FYQJQVKXNF",status:"Assigned",events:[["Received into stock","2 Sep 2026 · 10:20","Checked serial and condition · Dubai"],["Identified as AST-0044","2 Sep 2026 · 10:32","Type, brand, model and serial recorded"],["Issued to Jerrin Varghese","5 Sep 2026 · 09:30","Newbee kit · AXAF0726015 signed"]]},
  {id:"AST-0045",type:"Other",name:"Motorola edge 50 fusion",brand:"Motorola",model:"edge 50 fusion",serial:"VIUUIS35H.15-41-6-38-3",status:"Assigned"},
  {id:"AST-0046",type:"Tablet",name:"Mi Tab",brand:"Xiaomi",model:"Mi Tab",serial:"23073RPBFG",status:"Assigned"},
  {id:"AST-0047",type:"Accessory",name:"Ugreen USB-Dongle",brand:"Ugreen",model:"USB-Dongle",serial:"CM512",status:"Assigned"},
  {id:"AST-0048",type:"Keyboard",name:"Magic Keyboard",brand:"Apple",model:"Magic Keyboard",serial:"F0T4497RGVMJKPQAP",status:"Returned"},
  {id:"AST-0049",type:"Mouse",name:"Magic Mouse",brand:"Apple",model:"Magic Mouse",serial:"CC24257A55A5N6GAJ",status:"Returned"},
  {id:"AST-0050",type:"Monitor",name:"LG Ultrafine Monitor",brand:"LG",model:"UltraFine",serial:"412NTZN0R037",status:"Assigned"}
];
var ITEMS=[["keyboard","Keyboard"],["mouse","Mouse"],["monitor","Monitor"],["hdd","Hard drive"],["usb","USB"],["headset","Headset"],["webcam","Webcam"],["dock","Dock / hub"],["other","Other peripheral"]];
var ITEM_LABEL={};ITEMS.forEach(function(i){ITEM_LABEL[i[0]]=i[1]});

/* the ten office statuses, in order */
var STATUSES=["New","In review","Waiting for approval","In procurement process","Waiting for CEO approval","CEO approved","Waiting for payment","Waiting for delivery","Product delivered","Reason not valid"];
function statusChip(s){
  var c={"In repair":"wait","Ready for collection":"info","Returned to you":"ok","Old device collected":"info","Replacement delivered":"ok","Product delivered":"ok","Reason not valid":"err","In review":"info","Waiting for approval":"","In procurement process":"wait","Waiting for CEO approval":"brand","CEO approved":"ok","Waiting for payment":"wait","Waiting for delivery":"info","New":"wait"}[s]||"";
  return '<span class="chip '+c+'"><i></i>'+esc(s)+'</span>';
}
function isClosed(s){return s==="Product delivered"||s==="Reason not valid"||s==="Returned to you"||s==="Replacement delivered"}
var KIND={kit:"New kit",replacement:"Replacement",service:"Service"};
function reqTitle(r){return r.title||r.items.map(function(i){return ITEM_LABEL[i]}).join(", ")}
function assetById(id){return ASSETS.filter(function(a){return a.id===id})[0]}
function openFor(a){return requests.filter(function(r){return r.mine&&r.assetId===a.id&&!isClosed(r.status)})[0]}
/* staff-facing next step (mirrors requestDeskAction for the personal desk) */
function nextStep(r){
  var s=r.status;
  if(s==="Product delivered")return {bucket:"done",step:"Delivered"};
  if(s==="Reason not valid")return {bucket:"done",step:"IT marked this not valid"};
  if(r.kind==="service"){
    if(s==="New")return {bucket:"you",step:"Sent to IT. IT will contact you to "+(r.dropoff&&r.dropoff.indexOf("Collect")===0?"collect the device from your desk":"take the device at the IT desk")+". You can withdraw while it is New."};
    if(s==="In review")return {bucket:"wait",step:"IT is diagnosing the issue"};
    if(s==="In repair")return {bucket:"wait",step:"With the service centre"+(r.loaner?" · a loaner device is with you":"")};
    if(s==="Ready for collection")return {bucket:"you",step:"Ready — collect it from the IT desk, Dubai office"};
    if(s==="Returned to you")return {bucket:"done",step:"Back with you · card updated"};
  }
  if(r.kind==="replacement"){
    if(s==="New")return {bucket:"you",step:"Sent to IT, CC "+ME.manager+". You can still withdraw this while it is New."};
    if(s==="In review")return {bucket:"wait",step:"IT is checking for a replacement in stock"};
    if(s==="Old device collected")return {bucket:"wait",step:"IT has the old device. The replacement is on its way"};
    if(s==="Replacement delivered")return {bucket:"done",step:"Replacement issued on your name"};
  }
  if(s==="New"&&r.mine)return {bucket:"you",step:"Sent to IT, CC "+ME.manager+". You can still withdraw this while it is New."};
  if(s==="New"&&r.pending)return {bucket:"wait",step:"Waiting for the manager to Approve in the email"};
  if(s==="New"||s==="In review")return {bucket:"wait",step:r.buy?"IT is checking stock":"IT will issue this from stock"};
  if(s==="Waiting for approval"||s==="In procurement process"||s==="Waiting for CEO approval")return {bucket:"wait",step:"Procurement is buying this"};
  if(s==="CEO approved"||s==="Waiting for payment")return {bucket:"wait",step:"Finance is recording payment"};
  if(s==="Waiting for delivery")return {bucket:"wait",step:"Waiting for the item to arrive"};
  return {bucket:"wait",step:s};
}

/* two of Jerrin's own requests so the board reads as a working desk (noted in the footer) */
var SAMPLE=[
  {id:"REQ-0115",kind:"service",title:"Service · Mi Tab",assetId:"AST-0046",items:["tablet"],name:ME.name,email:ME.email,issue:"Battery / charging",reason:"Battery drops from full to 20% in under two hours, and it gets warm while charging.",urgency:"Affects my work",dropoff:"I'll drop it at the IT desk",loaner:false,backup:true,status:"In repair",date:"18 Oct 2026",office:"Dubai",mine:true,sample:true,files:["battery-health.png"],
   events:[["New","18 Oct 2026 · 10:05","Service request sent to IT"],["In review","18 Oct 2026 · 15:20","IT confirmed battery health at 71%"],["In repair","20 Oct 2026 · 11:00","Sent to Xiaomi service centre, Dubai · ETA 28 Oct"]]},
  {id:"REQ-0118",sample:true,name:ME.name,email:ME.email,items:["headset"],ref:"Jabra Evolve2 40",reason:"Daily client calls from the Dubai office desk.",status:"In review",buy:false,date:"22 Oct 2026",office:"Dubai",mine:true,
   events:[["New","22 Oct 2026 · 09:14","Sent To IT, CC Anna Chatziioannou"],["Manager approved","22 Oct 2026 · 11:02","Anna Chatziioannou tapped Approve in the email"],["In review","22 Oct 2026 · 14:30","IT is checking unassigned stock in Dubai"]]},
  {id:"REQ-0111",sample:true,name:ME.name,email:ME.email,items:["monitor","dock"],ref:"Dell U2723QE + WD19S dock",reason:"Second screen for design system QA at the office desk.",status:"Waiting for CEO approval",buy:true,date:"15 Oct 2026",office:"Dubai",mine:true,files:["dell-u2723qe-quote.pdf"],
   events:[["New","15 Oct 2026 · 10:41","Sent To IT, CC Anna Chatziioannou"],["Manager approved","15 Oct 2026 · 12:05","Anna Chatziioannou tapped Approve in the email"],["In review","16 Oct 2026 · 09:20","IT checked stock — no spare 27-inch monitor in Dubai"],["Waiting for approval","16 Oct 2026 · 09:26","Sent to Procurement (ymohamad@alphax.ae)"],["In procurement process","17 Oct 2026 · 15:48","Yahia uploaded 2 quotations (Jumbo, noon)"],["Waiting for CEO approval","20 Oct 2026 · 08:55","Comparison sheet emailed to CEO Waleed with Approve"]]}
];
var requests=(store("ax-asset-requests")||[]).filter(function(r){return !r.sample&&!SAMPLE.some(function(x){return x.id===r.id})}).concat(SAMPLE);
var selectedReq=null;

/* ---------- people in the office ---------- */
var PEOPLE=["Alex Bwogi","Anna Chatziioannou","Annie Tolentino","Artjoms Brilovs","Bogdan Dovleac","Bulenza Mulezi","David Echakara","Deepak Steevanson","Ejaz Siddiqui","Gellyn Victorio","Huda Latheef","Hussein Kanji","Iyad Al Sharif","Jay Riche","Joseph Mivule","Kagoda Rogers","Kristine Joy Roaquin","Maher Al-Bunni","Megha Mohan","Miguel Sanjines","Mike Karavidas","Mohammed Nafih","Mustafa Syed","Norhan Tatour","Oumaima Jbeli","Rafsal KK","Rao Iqbal","Ronald Angiro","Saba Mohamad","Sabareesh Kumar","Saeed Mohammad","Sambrit Bidari","Saqib Mehmood","Sarah A","Spiros Pilafas","Susana Zapata","Swedel Viola Fernandes","Thengil Bjornsson","Timos Tokousmpalidis","Vishakha Heralal","Waleed Al Aryan","Yahia Mohamad"];
var ROLE={"Deepak Steevanson":"IT · Ultimate","Waleed Al Aryan":"CEO","Yahia Mohamad":"Procurement","Sabareesh Kumar":"Finance","Anna Chatziioannou":"Manager","Mike Karavidas":"Manager","Spiros Pilafas":"Manager"};
function initials(n){return n.split(/\s+/).slice(0,2).map(function(w){return w[0]}).join("").toUpperCase()}

/* ---------- process modules (the office playbook) ---------- */
var MODULES=[
 {id:"map",title:"Map of all modules",who:"Whole register",intro:"Sign in assigns a desk. Overview is the landing page. People, assets, stock, infrastructure, new joiners, kit requests, office chat, reports and backup sit under it. Stock is unassigned kit IT can issue without buying.",
  flow:{kind:"map"},
  steps:[["Two kit flows","New joiners are HR → manager → IT → employee sign. Kit requests are for people who already work here: staff → IT, then Procurement only if there is no matching stock. Office chat lives in the Messages button and lists people in the office."],["Who is emailed","New kit-request mail is To IT, CC manager only. That mail has Approve so the manager finishes from the inbox. No-stock purchase mail is To ymohamad@alphax.ae. Comparison-sheet mail is To waleed@alphax.ae with Approve. Waiting for payment mail is To skumar@alphax.ae."]]},
 {id:"lifecycle",title:"IT asset lifecycle",who:"Purchase to retirement — IT, with HR / manager / Procurement on the hand-offs",intro:"What happens to a laptop from the moment it arrives until it is retired. The live record is one Assets card. If you cannot track it, you cannot manage it.",
  flow:{kind:"cycle",cap:"The IT asset lifecycle",stages:[["Receive",["Check make, model and serial","Confirm quantity and condition","Record purchase / delivery on the card","Dubai or Uganda office"]],["Identify",["Assign a unique Asset ID","Serial cannot be reused","Record type, brand and model"]],["Deploy",["Assign to someone on People","Or issue on a new joiner (IT ready)","Employee signs AXAF0726015","Status becomes Assigned"]],["Maintain",["User or department change","Repairs and replacement parts","Keep warranty and history current"]],["Reassign",["Recover from the previous user","Return to stock or assign a new holder","Handover stays on the history"]],["Retire",["Recover the device","Follow data-handling","Mark Retired — not stock","Delete stays with Ultimate IT only"]]]},
  cards:[["Who has this laptop?","Assigned rows show the person or team."],["When was it issued?","Assign date and history sit on the asset card."],["Where is it?","Dubai or Uganda, plus any room or note on the card."],["Is it under warranty?","Warranty expiry on the card. Overdue banners use today in Asia/Dubai."]],
  steps:[["1. Receive","When a buy is delivered, or when IT adds a spare, record it as stock. Check serial, condition and office."],["2. Identify","The register gives it an Asset ID. Serials must be unique."],["3. Deploy","Assign it to a person, or issue it on a joiner and collect the acknowledgement signature."],["4. Maintain","Transfers, repairs, location and warranty go on the same card."],["5. Reassign","Return to stock or Assign to someone else so the register stays true."],["6. Retire","Recover it, handle the data, mark Retired. Do not delete the row except Ultimate IT."]]},
 {id:"sign-in",title:"Sign in",who:"Everyone",intro:"The register is closed until a work login is accepted. Nobody can read people, kit, or backups from the public internet without signing in.",
  flow:{kind:"pipe",cap:"Sign in",nodes:[["Team HTTPS link"],["Work email + password"],["Session open"],["Idle ~2.5 min","Stay / Leave"]]},
  steps:[["Open the team HTTPS link","Open https://inventory.alphaxdev.online/login.html — not 127.0.0.1 on another laptop."],["Work email and password","Unknown emails cannot self-register. Create your sign-in sets the first password if that person is already on People. Forgot and Change password email a verification link and a 6-digit code."],["Google (optional)","After IT pastes a Google client ID, @alphax.ae Workspace accounts can tap Sign in with Google. Gmail.com is rejected."],["Stay signed in","Mouse, keyboard or touch keeps the session. After about two and a half minutes idle, Stay signed in / Leave appears."]]},
 {id:"desks",title:"Six desks",who:"Sign-in decides the desk",intro:"The same register, six desks plus staff. Tabs you do not have are hidden. There is no public Create account.",
  lane:[["IT · Ultimate","Deepak Steevanson. Full register plus delete, database and backups."],["IT","People, assets, infra, joiners, requests, reports, backups. No delete."],["CEO","Waleed Al Aryan. Full register below Ultimate. Stamps Approved by CEO Waleed."],["HR","Overview, People, New joiners, My assets, and office Requests."],["Manager","Overview, My assets, New joiners (kit), own request form, and office request status."],["Procurement","Yahia Mohamad. Stock, Requests, Vendors. Buys only when IT has no matching stock."],["Finance","Sabareesh Kumar. Records payment only — Waiting for payment → Waiting for delivery."],["Staff","My assets, the request form, and every office request. Can withdraw an own New request."]],
  flow:{kind:"fan",cap:"Sign-in decides the desk",start:["Sign in"],nodes:[["IT · Ultimate","Delete"],["IT","No delete"],["CEO","Waleed"],["HR"],["Manager"],["Procurement","Yahia"],["Finance","Sabareesh"],["Staff"]]},
  steps:[["Procurement login","Official inbox ymohamad@alphax.ae. Alias procurement@alphax.ae."],["Finance login","Official inbox skumar@alphax.ae. Finance is not emailed on a new kit request."],["No official email","Lama, Gellyn, Annie, Kristine, Noor and Vishakha stay on People with their kit. They cannot sign in."]]},
 {id:"overview",title:"Overview",who:"IT, HR, Manager, Procurement, Finance",intro:"The landing page after sign-in. Counts jump to the matching tab. IT also sees the official team address.",
  flow:{kind:"fan",cap:"Overview",start:["Overview","After sign-in"],nodes:[["People"],["Assets / stock"],["Joiners"],["Requests"],["Infra"],["Reports"]]},
  steps:[["IT","People, assets, infrastructure, joiners in progress, open kit requests, unassigned stock, in repair."],["HR","People on file, joiners in progress, your kit, and your open requests."],["Manager","Your kit, joiners in progress, and open kit requests."],["Procurement","In stock vs none in stock by Dubai and Uganda, vendor book, quotations, purchase trail."],["CEO","Comparison sheet of vendor quotations. Stamp Approved by CEO Waleed."],["Finance","Waiting for payment and paid waiting for delivery. Pay-to from the vendor book."]]},
 {id:"people",title:"People",who:"HR and IT",intro:"The directory of everyone on file. Official email may be blank. Exiting a person does not collect their kit.",
  flow:{kind:"pipe",cap:"People",nodes:[["Add person"],["On file"],["Leaver checklist"],["Exited","Kit stays on name"],["IT moves kit","Stock or someone else"]]},
  steps:[["Add a person","Employee ID, name, title, department, Dubai or Uganda, work email if they have one, manager, join date."],["Leaver","HR ticks the leaver checklist. Status becomes Exited. Assigned kit stays on their name until IT returns it to stock."],["Delete","Only Ultimate IT. Everyone else returns kit to unassigned or marks Exited."]]},
 {id:"assets",title:"Assets",who:"IT. Staff and HR see My assets for their own issued kit",intro:"Add an asset with no person — it is stock. Assigned rows are people or teams who already hold kit.",
  flow:{kind:"fork",cap:"Assets",start:["Add to stock"],branches:[["Keep",[["Unassigned / in stock"],["Issue next request"]]],["Move",[["Assign to someone else"]]],["Stop",[["In Repair or Retired","Not stock"]]]]},
  steps:[["Add to stock","No person needed. Asset ID, what it is, type, brand, model, serial, and Dubai or Uganda."],["Return to stock","Clears the holder so the next request can be filled without buying."],["Assign to someone else","Pick someone on file, or add a new person."],["Staff and HR My assets","Only items issued to the signed-in person, plus their request status and handover document when it exists."]]},
 {id:"stock",title:"Stock",who:"Procurement",intro:"Unassigned items that are not Retired or In Repair. This is what IT can deliver without emailing Procurement.",
  flow:{kind:"fork",cap:"Stock vs buy",start:["IT checks stock"],branches:[["In stock",[["IT issues it","Yahia not emailed"],["Product delivered"]]],["No stock",[["Send to Procurement"],["Yahia quotes","this product"],["CEO Approve","in that email"],["Finance pays","Waiting for payment"],["Product delivered"]]]]},
  steps:[["Available in stock","Types with at least one unassigned matching device. IT issues these and marks product delivered."],["None in stock","Empty kit types by office — No spare mouse in Dubai. A spare with no office does not cover a site. Purchase mail goes To ymohamad@alphax.ae."],["Read-only kit","Procurement cannot edit assigned assets, create requests, or mark reason not valid."]]},
 {id:"infra",title:"Infrastructure",who:"IT",intro:"Rooms, floors, network, Wi-Fi, servers and circuits. Not staff kit.",
  flow:{kind:"pipe",cap:"Infrastructure",nodes:[["IT desk"],["Add infrastructure","Dubai or Uganda"],["Rooms · Wi-Fi · servers"]]},
  steps:[["Add infrastructure","Name, type, site, hostname, IP, vendor, status."],["Keep it with IT","HR, managers, Procurement, Finance and staff do not get this tab."]]},
 {id:"joiners",title:"New joiners",who:"HR → manager → IT → employee",intro:"A newbee cannot be marked joined until they sign Company Asset & Inventory Acknowledgement Form AXAF0726015.",
  lane:[["1. HR","Person and position only. Send goes to the manager automatically."],["2. Manager","Laptop and keyboard start ticked. Office desks skip a company monitor. Home needs single or dual."],["3. IT","Serial or asset ID on every needed item. Marking ready emails the employee the signing link."],["4. Employee","Opens the handover link and signs. Then the record can be Joined."]],
  flow:{kind:"pipe",cap:"New joiners",nodes:[["1. HR","Person and position"],["2. Manager","Laptop + keyboard"],["3. IT","Serial or asset ID"],["4. Employee signs","AXAF0726015"],["Joined"]]},
  steps:[["Managers","Waleed Al Aryan (CEO), Anna Chatziioannou, Mike Karavidas, Spiros Pilafas."],["Mail","HR complete emails the manager (CC HR and IT). Manager complete emails IT. IT ready emails the employee."],["No official email","IT copies the signing link from the joiner record. Do not invent an AlphaX inbox."]]},
 {id:"requests",title:"Kit requests",who:"Staff, HR and managers, then IT, then Procurement only if no stock, then CEO Waleed, then Finance only for payment",intro:"People who already work here request a keyboard, mouse, monitor, USB, headset or other peripheral. If they have a picture, a forwarded email, a PDF or any other file of the item, they attach it on that request. This is not the newbee kit.",
  lane:[["New","Staff, HR and managers submit their own request. Email To IT, CC manager only. The manager taps Approve in that email. Not Finance."],["In review","IT checks unassigned stock."],["In stock","IT issues it and marks product delivered. Procurement and Finance are not emailed."],["No stock","IT sends it to Procurement. To: ymohamad@alphax.ae. Yahia quotes that product, then CEO approval and purchase."]],
  flow:{kind:"story",cap:"Kit requests — stock vs buy",lead:[["Staff submit","To IT, CC manager"],["Manager Approve","in that email"],["IT checks stock"]],branches:[["In stock",[["IT issues it","Yahia not emailed"],["Product delivered"]]],["No stock",[["Send to Procurement"],["Yahia quotes","this product"],["CEO Approve","in that email"],["Finance pays","Waiting for payment"],["Product delivered"]]],["Not valid",[["Reason not valid","IT only"]]]]},
  steps:[["Attachment on the item","Optional picture, forwarded email (.eml or .msg), PDF or Office file on each requested item. Staff can add or remove them while the request is New or In review."],["Procurement buy","Pick a vendor from the book, upload one or more quotations, choose cash, account transfer or payment link. Then waiting for CEO approval. After the seal, record PO number, courier and delivery date."],["CEO comparison","Waiting for CEO approval emails Waleed a comparison sheet with Approve. If there are several quotations he picks one and the seal goes on that quotation."],["Finance payment","Waiting for payment → waiting for delivery only, after the CEO seal. Finance does not buy, deliver, or see stock."],["Reason not valid","IT only, at review."],["Status mail","Later status changes email the employee, with IT and the manager copied."]]},
 {id:"approvals",title:"Manager approvals",who:"Managers — then Admin (CEO Waleed or IT admin), then Procurement",intro:"A request from someone in your team comes to you first. Once you approve it, it goes to Admin. Once Admin approves it, it goes to Procurement to buy.",
  flow:{kind:"story",cap:"Team request approval",lead:[["Team member asks","Request form"],["You review","Requests from your team"]],branches:[["Approve",[["Admin approves","CEO Waleed or IT admin"],["Procurement","Yahia buys it"],["Delivered","IT issues it"]]],["Decline",[["Closed","Your reason goes to them"]]]]},
  lane:[["1. Team member","Sends the request. It lands on Team requests (and on Home), with a notification."],["2. You (manager)","Open the row, check the item, cost and justification. Approve (optional note for Admin) or Decline with a reason. Ask the person first if anything is unclear."],["3. Admin","CEO Waleed Al Aryan or the IT admin approves the spend."],["4. Procurement","Yahia Mohamad gets quotations, buys it, and IT issues it."]],
  steps:[["Needs your approval","Open Team requests in the menu (the count shows how many wait on you). Rows waiting on you have an orange edge."],["Decline","Pick a reason. Other needs a short message. The request closes and never reaches Admin."],["After you approve","You cannot take it back from the table. Message Admin if something changes."]]},
 {id:"chat",title:"Office chat",who:"Everyone signed in",intro:"People chat inside this register from the Messages button. The panel lists people in the office only — not kit, quotes, or joiners.",
  flow:{kind:"pipe",cap:"Office chat",nodes:[["Messages button"],["People in the office"],["Open a person"],["Type a message"],["Send"]]},
  steps:[["Messages button","Bottom-right corner, with a chat icon. Every signed-in desk sees people who still work here."],["Type a message","Same as a phone chat. Your bubbles sit on the right. 800 characters. About 80 messages per conversation. Not emailed."],["Not the gold Ask button","Ask is how the register works. Office chat is a message to a person in the office."],["Delete","Only Ultimate IT can remove a chat message."]]},
 {id:"reports",title:"Kit report and database",who:"IT",intro:"Counts and the full tables. HR and managers do not get these tabs.",
  flow:{kind:"fan",cap:"IT reports",start:["IT desk"],nodes:[["Kit report","Who holds what"],["Database","All tables"],["Search"],["Activity"]]},
  steps:[["Kit report","Who holds what, by person."],["Database","People, assets, infrastructure, joiners and requests in one place."],["Search","Type a name, serial, asset ID, room or request."],["Activity","What changed and when. Most recent first."]]},
 {id:"backup",title:"Backup and notices",who:"IT",intro:"The live file is data/registry.json. A dated backup is written on every successful save.",
  flow:{kind:"pipe",cap:"Backup",nodes:[["Successful save"],["data/registry.json"],["Dated backup"],["IT can restore"]]},
  steps:[["Backup JSON","Header control, IT only."],["Emails and notices","Until a sending mailbox is connected, notices are stored in the register for Open in mail."],["Restore","Replace data/registry.json from data/backups or a downloaded JSON, then keep the app running."]]},
 {id:"best-views",title:"Best views (all combined)",who:"Every desk and surface",intro:"All changes combined in one place: HR and Manager have My assets and their own request form, stock vs buy is site-aware (Dubai and Uganda), Add to stock needs no person, no-stock requests hand off in one click with Send to Procurement, and CEO Waleed picks one quotation when several are uploaded.",
  flow:{kind:"fan",cap:"Combined surfaces",start:["Live Register","All changes combined"],nodes:[["6 Desks + CEO","Role-scoped tabs"],["My assets + Requests","Staff · HR · Manager"],["Dubai & Uganda Stock","Site-aware buy check"],["Needs you / Waiting","2-column board"],["Email Approve","Manager & CEO seal"],["Messages + Ask","Office people chat"]]},
  cards:[["Live Register","Sign in as IT, HR, Manager, CEO, Procurement, Finance, or Staff. Each desk sees only its tabs."],["Process of all modules","Lane diagrams for Sign in, Six desks, Stock vs buy, New joiners, Kit requests, and Office chat."],["Official Approve mail","Navy-and-gold letters sent to line managers and to CEO Waleed with the Approve button."],["Kit Request Form AXAF0726015","Printable and online request form with per-item attachments and locked identity."]],
  steps:[["Site-aware stock vs buy","When a request has an office location, IT checks spare stock at that office so a spare mouse in Uganda never hides a missing mouse in Dubai."],["No-stock → Procurement → CEO → Finance","IT clicks Send to Procurement. Yahia uploads quotations and sends the comparison sheet to CEO Waleed. Finance records payment after the seal."]]}
];

/* ---------- theme (as on the Alpha DS site: one sun/moon button, light by default, choice saved) ---------- */
var root=document.documentElement;
var SUN='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';
var MOON='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/></svg>';
function isDark(){var a=root.getAttribute("data-theme");return a?a==="dark":matchMedia("(prefers-color-scheme: dark)").matches}
function paintThemeBtn(){$("#themeIcon").innerHTML=isDark()?SUN:MOON;$("#themeLabel").textContent=isDark()?"Light mode":"Dark mode"}
$("#themeBtn").addEventListener("click",function(){var n=isDark()?"light":"dark";root.setAttribute("data-theme",n);store("ax-theme",n);paintThemeBtn()});
root.setAttribute("data-theme",store("ax-theme")==="dark"?"dark":"light");
var D_SMALL='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M4 14h6v6M20 10h-6V4M14 10l7-7M3 21l7-7"/></svg>';
var D_BIG='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7"/></svg>';
function paintDensity(){var c=root.getAttribute("data-density")==="compact";$("#densityIcon").innerHTML=c?D_BIG:D_SMALL;$("#densityLabel").textContent=c?"Default density":"Compact density"}
$("#density-row").addEventListener("click",function(){var c=root.getAttribute("data-density")!=="compact";if(c)root.setAttribute("data-density","compact");else root.removeAttribute("data-density");store("ax-density",c?"compact":"default");paintDensity()});
if(store("ax-density")==="compact")root.setAttribute("data-density","compact");paintDensity();
paintThemeBtn();

function scrollBoard(){if(location.hash!=="#kit"){location.hash="kit";setTimeout(scrollBoard,120);return}var t=$("#board-top");if(!t)return;window.scrollTo({top:t.getBoundingClientRect().top+window.scrollY-84,behavior:"smooth"})}
/* ---------- notifications ---------- */
var NOTIFS=[
  {id:"t1",kind:"req",team:"REQ-0122",t:"Rafsal asked for a new laptop",d:"REQ-0122 MacBook Pro 14-inch. Waiting for your approval.",at:"25 Oct · 16:20",unread:true},
  {id:"t2",kind:"req",team:"REQ-0121",t:"Megha asked for a monitor and dock",d:"REQ-0121 Dell U2723QE + WD19S. Waiting for your approval.",at:"24 Oct · 10:05",unread:true},
  {id:"n0",kind:"req",ref:"REQ-0115",t:"Mi Tab sent to the service centre",d:"REQ-0115: Xiaomi service centre, Dubai. Expected back 28 Oct.",at:"20 Oct · 11:00",unread:true},
  {id:"n1",kind:"req",ref:"REQ-0111",t:"Comparison sheet is with CEO Waleed",d:"REQ-0111 Monitor + dock: Yahia uploaded 2 quotations. Waleed picks one and stamps the seal.",at:"20 Oct · 08:55",unread:true},
  {id:"n2",kind:"req",ref:"REQ-0118",t:"Your headset request is In review",d:"IT is checking unassigned stock in Dubai for a Jabra Evolve2 40.",at:"22 Oct · 14:30",unread:true},
  {id:"n3",kind:"req",ref:"REQ-0118",t:"Anna approved REQ-0118",d:"Your manager tapped Approve in the email. IT is next.",at:"22 Oct · 11:02",unread:true},
  {id:"n4",kind:"asset",ref:"AST-0050",t:"Warranty check on AST-0050 LG UltraFine",d:"IT added the warranty expiry to the asset card. Open the card to see it.",at:"21 Oct · 16:40",unread:false},
  {id:"n5",kind:"team",t:"Announcement · Office closed 2 Dec",d:"UAE National Day. Kit requests raised that day are picked up by IT on 3 Dec.",at:"20 Oct · 09:00",unread:false},
  {id:"n6",kind:"asset",ref:"AST-0048",t:"Magic Keyboard returned to stock",d:"AST-0048 is off your name and available for the next request.",at:"14 Oct · 12:12",unread:false},
  {id:"n7",kind:"team",t:"Announcement · Google sign-in coming",d:"IT is connecting Workspace sign-in for @alphax.ae. Email + password keeps working.",at:"10 Oct · 10:30",unread:false}
];
var NICO={req:IC.keyboard,asset:IC.laptop,team:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 11l18-5v12L3 13z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/></svg>'};
var notif=$("#notif");
function renderNotifs(){
  var un=NOTIFS.filter(function(n){return n.unread}).length;$("#notif-badge").hidden=!un;
  var nn=$("#notif-n");nn.textContent=un;nn.hidden=!un;
  $("#notif-list").innerHTML=NOTIFS.map(function(n){return '<button class="ni '+n.kind+(n.unread?' unread':'')+'" type="button" data-n="'+n.id+'" role="menuitem"><span class="ic">'+NICO[n.kind]+'</span><span><b>'+esc(n.t)+'</b><small>'+esc(n.d)+'</small></span><span class="dt">'+esc(n.at)+'</span><i class="dot'+(n.unread?'':' off')+'"></i></button>'}).join("");
  $$("#notif-list .ni").forEach(function(b){b.addEventListener("click",function(){var n=NOTIFS.filter(function(x){return x.id===b.getAttribute("data-n")})[0];n.unread=false;renderNotifs();closeNotif();
    if(n.team){var tr=teamById(n.team);if(tr)openTeam(tr);return}
    if(n.kind==="req"){var r=requests.filter(function(x){return x.id===n.ref})[0];if(r)openRequest(r)}
    else if(n.kind==="asset"){if(location.hash!=="#home")location.hash="home";setTimeout(function(){openAsset(n.ref)},60)}
    else toast(n.t)})});
}
function closeNotif(){notif.classList.remove("open");$("#notif-btn").setAttribute("aria-expanded","false")}
$("#notif-btn").addEventListener("click",function(e){e.stopPropagation();var o=!notif.classList.contains("open");closeProf();notif.classList.toggle("open",o);this.setAttribute("aria-expanded",String(o))});
$("#notif-read").addEventListener("click",function(){NOTIFS.forEach(function(n){n.unread=false});renderNotifs()});
document.addEventListener("click",function(e){if(!notif.contains(e.target))closeNotif()});
renderNotifs();
/* ---------- transparent header over the welcome band ---------- */
function syncTop(){var clear=document.body.classList.contains("on-hero")&&window.scrollY<24&&!$("#mnav").classList.contains("open");$(".top").classList.toggle("clear",clear)}
window.addEventListener("scroll",syncTop,{passive:true});
/* ---------- routing ---------- */
var VIEWS={home:"home",kit:"kit",team:"team",requests:"requests",help:"process",process:"process",signin:"signin"};
function go(v,opts){
  var view=VIEWS[v]||"home";var nav=view==="process"?"help":view;
  if($("#drawer").classList.contains("show"))closeDrawer();if($("#mscrim").classList.contains("show"))closeModal();if($("#tscrim").classList.contains("show"))closeTModal();
  $$(".view").forEach(function(s){s.classList.toggle("on",s.id==="view-"+view)});
  $$("[data-nav]").forEach(function(a){a.classList.toggle("on",a.getAttribute("data-nav")===nav)});
  document.body.classList.toggle("on-signin",view==="signin");if(view==="home")requestAnimationFrame(sizeHomePanels);document.body.classList.toggle("on-hero",["home","kit","team","requests","process"].indexOf(view)!==-1);syncTop();
  $("#mnav").classList.remove("open");$("#menu-btn").setAttribute("aria-expanded","false");
  if(view==="process"&&opts&&opts.module)showModule(opts.module);
  if(!(opts&&opts.keepScroll))window.scrollTo({top:0,behavior:"auto"});
}
function onHash(){var h=(location.hash||"#home").slice(1);go(h)}
window.addEventListener("hashchange",onHash);
$$("[data-go]").forEach(function(b){b.addEventListener("click",function(){var v=b.getAttribute("data-go");if(("#"+v)===location.hash)go(v);else location.hash=v})});
$$("[data-module]").forEach(function(a){a.addEventListener("click",function(){showModule(a.getAttribute("data-module"))})});
$("#menu-btn").addEventListener("click",function(){var m=$("#mnav");var o=!m.classList.contains("open");m.classList.toggle("open",o);this.setAttribute("aria-expanded",String(o));syncTop()});
$("#logout").addEventListener("click",function(){closeProf();location.hash="signin";toast("Signed out of the design preview.")});
var prof=$("#prof-wrap");
function closeProf(){prof.classList.remove("open");$("#prof-btn").setAttribute("aria-expanded","false")}
$("#prof-btn").addEventListener("click",function(e){e.stopPropagation();closeNotif();var o=!prof.classList.contains("open");prof.classList.toggle("open",o);this.setAttribute("aria-expanded",String(o))});
document.addEventListener("click",function(e){if(!prof.contains(e.target))closeProf()});
$$(".prof-menu a").forEach(function(a){a.addEventListener("click",closeProf)});

/* ---------- sortable table headers (DS data table: brand up/down icon) ---------- */
var SORT={};
function dnum(v){var d=new Date(String(v).replace(" · "," "));return isNaN(d)?0:d.getTime()}
function sortBy(list,tid,get){var st=SORT[tid];if(!st||!get[st.key])return list;var g=get[st.key];
  return list.slice().sort(function(a,b){var x=g(a),y=g(b);var c=(typeof x==="number"&&typeof y==="number")?x-y:String(x).localeCompare(String(y),"en",{numeric:true,sensitivity:"base"});return st.dir==="asc"?c:-c})}
document.addEventListener("click",function(e){var b=e.target.closest&&e.target.closest("th.sort button");if(!b)return;
  var th=b.closest("th"),tbl=th.closest("table"),id=tbl.id,k=th.getAttribute("data-sort"),cur=SORT[id];
  SORT[id]={key:k,dir:cur&&cur.key===k&&cur.dir==="asc"?"desc":"asc"};
  $$("th.sort",tbl).forEach(function(h){h.setAttribute("aria-sort",h===th?(SORT[id].dir==="asc"?"ascending":"descending"):"none")});
  if(id==="kit-table"||id==="kit-table2")renderKit();else if(id==="mr-table"||id==="home-mr-table")renderBoard();else renderTeam();
});
/* ---------- stats + kit table ---------- */
function tileHtml(t){return '<a class="tile" href="'+t[0]+'"'+(t[1]?' data-tile="'+t[1]+'"':'')+'><span class="ti">'+t[2]+'</span><h3>'+esc(t[3])+'</h3><p>'+esc(t[4])+'</p></a>'}
function scrollToEl(sel){setTimeout(function(){var t=$(sel);if(t)window.scrollTo({top:t.getBoundingClientRect().top+window.scrollY-84,behavior:"smooth"})},80)}
function renderStats(){
  var assigned=ASSETS.filter(function(a){return a.status==="Assigned"}).length;
  var returned=ASSETS.length-assigned;
  var open=requests.filter(function(r){return r.mine&&!isClosed(r.status)}).length;
  var check='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>';
  var back='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/></svg>';
  /* Home overview = DS website "tiles": icon · title · description · brand link; your kit (row 1), your team (row 2) */
  var tc=function(s){return (typeof TEAM==="undefined"?[]:TEAM).filter(function(r){return s.indexOf(r.status)!==-1}).length};
  var CLOCK='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>';
  var SHIELD='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/></svg>';
  var CART='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.6 12.4a2 2 0 0 0 2 1.6h8.2a2 2 0 0 0 2-1.5L22 7H6"/></svg>';
  var DONE='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/></svg>';
  var waiting=tc(["mgr"]);
  var T=[
    ["#kit","",check,assigned+" assets with you","Kit you hold now. Open a row for its card and history.","My assets"],
    ["#kit","board",IC.keyboard,open+" open request"+(open===1?"":"s"),"Your own kit, service and replacement requests in progress.","Track requests"],
    ["#team","mgr",CLOCK,waiting+" need"+(waiting===1?"s":"")+" your approval","Team requests waiting for you to approve or decline.","Review"],
    ["#team","closed",DONE,tc(["done","declined"])+" closed","Team requests that were delivered or declined.","Team requests"]
  ];
  var box=$("#home-tiles");if(!box)return;
  box.innerHTML=T.map(tileHtml).join("");
  $$("[data-tile]",box).forEach(function(a){a.addEventListener("click",function(){var k=a.getAttribute("data-tile");
    if(k==="board"){setTimeout(scrollBoard,80);return}
    teamFilter.view=k;renderTeam();setTimeout(function(){var t=$("#tv-tabs");window.scrollTo({top:t.getBoundingClientRect().top+window.scrollY-84,behavior:"smooth"})},80)})});
}
function renderKit(){renderKitTable("#kit-table");renderKitTable("#kit-table2");renderKitPage()}
/* My assets page: kit-only stats + recent activity */
function renderKitPage(){
  var box=$("#kit-stats");if(!box)return;
  var assigned=ASSETS.filter(function(a){return a.status==="Assigned"}).length;
  var svc=requests.filter(function(r){return r.mine&&(r.kind==="service"||r.kind==="replacement")&&!isClosed(r.status)}).length;
  var check='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>';
  var back='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/></svg>';
  var returned=ASSETS.length-assigned;
  box.innerHTML=[
    ["#kit","kitlist",IC.laptop,ASSETS.length+" item"+(ASSETS.length===1?"":"s")+" issued to you","Everything issued in your name, including returns.","See the list"],
    ["#kit","kitlist",check,assigned+" assigned to you","Kit you hold now. Open a row for its card and history.","See the list"],
    ["#kit","activity",back,returned+" returned to stock","Items handed back to IT and taken off your name.","Recent activity"],
    ["#kit","board",SVC_IC,svc+" in service","Repairs and replacements that are still open.","Track requests"]
  ].map(tileHtml).join("");
  $$("[data-tile]",box).forEach(function(el){el.addEventListener("click",function(e){var k=el.getAttribute("data-tile");e.preventDefault();
    if(k==="board")setTimeout(scrollBoard,80);else scrollToEl(k==="activity"?"#activity-band":"#kit-table2")})});
  $("#kit-hero-meta").innerHTML='<span>'+ASSETS.length+' items on your name</span><i></i><span>'+assigned+' assigned</span><i></i><span>'+(ASSETS.length-assigned)+' returned to stock</span>'+(svc?'<i></i><span>'+svc+' in service or replacement</span>':'');
  /* activity: every asset event plus open service / replacement requests, newest first */
  var ev=[];
  ASSETS.forEach(function(a){assetEvents(a).forEach(function(e){ev.push({a:a,e:e})})});
  requests.filter(function(r){return r.mine&&r.assetId}).forEach(function(r){var a=assetById(r.assetId);(r.events||[]).forEach(function(e){if(e[3]!=="note")ev.push({a:a,e:[KIND[r.kind]+" · "+e[0],e[1],e[2]],r:r})})});
  function t(s){var d=new Date(String(s).replace(" · "," "));return isNaN(d)?0:d.getTime()}
  ev.sort(function(x,y){return t(y.e[1])-t(x.e[1])});
  $("#kit-activity").innerHTML=ev.slice(0,10).map(function(x){return '<div class="tle"><span class="dot">'+TL_TICK+'</span><div class="wh"><b>'+esc(x.e[0])+'</b><span>'+esc(x.a.name)+' · '+esc(x.a.id)+(x.e[2]?' — '+esc(x.e[2]):'')+'</span></div><span class="at">'+esc(x.e[1])+'</span></div>'}).join("");
}
function renderKitTable(sel){
  var tb=$(sel+" tbody");if(!tb)return;
  tb.innerHTML=sortBy(ASSETS,sel.slice(1),{item:function(a){return a.name},type:function(a){return a.type},status:function(a){return a.status}}).map(function(a){
    return '<tr class="row" tabindex="0" data-asset="'+a.id+'"><td class="num">'+a.id+'</td><td><div class="cell">'+art(a.type)+'<div class="it-main"><b>'+esc(a.name)+'</b><span>'+esc(a.brand)+' · '+esc(a.model)+'</span></div></div></td><td>'+esc(a.type)+'</td><td><code>'+esc(a.serial)+'</code></td><td><div style="display:flex;gap:6px;flex-wrap:wrap;align-items:center">'+(a.status==="Assigned"?'<span class="chip ok"><i></i>Assigned</span>':'<span class="chip"><i></i>Returned</span>')+(function(){var o=openFor(a);return o?'<span class="a-tag a-tag--warning">'+(o.kind==="service"?"In service":"Replacement requested")+'</span>':''})()+'</div></td><td>'+(a.status==="Assigned"?esc(ME.name):'<span style="color:var(--fg-3)">—</span>')+'</td><td class="go">'+IC.chev+'</td></tr>';
  }).join("");
  $$("tr.row",tb).forEach(function(tr){
    var open=function(){openAsset(tr.getAttribute("data-asset"))};
    tr.addEventListener("click",open);tr.addEventListener("keydown",function(e){if(e.key==="Enter"||e.key===" "){e.preventDefault();open()}});
  });
}

/* ---------- drawer ---------- */
var lastFocus=null;
function openDrawer(title,body,foot){
  lastFocus=document.activeElement;
  $("#dr-title").innerHTML=title;$("#dr-body").innerHTML=body;$("#dr-body").scrollTop=0;$("#dr-foot").innerHTML=foot||"";
  $("#scrim").classList.add("show");var d=$("#drawer");d.classList.add("show");d.setAttribute("aria-hidden","false");
  document.body.style.overflow="hidden";bindTabs($("#dr-body"));$("#dr-close").focus();
}
function closeDrawer(){$("#scrim").classList.remove("show");var d=$("#drawer");d.classList.remove("show");d.setAttribute("aria-hidden","true");document.body.style.overflow="";if(lastFocus&&lastFocus.focus)lastFocus.focus()}
$("#dr-close").addEventListener("click",closeDrawer);$("#scrim").addEventListener("click",closeDrawer);
document.addEventListener("keydown",function(e){if(e.key==="Escape"){if($("#tscrim").classList.contains("show")){closeTModal();return}closeDrawer();closeModal();$("#ask-panel").classList.remove("show");$("#msg-panel").classList.remove("show")}});
function assetEvents(a){
  if(a.events)return a.events;
  var ev=[["Received into stock","2 Sep 2026 · 10:20","Checked serial and condition · Dubai"],["Identified as "+a.id,"2 Sep 2026 · 10:40","Type, brand, model and serial recorded"],["Issued to "+ME.name,"5 Sep 2026 · 09:30","Newbee kit · AXAF0726015 signed"]];
  if(a.status==="Returned")ev.push(["Returned to stock","14 Oct 2026 · 12:12","Off your name · available for the next request"]);
  return ev;
}
var TL_TICK='<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>';
var TL_EDIT='<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>';
function timelineHtml(events,futures,closed){
  var nowIdx=-1;events.forEach(function(e,i){if(e[3]!=="note")nowIdx=i});
  var done=events.map(function(e,i,arr){var note=e[3]==="note";var now=i===nowIdx&&!closed;return '<div class="tle'+(now?' now':'')+(note?' note':'')+'"><span class="dot">'+(note?TL_EDIT:now?'<i class="nowdot"></i>':TL_TICK)+'</span><div class="wh"><b>'+esc(e[0])+'</b><span>'+esc(e[2]||"")+'</span></div><span class="at">'+esc(e[1])+'</span></div>'}).join("");
  var todo=(futures||[]).map(function(st){return '<div class="tle todo"><span class="dot"></span><div class="wh"><b>'+esc(st[0])+'</b><span>'+esc(st[1]||"")+'</span></div><span class="at">—</span></div>'}).join("");
  return '<div class="tl">'+done+todo+'</div>';
}
function openAsset(id){
  var a=ASSETS.filter(function(x){return x.id===id})[0];if(!a)return;
  var details='<dl class="dl">'+
    row("Assigned to",a.status==="Assigned"?'<span class="chip ok" style="margin-right:8px"><i></i>Person</span>'+esc(ME.name)+' <span style="color:var(--fg-3)">· '+esc(ME.title)+'</span>':'<span style="color:var(--fg-3)">Returned to stock</span>')+
    row("Employee ID",'<code>'+ME.id+'</code>')+row("Location","Dubai")+row("Device type",esc(a.type))+row("Brand",esc(a.brand))+row("Model",esc(a.model))+
    row("Serial number",'<code>'+esc(a.serial)+'</code>')+row("Status",a.status==="Assigned"?'<span class="chip ok"><i></i>Assigned</span>':'<span class="chip"><i></i>Returned</span>')+
    row("Assign date","—")+row("Return date","—")+row("Warranty","—")+row("Extra / notes","—")+'</dl>';
  var history=timelineHtml(assetEvents(a),a.status==="Assigned"?[["Maintain","Repairs, warranty and location stay on this card"],["Reassign or retire","Return to stock, assign to someone else, or retire"]]:[["Issue to the next request","Unassigned stock IT can deliver without buying"]],a.status==="Returned");
  var busy=openFor(a);
  var banner=busy?'<div class="asset-busy"><span><b>'+esc(KIND[busy.kind])+' '+esc(busy.id)+'</b> · '+esc(busy.status)+'</span><button class="a-btn a-btn--secondary a-btn--sm" type="button" id="dr-busy">Open request</button></div>':'';
  var body='<div class="dhero">'+art(a.type,"lg")+'<div><h4>'+esc(a.name)+'</h4><p>'+esc(a.type)+' · '+esc(a.brand)+'</p></div></div>'+banner+tabs([["Details",details],["Timeline",history]]);
  var labelBtn='<button class="a-btn a-btn--ghost" type="button" id="dr-label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20 12l-8 8-9-9V3h8z"/><circle cx="7.5" cy="7.5" r="1.2"/></svg>Label</button>';
  var actions='<button class="a-btn a-btn--secondary" type="button" id="dr-service">'+SVC_IC+'Request service</button><button class="a-btn a-btn--primary" type="button" id="dr-replace">'+RPL_IC+'Request replacement</button>';
  openDrawer('<code>'+a.id+'</code> '+esc(a.type),body,labelBtn+'<span style="flex:1"></span>'+actions);
  $("#dr-label").addEventListener("click",function(){toast("Label for "+a.id+" sent to the IT label printer queue.")});
  function go2(kind){if(busy){openRequest(busy);toast(KIND[busy.kind]+" request "+busy.id+" is already open for this device.");return}openReqForm(kind,a.id,true)}
  $("#dr-service").addEventListener("click",function(){go2("service")});
  $("#dr-replace").addEventListener("click",function(){go2("replacement")});
  var b3=$("#dr-busy");if(b3)b3.addEventListener("click",function(){openRequest(busy)});
  var b4=$("#dr-busy2");if(b4)b4.addEventListener("click",function(){openRequest(busy)});
  var b5=$("#dr-again");if(b5)b5.addEventListener("click",function(){
    var key={Keyboard:"keyboard",Mouse:"mouse",Monitor:"monitor"}[a.type]||"other";
    closeDrawer();if(location.hash!=="#requests")location.hash="requests";
    setTimeout(function(){setRType("kit");var cb=$("#item-"+key);if(cb&&!cb.checked){cb.checked=true;cb.dispatchEvent(new Event("change",{bubbles:true}))}
      if(key==="other"){$("#f-other").value=a.name}
      $("#f-ref").value=$("#f-ref").value||a.brand+" "+a.model;
      var t=$("#items");window.scrollTo({top:t.getBoundingClientRect().top+window.scrollY-120,behavior:"smooth"});toast(a.name+" added to a new kit request.")},120);
  });
}
function row(k,v){return '<dt>'+k+'</dt><dd>'+v+'</dd>'}
function tabs(list,start){start=start||0;return '<div class="dtabs" role="tablist">'+list.map(function(t,i){return '<button type="button" role="tab" data-tab="'+i+'" class="'+(i===start?'on':'')+'" aria-selected="'+(i===start)+'">'+esc(t[0])+'</button>'}).join("")+'</div>'+list.map(function(t,i){return '<div data-pane="'+i+'"'+(i===start?'':' hidden')+'>'+t[1]+'</div>'}).join("")}
function bindTabs(root){
  var panes=$$("[data-pane]",root);
  /* measure every pane once so the dialog keeps one height when the tab changes */
  var max=0;panes.forEach(function(pn){var was=pn.hidden;pn.hidden=false;max=Math.max(max,pn.offsetHeight);pn.hidden=was});
  root.style.minHeight="";root.style.setProperty("--pane-h",max+"px");
  /* the dialog has one fixed height; panes scroll inside it */
  $$(".dtabs button",root).forEach(function(b){b.addEventListener("click",function(){var k=b.getAttribute("data-tab");$$(".dtabs button",root).forEach(function(x){var on=x===b;x.classList.toggle("on",on);x.setAttribute("aria-selected",String(on))});panes.forEach(function(pn){pn.hidden=pn.getAttribute("data-pane")!==k});root.scrollTop=0})});
}
function openRequest(r,startTab){
  var ns=nextStep(r);var idx=STATUSES.indexOf(r.status);
  var trail=["New","In review"].concat(r.buy?["Waiting for approval","In procurement process","Waiting for CEO approval","CEO approved","Waiting for payment","Waiting for delivery"]:[]).concat(["Product delivered"]);
  if(r.status==="Reason not valid")trail=["New","In review","Reason not valid"];
  var cur=trail.indexOf(r.status);
  var next='<div class="panel" style="padding:14px 16px;margin-bottom:16px;background:var(--surface);border-color:transparent"><div class="eyebrow" style="margin-bottom:6px">Next step</div><div style="display:flex;gap:10px;align-items:flex-start"><span style="color:var(--brand);margin-top:4px">'+IC.step+'</span><span style="font-size:15px">'+esc(ns.step)+'</span></div></div>';
  var dev=r.assetId?assetById(r.assetId):null;
  var details=r.kind&&r.kind!=="kit"?next+'<dl class="dl">'+row("Type",'<span class="a-tag">'+esc(KIND[r.kind])+'</span>')+row("Status",statusChip(r.status))+row("Device",dev?esc(dev.name)+'<br><span style="color:var(--fg-3);font-size:12px" class="mono">'+esc(dev.id)+' · '+esc(dev.serial)+'</span>':"—")+
    (r.kind==="service"?row("Issue",esc(r.issue||"—"))+row("Description",esc(r.reason||"—"))+row("Urgency",esc(r.urgency||"—"))+row("Hand-over",esc(r.dropoff||"—")+(r.date2?' · '+esc(r.date2):''))+row("Loaner device",r.loaner?'<span class="chip info"><i></i>Requested</span>':"Not needed")+row("Files backed up",r.backup?"Yes":"—")
      :row("Reason",esc(r.reasonType||"—"))+row("What happened",esc(r.reason||"—"))+row("When",esc(r.when||"—"))+row("Can you still work on it?",esc(r.urgency||"—"))+(r.reasonType==="Lost or stolen"?row("Incident report",esc(r.incident||"—")):row("Old device","Handed back to IT when the replacement arrives")))+
    row("Attachments",r.files&&r.files.length?r.files.map(function(f){return '<span class="a-tag">'+IC.clip+' '+esc(f)+'</span>'}).join(" "):"—")+'</dl>'
  :next+'<dl class="dl">'+row("Type",'<span class="a-tag">New kit</span>')+row("Status",statusChip(r.status))+row("Requested by",esc(r.name)+'<br><span style="color:var(--fg-3);font-size:12px">'+esc(r.email)+'</span>')+row("Items",r.items.map(function(i){return '<span class="a-tag">'+esc(ITEM_LABEL[i])+'</span>'}).join(" "))+row("Product reference",r.ref?esc(r.ref):"—")+row("Attachments",r.files&&r.files.length?r.files.map(function(f){return '<span class="a-tag">'+IC.clip+' '+esc(f)+'</span>'}).join(" "):"—")+row("Business justification",r.reason?esc(r.reason):"—")+row("Stock or buy",r.buy?'<span class="chip wait"><i></i>No matching stock — buy</span>':'<span class="chip ok"><i></i>Expected from stock</span>')+'</dl>';
  var history=timelineHtml(r.events||[[r.status,r.date,""]],futureStages(r).map(function(st){return [st,stepHelp(st,r)]}),isClosed(r.status));
  var body='<div class="dhero">'+(dev?art(dev.type,"lg"):'<span class="ti" style="width:56px;height:56px;border-radius:16px">'+IC[r.items[0]]+'</span>')+'<div><h4>'+esc(reqTitle(r))+'</h4><p>'+esc(KIND[r.kind||"kit"])+' · '+esc(r.date)+' · '+esc(r.office||"Dubai")+'</p></div></div>'+tabs([["Details",details],["Timeline",history]],startTab==="timeline"?1:0);
  var foot=!r.mine||isClosed(r.status)?'':(r.status==="New"?'<button class="a-btn a-btn--secondary" type="button" id="dr-withdraw">Withdraw request</button><span style="flex:1"></span><button class="a-btn a-btn--secondary" type="button" id="dr-edit"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>Edit request</button>'
      :'<span class="foot-note">IT has started on this request. To change or cancel it, message IT.</span><span style="flex:1"></span><button class="a-btn a-btn--primary" type="button" id="dr-msgit">Message IT</button>');
  openDrawer('<code>'+esc(r.id)+'</code> '+esc(KIND[r.kind||"kit"])+' request',body,foot);
  var w=$("#dr-withdraw");if(w)w.addEventListener("click",function(){confirmWithdraw(r)});
  var ed=$("#dr-edit");if(ed)ed.addEventListener("click",function(){openEdit(r)});
  var mi=$("#dr-msgit");if(mi)mi.addEventListener("click",function(){messageIT(r)});
}
function stepHelp(s,r){
  if(r&&r.kind==="service"){var sv={"New":"Sent to IT. No manager approval needed.","In review":"IT diagnoses the issue and decides on repair."};if(sv[s])return sv[s]}
  if(r&&r.kind==="replacement"){var rp={"New":"Mail To IT, CC your manager. Manager taps Approve.","In review":"IT checks the device and looks for a replacement in stock."};if(rp[s])return rp[s]}
  return {"New":"Mail To IT, CC your manager. Manager taps Approve.","In review":"IT checks unassigned stock at your office.","Waiting for approval":"No stock. Sent to Procurement (ymohamad@alphax.ae).","In procurement process":"Yahia picks a vendor and uploads quotations.","Waiting for CEO approval":"Comparison sheet with CEO Waleed.","CEO approved":"Seal stamped. Procurement asks Finance to pay.","Waiting for payment":"Finance (skumar@alphax.ae) records payment.","Waiting for delivery":"Paid. Courier and delivery date on the trail.","Product delivered":"Issued to you and closed.","Reason not valid":"IT closed it at review.","In repair":"Fixed by IT or sent to the service centre.","Ready for collection":"Collect it from the IT desk, Dubai office.","Returned to you":"Device back with you and the card updated.","Old device collected":"IT takes the old device back to stock, repair or retirement.","Replacement delivered":"New device issued on your name and the card updated."}[s]||""}

/* ---------- confirm modal ---------- */
var pendingWithdraw=null;
function confirmWithdraw(r){pendingWithdraw=r;$("#m-text").textContent="Request "+r.id+" is still New, so IT has not acted on it. Withdrawing removes it from the board.";$("#mscrim").classList.add("show");$("#m-no").focus()}
function closeModal(){$("#mscrim").classList.remove("show");pendingWithdraw=null}
$("#m-no").addEventListener("click",closeModal);
$("#mscrim").addEventListener("click",function(e){if(e.target===this)closeModal()});
$("#m-yes").addEventListener("click",function(){
  if(!pendingWithdraw)return;var id=pendingWithdraw.id;
  requests=requests.filter(function(x){return x.id!==id});persist();closeModal();closeDrawer();renderAll();renderPick();toast("Request "+id+" withdrawn.");
});
function persist(){store("ax-asset-requests",requests.filter(function(r){return r.mine&&!r.sample}))}

/* ---------- request form ---------- */
var chosen={};var files=[];
function renderItems(){
  $("#items").innerHTML=ITEMS.map(function(it){
    var k=it[0];
    return '<div class="item" data-item="'+k+'"><label class="hd" for="item-'+k+'"><span class="ti">'+IC[k]+'</span><b>'+esc(it[1])+'</b><span class="a-check"><input type="checkbox" id="item-'+k+'"><i></i></span></label></div>';
  }).join("");
  $$("#items input[type=checkbox]").forEach(function(cb){
    cb.addEventListener("change",function(){var k=cb.id.replace("item-","");chosen[k]=cb.checked;cb.closest(".item").classList.toggle("on",cb.checked);$("#other-wrap").hidden=!chosen.other;$("#items-err").hidden=true;var any=Object.keys(chosen).some(function(x){return chosen[x]});$("#req-rest").disabled=!any;$("#req-note").hidden=any});
  });
}
function addFiles(list){files=files.concat(Array.prototype.slice.call(list).map(function(f){return f.name}));renderFiles()}
function renderFiles(){
  var box=$("#files-all");box.innerHTML=files.map(function(n,i){return '<span class="a-chip">'+IC.clip+'<span>'+esc(n)+'</span><button type="button" class="a-btn a-btn--icon" style="--h:18px;width:18px;padding:0" data-rm="'+i+'" aria-label="Remove '+esc(n)+'">×</button></span>'}).join("");
  $$("[data-rm]",box).forEach(function(b){b.addEventListener("click",function(){files.splice(+b.getAttribute("data-rm"),1);renderFiles()})});
}
(function(){var fi=$("#file-all"),zone=fi.closest(".a-upload");fi.addEventListener("change",function(){addFiles(fi.files);fi.value=""});
  ["dragenter","dragover"].forEach(function(ev){zone.addEventListener(ev,function(e){e.preventDefault();zone.classList.add("drag")})});
  ["dragleave","drop"].forEach(function(ev){zone.addEventListener(ev,function(e){e.preventDefault();zone.classList.remove("drag");if(ev==="drop"&&e.dataTransfer)addFiles(e.dataTransfer.files)})});
})();
var seq=(store("ax-asset-seq")||120);
$("#req-form").addEventListener("submit",function(e){
  e.preventDefault();
  var items=ITEMS.map(function(i){return i[0]}).filter(function(k){return chosen[k]});
  if(!items.length){$("#items-err").hidden=false;$("#items").scrollIntoView({behavior:"smooth",block:"center"});return}
  var other=$("#f-other").value.trim();
  seq+=1;store("ax-asset-seq",seq);
  var atts=files.slice();
  var buy=items.indexOf("monitor")!==-1||items.indexOf("webcam")!==-1||items.indexOf("hdd")!==-1;
  var r={id:"REQ-0"+seq,name:ME.name,email:ME.email,items:items,other:other,ref:$("#f-ref").value.trim(),reason:$("#f-reason").value.trim(),files:atts,status:"New",mine:true,buy:buy,events:[["New",new Date().toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"})+" · "+new Date().toTimeString().slice(0,5),"Sent To IT, CC "+ME.manager]],date:new Date().toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"}),office:"Dubai"};
  requests.unshift(r);persist();
  this.reset();chosen={};files=[];renderItems();renderFiles();$("#req-rest").disabled=true;$("#req-note").hidden=false;$("#other-wrap").hidden=true;
  renderAll();
  selectedReq=r.id;showSent(r,false);
});


/* ---------- replacement & service requests ---------- */
var SVC_IC='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.4-.6-.6-2.4z"/></svg>';
var RPL_IC='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M17 1l4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><path d="M7 23l-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>';
var WARN_IC='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 9v4M12 17h.01"/><path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/></svg>';
var INFO_IC='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v4h1"/></svg>';
function pills(name,opts,req){return '<div class="pills" role="radiogroup">'+opts.map(function(o,i){return '<label class="radio-r"><input type="radio" name="'+name+'" value="'+esc(o)+'"'+(req?' required':'')+'><i></i><span>'+esc(o)+'</span></label>'}).join("")+'</div><div class="err-t" data-err="'+name+'" hidden>Choose one.</div>'}
function todayISO(){var d=new Date();return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0")}
function fmtDate(iso){if(!iso)return "";var p=iso.split("-");return new Date(+p[0],+p[1]-1,+p[2]).toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"})}
function nowStamp(){var d=new Date();return d.toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"})+" · "+d.toTimeString().slice(0,5)}
var rfFiles=[];
function isoFrom(label){if(!label)return todayISO();var d=new Date(label);if(isNaN(d))return todayISO();return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0")}
function uploadField(hint){return '<div class="a-field"><label for="rf-file">Photos or documents <span class="a-help">(optional)</span></label><label class="a-upload a-upload--big" for="rf-file">'+IC.clip+'<span><b>Drop files here or click to attach</b><small>'+hint+'</small></span><input type="file" id="rf-file" multiple accept="image/*,video/*,.pdf,.eml,.msg,.doc,.docx,.xls,.xlsx"></label><div class="files" id="rf-files"></div></div>'}
function wireUpload(){
  var fi=$("#rf-file"),zone=fi.closest(".a-upload");
  function draw(){var box=$("#rf-files");box.innerHTML=rfFiles.map(function(n,i){return '<span class="a-chip">'+IC.clip+'<span>'+esc(n)+'</span><button type="button" class="a-btn a-btn--icon" style="--h:18px;width:18px;padding:0" data-rf-rm="'+i+'" aria-label="Remove '+esc(n)+'">×</button></span>'}).join("");$$("[data-rf-rm]",box).forEach(function(b){b.addEventListener("click",function(){rfFiles.splice(+b.getAttribute("data-rf-rm"),1);draw()})})}
  function add(list){rfFiles=rfFiles.concat(Array.prototype.slice.call(list).map(function(f){return f.name}));draw()}
  fi.addEventListener("change",function(){add(fi.files);fi.value=""});
  ["dragenter","dragover"].forEach(function(ev){zone.addEventListener(ev,function(e){e.preventDefault();zone.classList.add("drag")})});
  ["dragleave","drop"].forEach(function(ev){zone.addEventListener(ev,function(e){e.preventDefault();zone.classList.remove("drag");if(ev==="drop"&&e.dataTransfer)add(e.dataTransfer.files)})});
  draw();
}
function setRadio(name,val){var el=$('input[name="'+name+'"][value="'+String(val||"").replace(/"/g,'\\"')+'"]');if(el)el.checked=true}
function openReqForm(kind,assetId,fromAsset,edit){
  var a=assetById(assetId);if(!a)return;rfFiles=edit?(edit.files||[]).slice():[];
  var top='<div class="rf-asset">'+art(a.type)+'<div style="min-width:0"><b>'+esc(a.name)+'</b><span>'+esc(a.id)+' · '+esc(a.serial)+'</span></div></div>';
  var body;
  if(kind==="replacement"){
    body='<form class="rf" id="rf" novalidate>'+top+
      '<div><div class="rf-q">Why do you need a replacement? <span class="req">*</span></div>'+pills("rf-reason",["Damaged","Not working","Lost or stolen","Too slow / outdated","Other"],true)+'</div>'+
      '<div class="rf-note" id="rf-lost" hidden>'+WARN_IC+'<span>Lost or stolen devices are locked and wiped remotely by IT. Send this today and add the police or incident report number if you have one.</span></div>'+
      '<div class="a-field"><label for="rf-desc">What happened? <span style="color:var(--brand)">*</span></label><textarea class="a-input" id="rf-desc" placeholder="For example: dropped on the way to a client meeting, the screen is cracked and the bottom half does not respond."></textarea><div class="err-t" data-err="rf-desc" hidden>Tell IT what happened (at least 10 characters).</div></div>'+
      '<div class="frow"><div class="a-field"><label for="rf-when">When did it happen?</label><input class="a-input" type="date" id="rf-when" max="'+todayISO()+'" value="'+todayISO()+'"></div>'+
      '<div class="a-field" id="rf-inc-wrap" hidden><label for="rf-inc">Police / incident report no. <span class="a-help">(optional)</span></label><input class="a-input" id="rf-inc" placeholder="e.g. DXB-2026-104233"></div></div>'+
      '<div><div class="rf-q">Can you still work on it? <span class="req">*</span></div>'+pills("rf-urg",["Yes","Partly","No"],true)+'</div>'+uploadField("Photos of the damage, or the police / incident report.")+
      '<label class="cbx" id="rf-hand-wrap"><span class="a-check"><input type="checkbox" id="rf-hand"><i></i></span><span>I will hand the old device back to IT when the replacement arrives<small>IT returns it to stock, sends it for repair, or retires it.</small></span></label><div class="err-t" data-err="rf-hand" hidden>Confirm the hand-back to continue.</div>'+
      '<div class="rf-note info">'+INFO_IC+'<span>Mail goes To IT, CC '+esc(ME.manager)+', who approves from the email. IT checks stock first; Procurement only buys if nothing matches.</span></div></form>';
  }else{
    body='<form class="rf" id="rf" novalidate>'+top+
      '<div><div class="rf-q">What needs attention? <span class="req">*</span></div>'+pills("rf-issue",["Hardware damage","Battery / charging","Screen","Keyboard / trackpad","Software / OS","Slow performance","Other"],true)+'</div>'+
      '<div class="a-field"><label for="rf-desc">Describe the issue <span style="color:var(--brand)">*</span></label><textarea class="a-input" id="rf-desc" placeholder="What happens, since when, and anything you already tried."></textarea><div class="err-t" data-err="rf-desc" hidden>Describe the issue (at least 10 characters).</div></div>'+
      '<div><div class="rf-q">How urgent is it? <span class="req">*</span></div>'+pills("rf-urg",["Can wait","Affects my work","I can\'t work"],true)+'</div>'+
      '<div><div class="rf-q">How should IT get the device? <span class="req">*</span></div>'+pills("rf-drop",["I\'ll drop it at the IT desk","Collect from my desk"],true)+'</div>'+
      '<div class="frow"><div class="a-field"><label for="rf-date">Preferred date</label><input class="a-input" type="date" id="rf-date" min="'+todayISO()+'" value="'+todayISO()+'"></div><div></div></div>'+
      '<label class="toggle"><input type="checkbox" id="rf-loaner"><i></i>I need a loaner device while it is away</label>'+uploadField("A photo of the fault, an error screenshot or a short video.")+
      '<label class="cbx"><span class="a-check"><input type="checkbox" id="rf-backup"><i></i></span><span>I have backed up my work files<small>IT or the service centre may need to reset the device.</small></span></label><div class="err-t" data-err="rf-backup" hidden>Back up your files first, then tick this.</div>'+
      '<div class="rf-note info">'+INFO_IC+'<span>Service requests go straight to IT; your manager does not need to approve. You will get a notification at every step.</span></div></form>';
  }
  var sendLabel=edit?'Save changes':(kind==="service"?SVC_IC+'Send service request':RPL_IC+'Send replacement request');
  var foot='<button class="a-btn a-btn--secondary" type="button" id="rf-back">'+(edit||fromAsset?'Back':'Cancel')+'</button><span style="flex:1"></span><button class="a-btn a-btn--primary" type="button" id="rf-send">'+sendLabel+'</button>';
  openDrawer(edit?'Edit request <code>'+esc(edit.id)+'</code>':(kind==="service"?'Request service':'Request replacement')+' <code>'+a.id+'</code>',body,foot);
  $("#rf-back").addEventListener("click",function(){if(edit)openRequest(edit);else if(fromAsset)openAsset(a.id);else closeDrawer()});
  wireUpload();
  function lostUI(){var lost=($('input[name="rf-reason"]:checked')||{}).value==="Lost or stolen";$("#rf-lost").hidden=!lost;$("#rf-inc-wrap").hidden=!lost;$("#rf-hand-wrap").hidden=lost;$('[data-err="rf-hand"]').hidden=true}
  if(kind==="replacement")$$('input[name="rf-reason"]').forEach(function(rb){rb.addEventListener("change",lostUI)});
  $$('#rf input[type=radio]').forEach(function(rb){rb.addEventListener("change",function(){var e=$('[data-err="'+rb.name+'"]');if(e)e.hidden=true})});
  if(edit){
    $("#rf-desc").value=edit.reason||"";setRadio("rf-urg",edit.urgency);
    if(kind==="replacement"){setRadio("rf-reason",edit.reasonType);$("#rf-when").value=edit.whenISO||isoFrom(edit.when);$("#rf-inc").value=edit.incident||"";$("#rf-hand").checked=true;lostUI()}
    else{setRadio("rf-issue",edit.issue);setRadio("rf-drop",edit.dropoff);$("#rf-date").value=edit.date2ISO||todayISO();$("#rf-loaner").checked=!!edit.loaner;$("#rf-backup").checked=!!edit.backup}
  }
  $("#rf-send").addEventListener("click",function(){
    var f=$("#rf"),ok=true,first=null;
    function val(n){var c=$('input[name="'+n+'"]:checked',f);return c?c.value:""}
    function need(cond,key,el){var e=$('[data-err="'+key+'"]',f);if(e)e.hidden=cond;if(!cond){ok=false;if(!first)first=el||e}}
    var desc=$("#rf-desc").value.trim();
    if(kind==="replacement"){
      var reason=val("rf-reason"),lost=reason==="Lost or stolen";
      need(!!reason,"rf-reason");need(desc.length>=10,"rf-desc",$("#rf-desc"));need(!!val("rf-urg"),"rf-urg");
      if(!lost)need($("#rf-hand").checked,"rf-hand");
    }else{
      need(!!val("rf-issue"),"rf-issue");need(desc.length>=10,"rf-desc",$("#rf-desc"));need(!!val("rf-urg"),"rf-urg");need(!!val("rf-drop"),"rf-drop");need($("#rf-backup").checked,"rf-backup");
    }
    if(!ok){if(first&&first.scrollIntoView)first.scrollIntoView({behavior:"smooth",block:"center"});return}
    var fields={reason:desc,urgency:val("rf-urg"),files:rfFiles.slice()};
    if(kind==="replacement"){fields.reasonType=val("rf-reason");fields.whenISO=$("#rf-when").value;fields.when=fmtDate(fields.whenISO);fields.incident=$("#rf-inc").value.trim()}
    else{fields.issue=val("rf-issue");fields.dropoff=val("rf-drop");fields.date2ISO=$("#rf-date").value;fields.date2=fmtDate(fields.date2ISO);fields.loaner=$("#rf-loaner").checked;fields.backup=true}
    var r;
    if(edit){r=edit;Object.keys(fields).forEach(function(k){r[k]=fields[k]});r.events=(r.events||[]).concat([["Edited",nowStamp(),"You updated the request details","note"]])}
    else{
      seq+=1;store("ax-asset-seq",seq);
      r={id:"REQ-0"+seq,kind:kind,assetId:a.id,title:(kind==="service"?"Service · ":"Replacement · ")+a.name,items:[TYPE_ICON[a.type]||"other"],name:ME.name,email:ME.email,status:"New",mine:true,buy:false,office:"Dubai",date:new Date().toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"})};
      Object.keys(fields).forEach(function(k){r[k]=fields[k]});
      r.events=[["New",nowStamp(),kind==="service"?"Service request sent to IT"+(r.loaner?" · loaner requested":""):"Replacement request sent To IT, CC "+ME.manager]];
      requests.unshift(r);
      NOTIFS.unshift({id:"n"+Date.now(),kind:"req",ref:r.id,t:(kind==="service"?"Service request ":"Replacement request ")+r.id+" sent",d:a.name+" ("+a.id+"). "+nextStep(r).step,at:new Date().toLocaleDateString("en-GB",{day:"numeric",month:"short"})+" · "+new Date().toTimeString().slice(0,5),unread:true});
      renderNotifs();
    }
    selectedReq=r.id;persist();renderAll();renderPick();
    showSent(r,!!edit);
  });
}
/* edit a New-kit request in the dialog */
function openKitEdit(r){
  rfFiles=(r.files||[]).slice();
  var body='<form class="rf" id="rf" novalidate>'+
    '<div><div class="rf-q">What do you need? <span class="req">*</span></div><div class="pills">'+ITEMS.map(function(it){return '<label class="radio-r sq"><input type="checkbox" name="rf-items" value="'+it[0]+'"'+(r.items.indexOf(it[0])!==-1?' checked':'')+'><i></i><span>'+esc(it[1])+'</span></label>'}).join("")+'</div><div class="err-t" data-err="rf-items" hidden>Tick at least one item.</div></div>'+
    '<div class="a-field" id="rf-other-wrap"'+(r.items.indexOf("other")===-1?' hidden':'')+'><label for="rf-other">Other peripheral</label><input class="a-input" id="rf-other" value="'+esc(r.other||"")+'" placeholder="Say what it is"></div>'+
    uploadField("A picture, forwarded email (.eml/.msg), PDF or Office file of the item.")+
    '<div class="a-field"><label for="rf-ref">Product reference</label><input class="a-input" id="rf-ref" value="'+esc(r.ref||"")+'" placeholder="Model, SKU, part number or product link"></div>'+
    '<div class="a-field"><label for="rf-desc">Business justification</label><textarea class="a-input" id="rf-desc" placeholder="Why you need it and where you work from">'+esc(r.reason||"")+'</textarea></div>'+
    '<div class="rf-note info">'+INFO_IC+'<span>Your manager and IT see the updated request. Changes are allowed while it is still New.</span></div></form>';
  openDrawer('Edit request <code>'+esc(r.id)+'</code>',body,'<button class="a-btn a-btn--secondary" type="button" id="rf-back">Back</button><span style="flex:1"></span><button class="a-btn a-btn--primary" type="button" id="rf-send">Save changes</button>');
  wireUpload();
  $$('input[name="rf-items"]').forEach(function(cb){cb.addEventListener("change",function(){$('[data-err="rf-items"]').hidden=true;$("#rf-other-wrap").hidden=!$('input[name="rf-items"][value="other"]').checked})});
  $("#rf-back").addEventListener("click",function(){openRequest(r)});
  $("#rf-send").addEventListener("click",function(){
    var items=$$('input[name="rf-items"]:checked').map(function(c){return c.value});
    if(!items.length){$('[data-err="rf-items"]').hidden=false;return}
    r.items=items;r.other=$("#rf-other").value.trim();r.ref=$("#rf-ref").value.trim();r.reason=$("#rf-desc").value.trim();r.files=rfFiles.slice();
    r.buy=items.indexOf("monitor")!==-1||items.indexOf("webcam")!==-1||items.indexOf("hdd")!==-1;
    r.events=(r.events||[]).concat([["Edited",nowStamp(),"You updated the request details","note"]]);
    persist();renderAll();showSent(r,true);
  });
}
function openEdit(r){if(r.kind==="service"||r.kind==="replacement")openReqForm(r.kind,r.assetId,false,r);else openKitEdit(r)}
/* confirmation shown right after sending or saving */
function showSent(r,edited){
  var dev=r.assetId?assetById(r.assetId):null;
  var body='<div class="sent"><span class="ok"><svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg></span><h4>'+(edited?'Changes saved':'Request sent')+'</h4><p>'+esc(nextStep(r).step)+'</p></div>'+
    '<dl class="dl">'+row("Request",'<code>'+esc(r.id)+'</code>')+row("Type",'<span class="a-tag">'+esc(KIND[r.kind||"kit"])+'</span>')+row(dev?"Device":"Items",dev?esc(dev.name)+' <span class="mono" style="color:var(--fg-3);font-size:12px">'+esc(dev.id)+'</span>':r.items.map(function(i){return '<span class="a-tag">'+esc(ITEM_LABEL[i])+'</span>'}).join(" "))+row("Status",statusChip(r.status))+row("Sent to",r.kind==="service"?"IT":"IT, CC "+esc(ME.manager))+'</dl>'+
    '<p class="a-help" style="margin-top:16px">You can edit or withdraw this request while it is still New. After IT starts on it, message IT to change or cancel it.</p>';
  var foot='<button class="a-btn a-btn--secondary" type="button" id="dr-withdraw">Withdraw</button><button class="a-btn a-btn--secondary" type="button" id="dr-edit">Edit</button><span style="flex:1"></span><button class="a-btn a-btn--primary" type="button" id="dr-view">View request</button>';
  openDrawer('<code>'+esc(r.id)+'</code> '+(edited?'Updated':'Sent'),body,foot);
  $("#dr-withdraw").addEventListener("click",function(){confirmWithdraw(r)});
  $("#dr-edit").addEventListener("click",function(){openEdit(r)});
  $("#dr-view").addEventListener("click",function(){openRequest(r)});
}
function messageIT(r){closeDrawer();var p=$("#msg-panel");p.classList.add("show");$("#msg-btn").setAttribute("aria-expanded","true");$("#ask-panel").classList.remove("show");openThread("Deepak Steevanson");$("#msg-in").value="Hi Deepak, can you help me change or cancel "+r.id+" ("+reqTitle(r)+")? ";$("#msg-in").focus()}
var rtype="kit";
var RT={
  kit:["Form AXAF0726015","Company Asset & Inventory Request Form","Ask IT for a keyboard, mouse, monitor, USB, headset or other peripheral. Mail goes To IT, CC your manager, who approves from the email. Finance is not emailed."],
  replacement:["Replacement","Replace a device","For a device on your name that is damaged, not working, lost or too old. IT checks stock first, issues the replacement and collects the old one."],
  service:["Service","Send a device for service","For a device on your name that needs a repair or a check. IT diagnoses it, sends it to the service centre if needed, and can lend you a device meanwhile."]
};
function renderPick(){
  var g=$("#pick-grid");if(!g)return;
  var mine=ASSETS.slice();
  $("#pick-title").textContent=rtype==="service"?"Which device needs service?":"Which device needs replacing?";
  g.innerHTML=mine.map(function(a){var o=openFor(a);return '<button class="pk" type="button" data-pk="'+a.id+'"'+(o?' aria-disabled="true"':'')+'>'+art(a.type)+'<span class="nm"><b>'+esc(a.name)+'</b><span>'+esc(a.id)+' · '+esc(a.serial)+'</span>'+(o?'<span class="busy"><em class="a-tag a-tag--warning" style="font-style:normal">'+esc(KIND[o.kind])+' '+esc(o.id)+' open</em></span>':'')+'</span><span class="go">'+IC.chev+'</span></button>'}).join("");
  $$(".pk",g).forEach(function(b){b.addEventListener("click",function(){var a=assetById(b.getAttribute("data-pk"));var o=openFor(a);if(o){openRequest(o);return}openReqForm(rtype,a.id,false)})});
}
function setRType(t){
  rtype=t;var d=RT[t];$("#rt-eyebrow").textContent=d[0];$("#rt-title").textContent=d[1];$("#rt-lead").textContent=d[2];
  $$(".rtype button").forEach(function(b){var on=b.getAttribute("data-rt")===t;b.classList.toggle("on",on);b.setAttribute("aria-selected",String(on))});
  $("#req-form").hidden=t!=="kit";$("#req-pick").hidden=t==="kit";renderPick();
}
$$(".rtype button").forEach(function(b){b.addEventListener("click",function(){setRType(b.getAttribute("data-rt"))})});

/* ---------- board + my requests ---------- */
function reqCard(r,sel){
  var ns=nextStep(r);
  return '<button class="rq'+(sel?' sel':'')+'" type="button" '+(sel===undefined?'data-req="'+esc(r.id)+'"':'data-sel="'+esc(r.id)+'"')+'><div class="t"><b>'+esc(reqTitle(r))+'</b><code>'+esc(r.id)+'</code></div>'+
    '<div class="items-l">'+statusChip(r.status)+'<span class="a-tag">'+esc(KIND[r.kind||"kit"])+'</span>'+(r.buy&&!isClosed(r.status)?'<span class="a-tag a-tag--warning">Buy</span>':'')+(r.files&&r.files.length?'<span class="a-tag">'+IC.clip+' '+r.files.length+'</span>':'')+'</div>'+
    '<div class="step">'+IC.step+'<span>'+esc(ns.step)+'</span></div><div class="by">'+esc(r.name)+' · '+esc(r.date)+(r.ref?' · '+esc(r.ref):'')+'</div>'+(sel!==undefined?'<span class="rq-more">View details '+IC.chev+'</span>':'<span class="rq-more always">View details '+IC.chev+'</span>')+'</button>';
}
function futureStages(r){
  if(r.kind==="service"){var sv=["New","In review","In repair","Ready for collection","Returned to you"];var si=sv.indexOf(r.status);return si===-1?sv:sv.slice(si+1)}
  if(r.kind==="replacement"){var rp=["New","In review"].concat(r.reason==="Lost or stolen"?[]:["Old device collected"]).concat(r.buy?["Waiting for approval","In procurement process","Waiting for CEO approval","CEO approved","Waiting for payment","Waiting for delivery"]:[]).concat(["Replacement delivered"]);var ri=rp.indexOf(r.status);if(r.status==="Reason not valid")return [];return ri===-1?rp:rp.slice(ri+1)}
  var all=["New","In review"].concat(r.buy?["Waiting for approval","In procurement process","Waiting for CEO approval","CEO approved","Waiting for payment","Waiting for delivery"]:[]).concat(["Product delivered"]);
  if(r.status==="Reason not valid")return [];
  var i=all.indexOf(r.status);return i===-1?all:all.slice(i+1);
}
/* My requests table (My assets page). Filters: All (default) · Open · Closed. Rows open the request popup on Timeline. */
var MRT={"mr-table":{tabs:"#mr-tabs",f:"all"},"home-mr-table":{tabs:"#home-mr-tabs",f:"all"}};
var MRF=[["all","All",function(){return true}],["open","Open",function(r){return !isClosed(r.status)}],["closed","Closed",function(r){return isClosed(r.status)}]];
function renderBoard(){Object.keys(MRT).forEach(drawMyReqs)}
function drawMyReqs(id){
  var st=MRT[id],tabs=$(st.tabs),tb=$("#"+id+" tbody");if(!tabs||!tb)return;
  var mine=requests.filter(function(r){return r.mine});
  tabs.innerHTML=MRF.map(function(f){var n=mine.filter(f[2]).length;return '<button type="button" role="tab" data-mrf="'+f[0]+'" class="'+(f[0]===st.f?'on':'')+'" aria-selected="'+(f[0]===st.f)+'">'+f[1]+'<span class="n">'+n+'</span></button>'}).join("");
  $$("[data-mrf]",tabs).forEach(function(b){b.addEventListener("click",function(){st.f=b.getAttribute("data-mrf");drawMyReqs(id)})});
  var f=MRF.filter(function(x){return x[0]===st.f})[0];var list=sortBy(mine.filter(f[2]),id,{request:function(r){return reqTitle(r)},type:function(r){return KIND[r.kind||"kit"]},status:function(r){return r.status}});
  tb.innerHTML=list.length?list.map(function(r){
    var dev=r.assetId?assetById(r.assetId):null;
    var thumb=dev?art(dev.type):art(ITEM_ART[r.items[0]]||"Other");
    return '<tr class="row" tabindex="0" data-mr="'+esc(r.id)+'"><td class="num">'+esc(r.id)+'<span style="display:block;font-size:12px;color:var(--fg-3)">'+esc(r.date)+'</span></td>'+
      '<td><div class="cell">'+thumb+'<div class="it-main"><b>'+esc(reqTitle(r))+'</b><span>'+esc(dev?dev.id+' · '+dev.serial:(r.ref||'No product reference'))+'</span></div></div></td>'+
      '<td><span class="a-tag">'+esc(KIND[r.kind||"kit"])+'</span></td>'+
      '<td><div style="display:flex;gap:6px;align-items:center">'+statusChip(r.status)+(r.buy&&!isClosed(r.status)?'<span class="a-tag a-tag--warning">Buy</span>':'')+'</div></td>'+
      '<td><div class="ns"><span>'+IC.step+'</span><span>'+esc(nextStep(r).step)+'</span></div></td><td class="go">'+IC.chev+'</td></tr>';
  }).join(""):'<tr class="none-row"><td colspan="6">'+(st.f==="closed"?"No closed requests yet.":"No requests here. Use New request to ask IT for kit.")+'</td></tr>';
  $$("tr.row",tb).forEach(function(tr){var open=function(){var r=requests.filter(function(x){return x.id===tr.getAttribute("data-mr")})[0];if(r)openRequest(r,"timeline")};
    tr.addEventListener("click",open);tr.addEventListener("keydown",function(e){if(e.key==="Enter"||e.key===" "){e.preventDefault();open()}})});
}
function mineListHtml(list,total){
  return '<div style="display:flex;flex-direction:column;gap:10px;margin-top:16px">'+list.map(function(r){return reqCard(r)}).join("")+'</div><a class="a-btn a-btn--secondary a-btn--sm" href="#kit" data-board style="margin-top:12px;align-self:flex-start">'+(total>2?'See all '+total+' in My assets':'See all in My assets')+'</a>';
}
function renderMine(){
  var mine=requests.filter(function(r){return r.mine&&!isClosed(r.status)});
  var box=$("#my-requests");if(!box)return;
  if(!mine.length){box.innerHTML='<div class="empty"><span class="ti">'+IC.keyboard+'</span><b>No kit requests yet</b>Use Requests to ask for a keyboard, mouse, monitor or other peripheral.<a class="a-btn a-btn--secondary a-btn--sm" href="#requests" style="margin-top:8px">Open the request form</a></div>'}
  else{
    /* the two most recent open requests; the rest live on the board */
    box.innerHTML=mineListHtml(mine.slice(0,2),mine.length);
    $("[data-board]",box).addEventListener("click",function(){setTimeout(scrollBoard,80)});
    bindReq(box,"timeline");
  }
  sizeHomePanels();
}
/* both home panels share one minimum height: My requests holding two requests */
function sizeHomePanels(){
  var mp=$("#mine-panel"),ap=$("#ack-panel");if(!mp||!ap)return;
  var vis=$("#view-home").classList.contains("on");
  var w=mp.getBoundingClientRect().width;
  if(!vis||!w){return}
  var probe=mp.cloneNode(false);probe.removeAttribute("id");
  probe.style.cssText="position:absolute;visibility:hidden;left:-9999px;top:0;min-height:0;width:"+w+"px";
  probe.innerHTML=mp.querySelector("h3").outerHTML+mp.querySelector(".hint").outerHTML+'<div>'+mineListHtml(SAMPLE.slice(0,2),2)+'</div>';
  mp.parentNode.appendChild(probe);var h=Math.ceil(probe.getBoundingClientRect().height);probe.remove();
  [mp,ap].forEach(function(el){el.style.minHeight=h+"px"});
}
var spT;window.addEventListener("resize",function(){clearTimeout(spT);spT=setTimeout(sizeHomePanels,150)});
function bindReq(root,startTab){$$("[data-req]",root).forEach(function(b){b.addEventListener("click",function(){var r=requests.filter(function(x){return x.id===b.getAttribute("data-req")})[0];if(r)openRequest(r,startTab)})})}
function renderAll(){renderStats();renderKit();renderTeam();renderBoard();renderMine();renderReqHero()}
function renderReqHero(){var n=requests.filter(function(r){return r.mine&&!isClosed(r.status)}).length;$("#req-hero-meta").innerHTML='<span>'+n+' open request'+(n===1?'':'s')+'</span><i></i><span>New kit, replacement or service</span><i></i><span>Mail goes to IT, CC '+esc(ME.manager)+'</span>'}

/* ---------- team requests: manager approves → Admin (CEO / IT admin) → Procurement ---------- */
var ITEM_ART={keyboard:"Keyboard",mouse:"Mouse",monitor:"Monitor",laptop:"Laptop",dock:"Accessory",usb:"Accessory",hdd:"Accessory",headset:"Headset",webcam:"Webcam",tablet:"Tablet",phone:"Other"};
function tLabel(k){return k==="laptop"?"Laptop":(ITEM_LABEL[k]||k)}
var TSTAT={
  mgr:["Waiting for your approval","warning","You"],
  admin:["Waiting for admin approval","info","Admin"],
  proc:["With procurement","info","Procurement"],
  done:["Delivered","success","—"],
  declined:["Declined by you","error","—"]
};
var TEAM_SAMPLE=[
  {id:"REQ-0122",who:"Rafsal KK",title:"Front-end Developer",kind:"replacement",items:["laptop"],ref:"Apple MacBook Pro 14-inch, M4 Pro, 24 GB",reason:"Current laptop (AST-0031, 2019) takes several minutes to build the design system and runs out of memory with Figma and the dev server open.",files:["build-time-log.png"],cost:"AED 8,999 (Apple Store quote)",needBy:"10 Nov 2026",date:"25 Oct 2026",status:"mgr",
   events:[["Request sent","25 Oct 2026 · 16:20","Rafsal sent it to you for approval"]]},
  {id:"REQ-0121",who:"Megha Mohan",title:"Product Designer",kind:"kit",items:["monitor","dock"],ref:"Dell U2723QE + Dell WD19S dock",reason:"Second screen for reviewing app screens side by side with Figma at the office desk.",files:["dell-quote.pdf"],cost:"AED 2,890 (Dell quote)",needBy:"3 Nov 2026",date:"24 Oct 2026",status:"mgr",
   events:[["Request sent","24 Oct 2026 · 10:05","Megha sent it to you for approval"]]},
  {id:"REQ-0119",who:"Sambrit Bidari",title:"UI Designer",kind:"kit",items:["headset"],ref:"Jabra Evolve2 40",reason:"Daily calls with the Uganda team. The open office is too loud without a headset.",files:[],cost:"AED 420 (estimate)",needBy:"—",date:"23 Oct 2026",status:"mgr",
   events:[["Request sent","23 Oct 2026 · 09:41","Sambrit sent it to you for approval"]]},
  {id:"REQ-0116",who:"Mohammed Nafih",title:"UX Researcher",kind:"kit",items:["keyboard","mouse"],ref:"Logitech MX Keys S + MX Master 3S",reason:"Ergonomic set for long research write-ups. Current keyboard is shared.",files:[],cost:"AED 760 (estimate)",needBy:"—",date:"20 Oct 2026",status:"admin",
   events:[["Request sent","20 Oct 2026 · 11:12","Mohammed sent it to you for approval"],["Approved by you","21 Oct 2026 · 09:30","Sent to Admin for approval"]]},
  {id:"REQ-0112",who:"Oumaima Jbeli",title:"Visual Designer",kind:"kit",items:["monitor"],ref:"LG UltraFine 27-inch 5K",reason:"Colour-accurate screen for brand and print work.",files:["lg-ultrafine-spec.pdf"],cost:"AED 5,200 (estimate)",needBy:"31 Oct 2026",date:"15 Oct 2026",status:"proc",
   events:[["Request sent","15 Oct 2026 · 14:02","Oumaima sent it to you for approval"],["Approved by you","15 Oct 2026 · 16:40","Sent to Admin for approval"],["Approved by Admin","17 Oct 2026 · 10:15","CEO Waleed Al Aryan approved"],["With procurement","17 Oct 2026 · 10:16","Yahia is collecting quotations"]]},
  {id:"REQ-0108",who:"Saba Mohamad",title:"Content Designer",kind:"kit",items:["webcam"],ref:"Logitech Brio 500",reason:"Better picture on client calls.",files:[],cost:"AED 450 (estimate)",needBy:"—",date:"9 Oct 2026",status:"declined",
   events:[["Request sent","9 Oct 2026 · 12:30","Saba sent it to you for approval"],["Declined by you","9 Oct 2026 · 15:05","Already available in the team · Use the meeting-room camera for client calls"]]}
];
var TEAM=(function(){var saved=store("ax-team-reqs")||{};return TEAM_SAMPLE.map(function(r){var s=saved[r.id];if(s){r.status=s.status;r.events=s.events;r.note=s.note}return r})})();
function saveTeam(){var o={};TEAM.forEach(function(r){o[r.id]={status:r.status,events:r.events,note:r.note}});store("ax-team-reqs",o)}
function teamById(id){return TEAM.filter(function(r){return r.id===id})[0]}
function tTitle(r){return r.items.map(tLabel).join(" + ")}
function tChip(r){var s=TSTAT[r.status];return '<span class="a-tag a-tag--'+s[1]+'">'+esc(s[0])+'</span>'}
function first(r){return r.who.split(" ")[0]}
var teamFilter={home:"all",view:"all"};
var TFILTERS=[["all","All",function(){return true}],["mgr","Needs your approval",function(r){return r.status==="mgr"}],["moving","In progress",function(r){return r.status==="admin"||r.status==="proc"}],["closed","Closed",function(r){return r.status==="done"||r.status==="declined"}]];
function renderTeam(){renderStats();drawTeam("#team-tabs","#team-table","home",false);drawTeam("#tv-tabs","#tv-table","view",true);renderTeamStats();renderTeamPeople()}
function renderTeamStats(){
  var n=function(s){return TEAM.filter(function(r){return s.indexOf(r.status)!==-1}).length};
  var mine=n(["mgr"]);
  var CLOCK='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>';
  var SHIELD='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/></svg>';
  var CART='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.6 12.4a2 2 0 0 0 2 1.6h8.2a2 2 0 0 0 2-1.5L22 7H6"/></svg>';
  var DONE='<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>';
  ["#team-stats"].forEach(function(sel){
  var box=$(sel);var onHome=sel==="#home-team-stats";
  if(box){
    var adm=n(["admin"]),prc=n(["proc"]),cls=n(["done","declined"]);
    box.innerHTML=[
      ["#team","mgr",CLOCK,(mine?mine+" waiting for you":"Nothing waiting for you"),"Requests from your team that need you to approve or decline.","Review"],
      ["#team","moving",SHIELD,adm+" with Admin","Approved by you. CEO Waleed or the IT admin approves the spend next.","Track"],
      ["#team","moving",CART,prc+" with Procurement","Approved by Admin. Yahia gets quotations and buys the kit.","Track"],
      ["#team","closed",DONE,cls+" closed","Requests that were delivered or declined.","See closed"]
    ].map(tileHtml).join("");
    $$("[data-tile]",box).forEach(function(el){el.addEventListener("click",function(e){e.preventDefault();teamFilter.view=el.getAttribute("data-tile");renderTeam();
      if(onHome&&location.hash!=="#team")location.hash="team";scrollToEl("#tv-tabs")})});
  }
  });
  var tm=$("#team-hero-meta");if(tm){var ppl={};TEAM.forEach(function(r){ppl[r.who]=1});tm.innerHTML='<span>'+(mine?mine+' waiting for you':'Nothing waiting for you')+'</span><i></i><span>'+Object.keys(ppl).length+' people in your team</span><i></i><span>You → Admin → Procurement</span>';}
  /* waiting-on-you count on the menu and dock */
  $$('.nav [data-nav="team"],.mnav [data-nav="team"]').forEach(function(a){a.innerHTML='Team requests'+(mine?'<span class="nav-n">'+mine+'</span>':'')});
  var d=$("#dock-team-n");if(d){d.hidden=!mine;d.textContent=mine}
}
function renderTeamPeople(){
  var box=$("#team-people");if(!box)return;
  var seen={};var ppl=TEAM.filter(function(r){if(seen[r.who])return false;seen[r.who]=1;return true});
  box.innerHTML=ppl.map(function(p){var open=TEAM.filter(function(r){return r.who===p.who&&(r.status==="mgr"||r.status==="admin"||r.status==="proc")}).length;var wait=TEAM.filter(function(r){return r.who===p.who&&r.status==="mgr"}).length;
    return '<button class="pp" type="button" data-tp="'+esc(p.who)+'"><span class="av">'+initials(p.who)+'</span><span class="nm"><b>'+esc(p.who)+'</b><span>'+esc(p.title)+' · '+(open?open+' open request'+(open>1?'s':''):'No open requests')+'</span></span>'+(wait?'<span class="a-tag a-tag--warning">Needs you</span>':'')+'</button>'}).join("");
  $$("[data-tp]",box).forEach(function(b){b.addEventListener("click",function(){var who=b.getAttribute("data-tp");var p=$("#msg-panel");p.classList.add("show");$("#msg-btn").setAttribute("aria-expanded","true");$("#ask-panel").classList.remove("show");openThread(who)})});
}
function drawTeam(tabsSel,tableSel,key,wide){
  var tabs=$(tabsSel);if(!tabs)return;var cur=teamFilter[key];
  tabs.innerHTML=TFILTERS.map(function(f){var n=TEAM.filter(f[2]).length;return '<button type="button" role="tab" data-tf="'+f[0]+'" class="'+(f[0]===cur?'on':'')+'" aria-selected="'+(f[0]===cur)+'">'+esc(f[1])+'<span class="n">'+n+'</span></button>'}).join("");
  $$("[data-tf]",tabs).forEach(function(b){b.addEventListener("click",function(){teamFilter[key]=b.getAttribute("data-tf");renderTeam()})});
  var f=TFILTERS.filter(function(x){return x[0]===cur})[0];
  var list=sortBy(TEAM.filter(f[2]),tableSel.slice(1),{who:function(r){return r.who},item:function(r){return tTitle(r)},raised:function(r){return dnum(r.date)},status:function(r){return ["mgr","admin","proc","done","declined"].indexOf(r.status)}});
  var tb=$(tableSel+" tbody");
  tb.innerHTML=list.length?list.map(function(r){
    return '<tr class="row'+(r.status==="mgr"?' mine-turn':'')+'" tabindex="0" data-team="'+r.id+'"><td class="num">'+r.id+(wide?'<span style="display:block;font-size:12px;color:var(--fg-3)">'+esc(r.date)+'</span>':'')+'</td>'+
      '<td><div class="cell"><span class="av">'+initials(r.who)+'</span><div class="it-main"><b>'+esc(r.who)+'</b><span>'+esc(r.title)+'</span></div></div></td>'+
      '<td><div class="cell">'+art(ITEM_ART[r.items[0]]||"Other")+'<div class="it-main"><b>'+esc(tTitle(r))+'</b><span>'+esc(KIND[r.kind])+' · '+esc(r.ref)+'</span></div></div></td>'+
      (wide?'<td class="num">'+esc(r.cost.replace(/\s*\(.*\)$/,""))+'</td><td class="dim">'+esc(r.needBy)+'</td>':'')+
      (wide?'':'<td class="dim">'+esc(r.date)+'</td>')+'<td>'+tChip(r)+'</td><td class="go">'+IC.chev+'</td></tr>';
  }).join(""):'<tr class="none-row"><td colspan="'+(wide?7:6)+'">'+(cur==="mgr"?"Nothing is waiting for you. New requests from your team appear here.":"No team requests here.")+'</td></tr>';
  $$("tr.row",tb).forEach(function(tr){
    var open=function(){openTeam(teamById(tr.getAttribute("data-team")))};
    tr.addEventListener("click",open);tr.addEventListener("keydown",function(e){if(e.key==="Enter"||e.key===" "){e.preventDefault();open()}});
  });
}
function chainHtml(r){
  var s=r.status;
  var st={mgr:["done","now","todo","todo"],admin:["done","done","now","todo"],proc:["done","done","done","now"],done:["done","done","done","done"],declined:["done","stop","skip","skip"]}[s];
  var TICK='<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>';
  var X='<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';
  var steps=[["1 · Request",first(r)+" asked"],["2 · You",s==="declined"?"Declined":"Manager approval"],["3 · Admin","CEO Waleed or IT admin"],["4 · Procurement","Yahia buys it"]];
  var lab={done:"Done",now:"Now",todo:"Next",stop:"Declined",skip:"Not needed"};
  return '<div class="chain" aria-label="Approval path">'+steps.map(function(x,i){var k=st[i];return '<div class="ch '+k+'"><span class="k"><i>'+(k==="done"?TICK:k==="stop"?X:"")+'</i>'+lab[k]+'</span><b>'+esc(x[0])+'</b><span>'+esc(x[1])+'</span></div>'}).join("")+'</div>';
}
function tFutures(r){
  var all=[["Your approval","Approve or decline. Approved requests go to Admin."],["Admin approval","CEO Waleed or IT admin approves the spend."],["With procurement","Yahia gets quotations and buys it."],["Delivered","IT issues it to "+first(r)+"."]];
  var from={mgr:0,admin:1,proc:2,done:4,declined:4}[r.status];
  return all.slice(from+1);
}
function openTeam(r,startTab){
  if(!r)return;
  var lead={mgr:"Waiting for you. Approve to send it to Admin, or decline with a reason.",admin:"You approved this. Admin (CEO Waleed or IT admin) is reviewing it.",proc:"Admin approved this. Procurement is buying it.",done:"Delivered to "+first(r)+".",declined:"You declined this. "+first(r)+" was told why."}[r.status];
  var next='<div class="panel" style="padding:14px 16px;margin-bottom:16px;background:var(--surface);border-color:transparent"><div class="eyebrow" style="margin-bottom:6px">Next step</div><div style="display:flex;gap:10px;align-items:flex-start"><span style="color:var(--brand);margin-top:4px">'+IC.step+'</span><span style="font-size:15px">'+esc(lead)+'</span></div></div>';
  var details=next+'<dl class="dl">'+
    row("Requested by",'<span style="display:inline-flex;align-items:center;gap:10px"><span class="av">'+initials(r.who)+'</span><span>'+esc(r.who)+'<br><span style="color:var(--fg-3);font-size:12px">'+esc(r.title)+' · Dubai</span></span></span>')+
    row("Type",'<span class="a-tag">'+esc(KIND[r.kind])+'</span>')+row("Status",tChip(r))+
    row("Items",r.items.map(function(i){return '<span class="a-tag">'+esc(tLabel(i))+'</span>'}).join(" "))+
    row("Product reference",esc(r.ref))+row("Estimated cost",esc(r.cost))+row("Needed by",esc(r.needBy))+
    row("Business justification",esc(r.reason))+
    row("Attachments",r.files.length?r.files.map(function(f){return '<span class="a-tag">'+IC.clip+' '+esc(f)+'</span>'}).join(" "):"—")+
    (r.note?row("Your note",esc(r.note)):"")+'</dl>';
  var history=timelineHtml(r.events,tFutures(r),r.status==="done"||r.status==="declined");
  var body='<div class="dhero">'+art(ITEM_ART[r.items[0]]||"Other","lg")+'<div><h4>'+esc(tTitle(r))+'</h4><p>'+esc(KIND[r.kind])+' · '+esc(r.who)+' · '+esc(r.date)+'</p></div></div>'+chainHtml(r)+tabs([["Details",details],["Timeline",history]],startTab==="timeline"?1:0);
  var CHAT='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>';
  var foot=r.status==="mgr"
    ?'<button class="a-btn a-btn--secondary" type="button" id="tm-decline">Decline</button><span style="flex:1"></span><button class="a-btn a-btn--secondary" type="button" id="tm-ask">'+CHAT+'Ask '+esc(first(r))+'</button><button class="a-btn a-btn--primary" type="button" id="tm-approve"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>Approve</button>'
    :'<span class="foot-note">'+(r.status==="declined"?"Declined requests are closed. "+esc(first(r))+" can send a new one.":"This is out of your hands now. You get a notification at each step.")+'</span><span style="flex:1"></span><button class="a-btn a-btn--secondary" type="button" id="tm-ask">'+CHAT+'Message '+esc(first(r))+'</button>';
  openDrawer('<code>'+esc(r.id)+'</code> Team request',body,foot);
  $("#tm-ask").addEventListener("click",function(){askPerson(r)});
  var ap=$("#tm-approve");if(ap)ap.addEventListener("click",function(){confirmApprove(r)});
  var dc=$("#tm-decline");if(dc)dc.addEventListener("click",function(){confirmDecline(r)});
}
function askPerson(r){closeDrawer();var p=$("#msg-panel");p.classList.add("show");$("#msg-btn").setAttribute("aria-expanded","true");$("#ask-panel").classList.remove("show");openThread(r.who);$("#msg-in").value="Hi "+first(r)+", about "+r.id+" ("+tTitle(r)+"): ";$("#msg-in").focus()}
/* approve / decline modal */
var tYes=null;
var OK_IC='<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>';
var NO_IC='<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';
function openTModal(o){
  $("#t-ic").className="mi "+o.tone;$("#t-ic").innerHTML=o.icon;$("#t-title").textContent=o.title;$("#t-text").textContent=o.text;$("#t-body").innerHTML=o.body||"";
  var y=$("#t-yes");y.className="a-btn a-btn--primary";y.textContent=o.yes;tYes=o.onYes;
  $("#tscrim").classList.add("show");(o.focus?$(o.focus):$("#t-no")).focus();
}
function closeTModal(){$("#tscrim").classList.remove("show");tYes=null}
$("#t-no").addEventListener("click",closeTModal);
$("#tscrim").addEventListener("click",function(e){if(e.target===this)closeTModal()});
$("#t-yes").addEventListener("click",function(){if(tYes)tYes()});
function confirmApprove(r){
  openTModal({tone:"ok",icon:OK_IC,title:"Approve "+r.id+"?",text:tTitle(r)+" for "+r.who+". It goes to Admin (CEO Waleed or IT admin) next, then to Procurement.",
    body:'<div class="a-field"><label for="t-note">Note for Admin <span class="a-help">(optional)</span></label><textarea class="a-input" id="t-note" maxlength="300" placeholder="For example: budgeted in Q4 design tools"></textarea></div>',
    yes:"Approve",onYes:function(){
      var note=$("#t-note").value.trim();r.status="admin";r.note=note||r.note;
      r.events=r.events.concat([["Approved by you",nowStamp(),note?"Sent to Admin · “"+note+"”":"Sent to Admin for approval"]]);
      saveTeam();closeTModal();renderTeam();openTeam(r);toast(r.id+" approved. Sent to Admin.","success");
    }});
}
function confirmDecline(r){
  openTModal({tone:"err",icon:NO_IC,title:"Decline "+r.id+"?",text:first(r)+" gets a notification with your reason. The request closes and does not reach Admin.",danger:true,
    body:'<div><div class="rf-q">Reason <span class="req">*</span></div>'+pills("t-reason",["Not needed for the role","Already available in the team","Over budget this quarter","Other"],true)+'</div><div class="a-field"><label for="t-note">Message to '+esc(first(r))+' <span class="a-help" id="t-note-h">(optional)</span></label><textarea class="a-input" id="t-note" maxlength="300" placeholder="Explain what to do instead"></textarea><div class="err-t" data-err="t-note" hidden>Add a short explanation when the reason is Other.</div></div>',
    yes:"Decline request",onYes:function(){
      var c=$('input[name="t-reason"]:checked');var note=$("#t-note").value.trim();
      $('[data-err="t-reason"]').hidden=!!c;if(!c)return;
      var other=c.value==="Other";$('[data-err="t-note"]').hidden=!(other&&!note);if(other&&!note){$("#t-note").focus();return}
      r.status="declined";r.note=note||r.note;
      r.events=r.events.concat([["Declined by you",nowStamp(),(other?"":c.value)+(note?(other?"":" · ")+note:"")]]);
      saveTeam();closeTModal();renderTeam();openTeam(r);toast(r.id+" declined. "+first(r)+" has been told.");
    }});
  $$('input[name="t-reason"]').forEach(function(rb){rb.addEventListener("change",function(){$('[data-err="t-reason"]').hidden=true;$("#t-note-h").textContent=rb.value==="Other"?"(required)":"(optional)"})});
}

/* ---------- process playbook ---------- */
function box(n,cls){return '<div class="d-box'+(cls?" "+cls:"")+'">'+esc(n[0])+(n[1]?'<small>'+esc(n[1])+'</small>':'')+'</div>'}
function arrow(){return '<div class="arr">'+IC.step+'</div>'}
function pipe(nodes){return '<div class="d-row path">'+nodes.map(function(n,i){return (i?arrow():"")+box(n)}).join("")+'</div>'}
function branches(list){return '<div class="branches">'+list.map(function(br){return '<div class="branch"><span class="branch-lab">'+esc(br[0])+'</span><div class="lane-path">'+br[1].map(function(n,i){return (i?arrow():"")+box(n)}).join("")+'</div></div>'}).join("")+'</div>'}
function renderFlow(f){
  if(!f)return "";
  var cap='<div class="cap">'+esc(f.cap||"")+'</div>';
  if(f.kind==="pipe")return '<div class="diag">'+cap+pipe(f.nodes)+'</div>';
  if(f.kind==="fan")return '<div class="diag">'+cap+'<div class="fan"><div class="d-row">'+box(f.start,"hub")+'</div><div class="d-down">↓</div><div class="d-row">'+f.nodes.map(function(n){return box(n)}).join("")+'</div></div></div>';
  if(f.kind==="fork")return '<div class="diag">'+cap+'<div class="d-row" style="margin-bottom:12px">'+box(f.start,"hub")+'</div>'+branches(f.branches)+'</div>';
  if(f.kind==="story")return '<div class="diag">'+cap+pipe(f.lead)+'<div class="d-down">↓ then one of '+f.branches.length+' paths</div>'+branches(f.branches)+'</div>';
  if(f.kind==="cycle")return '<div class="diag">'+cap+'<div class="cycle">'+f.stages.map(function(s,i){return '<div class="cyc"><span class="n">0'+(i+1)+'</span><b>'+esc(s[0])+'</b><ul>'+s[1].map(function(p){return '<li>'+esc(p)+'</li>'}).join("")+'</ul></div>'}).join("")+'</div></div>';
  if(f.kind==="map")return '<div class="diag"><div class="cap">Map of all modules</div><div class="fan"><div class="d-row">'+box(["Sign in","Work email · team HTTPS"],"hub")+'</div><div class="d-down">↓</div><div class="d-row">'+[["IT · Ultimate","Deepak · delete"],["IT","No delete"],["CEO","Waleed · seal"],["HR","People + My assets + request"],["Manager","My assets + joiners + requests"],["Procurement","Yahia · stock / buy"],["Finance","Sabareesh · payment only"],["Staff","My assets + request"]].map(function(n){return box(n)}).join("")+'</div><div class="d-down">↓</div><div class="d-row">'+box(["Overview","Counts jump to a tab"],"hub")+'</div><div class="d-down">↓</div><div class="d-row">'+[["People","HR and IT"],["Assets","IT · My assets"],["Stock","Unassigned kit"],["Infrastructure","IT only"],["New joiners","HR → mgr → IT → sign"],["Kit requests","Staff and HR already here"],["Kit report","IT only"],["Backup","IT only"]].map(function(n){return box(n)}).join("")+'</div></div></div>'+
    '<div class="diag" style="margin-top:12px"><div class="cap">New joiners</div>'+pipe([["1. HR","Person and position"],["2. Manager","Laptop + keyboard"],["3. IT","Serial or asset ID"],["4. Employee signs","AXAF0726015"],["Joined"]])+'</div>'+
    '<div class="diag" style="margin-top:12px"><div class="cap">Kit requests — stock vs buy</div>'+pipe([["Staff submit","To IT, CC manager"],["Manager Approve","in that email"],["IT checks stock"]])+'<div class="d-down">↓ then one of three paths</div>'+branches([["In stock",[["IT issues it","Yahia not emailed"],["Product delivered"]]],["No stock",[["Send to Procurement"],["Yahia quotes","this product"],["CEO Approve","in that email"],["Finance pays","Waiting for payment"],["Product delivered"]]],["Not valid",[["Reason not valid","IT only"]]]])+'</div>';
  return "";
}
function renderModList(){
  $("#mod-list").innerHTML=MODULES.map(function(m){return '<button type="button" data-mod="'+m.id+'">'+esc(m.title)+'<small>'+esc(m.who)+'</small></button>'}).join("");
  $$("#mod-list button").forEach(function(b){b.addEventListener("click",function(){showModule(b.getAttribute("data-mod"));settleHelp()})});
  var wrap=$("#mod-select-wrap"),list=$("#mod-list-m"),btn=$("#mod-select");
  list.innerHTML=MODULES.map(function(m){return '<button type="button" role="option" data-opt="'+m.id+'">'+esc(m.title)+'</button>'}).join("");
  function closeSel(){wrap.classList.remove("open");list.hidden=true;btn.setAttribute("aria-expanded","false")}
  btn.addEventListener("click",function(e){e.stopPropagation();var o=list.hidden;list.hidden=!o;wrap.classList.toggle("open",o);btn.setAttribute("aria-expanded",String(o))});
  $$("button",list).forEach(function(b){b.addEventListener("click",function(){showModule(b.getAttribute("data-opt"));closeSel()})});
  document.addEventListener("click",function(e){if(!wrap.contains(e.target))closeSel()});
}
var curMod="map";
function settleHelp(force){var top=$("#mod-panel").getBoundingClientRect().top+window.scrollY-72;if(force||window.scrollY>top)window.scrollTo({top:top,behavior:"smooth"})}
function showModule(id){
  var m=MODULES.filter(function(x){return x.id===id})[0]||MODULES[0];curMod=m.id;
  $$("#mod-list button").forEach(function(b){b.classList.toggle("on",b.getAttribute("data-mod")===m.id)});
  $("#mod-select-text").textContent=m.title;$$("#mod-list-m button").forEach(function(b){b.classList.toggle("on",b.getAttribute("data-opt")===m.id)});
  var i=MODULES.indexOf(m);
  var html='<div class="page-h"><div class="eyebrow" style="margin-bottom:10px">Help &amp; Support · '+(i+1)+' of '+MODULES.length+'</div><h1>'+esc(m.title)+'</h1><p class="lead">'+esc(m.intro)+'</p><div style="margin-top:14px"><span class="who">'+esc(m.who)+'</span></div></div>';
  html+='<div class="sec"><h2>Diagram <small>'+esc(m.flow&&m.flow.cap||m.title)+'</small></h2>'+renderFlow(m.flow)+'</div>';
  if(m.lane)html+='<div class="sec"><h2>Who does what</h2><div class="lane">'+m.lane.map(function(l){return '<div><b>'+esc(l[0])+'</b><span>'+esc(l[1])+'</span></div>'}).join("")+'</div></div>';
  if(m.cards)html+='<div class="sec"><h2>Questions this answers</h2><div class="pq">'+m.cards.map(function(c){return '<div><b>'+esc(c[0])+'</b><span>'+esc(c[1])+'</span></div>'}).join("")+'</div></div>';
  if(m.steps)html+='<div class="sec"><h2>Steps</h2><div class="plist">'+m.steps.map(function(s,k){return '<div><span class="n">'+(k+1)+'</span><div><h3>'+esc(s[0])+'</h3><p>'+esc(s[1])+'</p></div></div>'}).join("")+'</div></div>';
  var prev=MODULES[i-1],next=MODULES[i+1];
  html+='<div class="sec" style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap">'+(prev?'<button class="a-btn a-btn--secondary" type="button" data-mod-go="'+prev.id+'">← '+esc(prev.title)+'</button>':'<span></span>')+(next?'<button class="a-btn a-btn--secondary" type="button" data-mod-go="'+next.id+'">'+esc(next.title)+' →</button>':'')+'</div>';
  $("#mod-body").innerHTML=html;
  $$("[data-mod-go]").forEach(function(b){b.addEventListener("click",function(){showModule(b.getAttribute("data-mod-go"));settleHelp(true)})});
}

/* ---------- sign-in showcase ---------- */
var SI={
  login:{t:"Sign in",l:"Use your @alphax.ae work email and password, or Sign in with Google. Other domains cannot sign in.",b:"Sign in",pw:true},
  create:{t:"Create your sign-in",l:"First time? Type your @alphax.ae work email and choose a password on this page. You must already be on People. There is no public self-register.",b:"Save password",pw:true},
  change:{t:"Change password",l:"Type your work email and current password. We email a verification link and a 6-digit code. The new password is saved only after that email is used.",b:"Email me a verification code",pw:true},
  forgot:{t:"Forgot password",l:"Type your @alphax.ae work email. We send a verification link and a 6-digit code to that inbox. Check junk if it is not there.",b:"Email me a verification code",pw:false}
};
var siMode="login";
function setSi(m){siMode=m;var d=SI[m];$("#si-title").textContent=d.t;$("#si-lead").textContent=d.l;$("#si-btn").textContent=d.b;$("#si-pw-wrap").hidden=!d.pw;$("#si-err").classList.remove("show");
  $$("[data-si]").forEach(function(a){var k=a.getAttribute("data-si");a.textContent=(m===k)?"Back to sign in":{create:"Create your sign-in",change:"Change password",forgot:"Forgot password?"}[k]})}
$$("[data-si]").forEach(function(a){a.addEventListener("click",function(){var k=a.getAttribute("data-si");setSi(siMode===k?"login":k)})});
$("#si-form").addEventListener("submit",function(e){
  e.preventDefault();var em=$("#si-email").value.trim().toLowerCase();var err=$("#si-err");
  if(!em){err.textContent="Type your work email.";err.classList.add("show");return}
  if(!/@alphax\.ae$/.test(em)){err.textContent="Use your @alphax.ae work email. Other domains cannot sign in.";err.classList.add("show");return}
  if(siMode==="login"){if(!$("#si-pw").value){err.textContent="Type your password.";err.classList.add("show");return}toast("Signed in as "+em+" (design preview).","success");location.hash="home";return}
  err.classList.remove("show");toast(siMode==="create"?"Password saved. Remember this password, then sign in.":"If that work email is on file, we sent a verification email with a link and a 6-digit code.","success");setSi("login");
});
$("#si-google").addEventListener("click",function(){var err=$("#si-err");err.textContent="IT has not connected Google sign-in yet. Use Create your sign-in, or ask IT to paste the Google client ID on New joiners.";err.classList.add("show")});

/* ---------- toasts ---------- */
var TOAST_IC={success:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>',error:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',"default":'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v4h1"/></svg>'};
/* DS a-toast: default (container) or success / error */
function toast(msg,kind){var k=kind==="success"||kind==="error"?kind:"default";var t=document.createElement("div");t.className="a-toast a-toast--"+k;t.setAttribute("role","status");t.innerHTML='<div class="tt"><span class="ti">'+TOAST_IC[k]+'</span><div class="tx"><b>'+esc(msg)+'</b></div></div>';$("#toasts").appendChild(t);setTimeout(function(){t.style.transition="opacity .3s";t.style.opacity="0";setTimeout(function(){t.remove()},320)},3600)}

/* ---------- Ask the register ---------- */
var FAQ=[
  {k:/my team|team request|approve (a|my|their|the)|decline|direct report/,a:"Requests from your team come to you first. Open <b>Team requests</b> in the menu, open a row and tap <b>Approve</b> or <b>Decline</b>. Approved requests go to <b>Admin</b> (CEO Waleed or IT admin), then to <b>Procurement</b>. A decline needs a reason and closes the request."},
  {k:/request|keyboard|mouse|monitor|peripheral|headset|usb|webcam|dock/,a:"Open <b>Requests</b>, tick what you need on form AXAF0726015, add a product reference and a short business justification, then <b>Send request to IT</b>. Mail goes To IT, CC your manager, who taps Approve in that email. Finance is not emailed. You can withdraw your own request while it is still New."},
  {k:/replac|broken|damag|lost|stolen|cracked/,a:"Open the device on <b>My assets</b> and tap <b>Request replacement</b>, or go to <b>Requests → Replacement</b> and pick the device. Choose the reason, say what happened, and confirm you will hand the old device back. Lost or stolen devices are locked and wiped by IT."},
  {k:/service|repair|fix|battery|slow|not working/,a:"Open the device on <b>My assets</b> and tap <b>Request service</b>, or go to <b>Requests → Service</b>. Pick what needs attention, how urgent it is, and whether IT should collect it. You can ask for a loaner device. Service requests do not need manager approval."},
  {k:/approv|manager|who signs off|ceo|waleed/,a:"Your <b>manager</b> approves a new request from the email (Approve button). Only tap Approve if the sender is Alpha X IT (alphax.ae) and the link is this register. <b>CEO Waleed</b> approves only vendor quotations when something must be bought. Managers are Waleed Al Aryan, Anna Chatziioannou, Mike Karavidas and Spiros Pilafas."},
  {k:/stock|buy|purchase|procure|yahia|vendor|quot/,a:"IT checks unassigned stock at your office first. <b>In stock</b>: IT issues it and marks Product delivered, Procurement is not emailed. <b>No stock</b>: IT sends it to Procurement (ymohamad@alphax.ae), Yahia quotes the product, CEO Waleed approves the comparison sheet, Finance records payment, then it is delivered."},
  {k:/handover|sign the|acknowledg|axaf|newbee|joiner/,a:"New joiners run HR → manager → IT → employee. When IT marks your kit ready you get the signing link by email. Open it and sign the Company Asset &amp; Inventory Acknowledgement Form <b>AXAF0726015</b>. The signed form is then logged under <b>My recent activity</b> on My assets."},
  {k:/sign in|login|log in|password|forgot|google|create/,a:"Sign in with your <b>@alphax.ae</b> work email and password at the team HTTPS link. First time: <b>Create your sign-in</b> sets the first password if you are already on People. <b>Forgot</b> or <b>Change password</b> email a verification link and a 6-digit code. Google works once IT connects it; gmail.com is rejected."},
  {k:/desk|role|staff|hr|finance|tabs|see/,a:"Sign-in decides the desk. <b>Staff</b> see My assets, the request form and every office request. HR adds People and New joiners. Managers confirm newbee kit. Procurement buys only when IT has no stock. Finance records payment only. IT holds the full register; Ultimate IT (Deepak) can delete."},
  {k:/status|next step|where is my|track|deliver/,a:"Open your request card. Each card shows the <b>next step</b> rather than the ten office statuses: IT is checking stock → Procurement is buying this → Finance is recording payment → Waiting for the item to arrive → Delivered. Later status changes email you, with IT and your manager copied."},
  {k:/attach|picture|photo|file|email of|pdf/,a:"On the request form, tick an item and an <b>Attach a file</b> box appears on that row. Add a picture, a forwarded email (.eml or .msg), a PDF or an Office file; more than one is fine. IT, Procurement and CEO Waleed see the files. You can add or remove them while the request is New or In review."},
  {k:/chat|message|talk to|people in the office/,a:"Use the <b>Messages</b> button in the bottom-right corner. It lists people in the office; open a person and type like a phone chat (800 characters, about 80 messages per conversation, not emailed). Only Ultimate IT can remove a chat message."},
  {k:/host|laptop|127|tunnel|link|url|address/,a:"Open the team HTTPS link <code>https://inventory.alphaxdev.online</code>, not 127.0.0.1 on another laptop; that address only works on the host machine. Mail links use the team HTTPS URL."},
  {k:/return|give back|leav|exit/,a:"Returned items go back to unassigned stock so the next request can be filled without buying. Exiting a person does not collect their kit; it stays on their name until IT returns it to stock or assigns it to someone else."}
];
function ask(q){
  var log=$("#ask-log");log.insertAdjacentHTML("beforeend",'<div class="bub me">'+esc(q)+'</div>');
  var hit=null;var ql=q.toLowerCase();for(var i=0;i<FAQ.length;i++){if(FAQ[i].k.test(ql)){hit=FAQ[i];break}}
  var a=hit?hit.a:"I only know this register's process notes. Try asking about sign in, your desk, kit requests, stock versus buy, new joiners, attachments or office chat. For anything else, message IT from the Messages button.";
  setTimeout(function(){log.insertAdjacentHTML("beforeend",'<div class="bub">'+a+'<small>From the process notes · I cannot change records</small></div>');log.scrollTop=log.scrollHeight},250);
  log.scrollTop=log.scrollHeight;
}
(function(){function sync(){[["#ask-btn","#ask-panel"],["#msg-btn","#msg-panel"]].forEach(function(x){var b=$(x[0]),o=$(x[1]).classList.contains("show");b.classList.toggle("open",o);b.setAttribute("aria-expanded",String(o));b.setAttribute("aria-label",o?"Close "+(x[0]==="#ask-btn"?"Ask the register":"Messages"):(x[0]==="#ask-btn"?"Ask the register":"Messages"))})}
["#ask-panel","#msg-panel"].forEach(function(id){new MutationObserver(sync).observe($(id),{attributes:true,attributeFilter:["class"]})});sync()})();
$("#ask-btn").addEventListener("click",function(){var p=$("#ask-panel");var o=!p.classList.contains("show");p.classList.toggle("show",o);this.setAttribute("aria-expanded",String(o));$("#msg-panel").classList.remove("show");if(o)$("#ask-q").focus()});
$("#ask-form").addEventListener("submit",function(e){e.preventDefault();var q=$("#ask-q").value.trim();if(!q)return;$("#ask-q").value="";ask(q)});
$$("#ask-chips button").forEach(function(b){b.addEventListener("click",function(){ask(b.textContent)})});

/* ---------- Messages ---------- */
var threads={};
var seeded={"Anna Chatziioannou":[{me:false,t:"Hi Jerrin — I approved your last kit request from the email. Let me know if IT needs anything from me.",ts:"Yesterday 16:12"}],"Deepak Steevanson":[{me:false,t:"Your MacBook Pro AST-0044 is on the register. Shout if the serial on the sticker does not match.",ts:"21 Oct 09:40"}]};
function renderPeople(q){
  q=(q||"").toLowerCase();
  $("#people").innerHTML=PEOPLE.filter(function(p){return !q||p.toLowerCase().indexOf(q)!==-1}).map(function(p){
    var th=threads[p]||seeded[p];var last=th&&th.length?th[th.length-1].t:"Tap to chat";
    return '<button class="pp" type="button" data-person="'+esc(p)+'"><span class="av">'+initials(p)+'</span><span class="nm"><b>'+esc(p)+(ROLE[p]?'<em class="role">'+ROLE[p]+'</em>':'')+'</b><span>'+esc(last)+'</span></span></button>';
  }).join("")||'<div class="none" style="padding:16px;color:var(--fg-3);font-size:13px">Nobody in the office matches that.</div>';
  $$("#people .pp").forEach(function(b){b.addEventListener("click",function(){openThread(b.getAttribute("data-person"))})});
}
var curPerson=null;
function openThread(p){
  curPerson=p;if(!threads[p])threads[p]=(seeded[p]||[]).slice();
  $("#msg-panel").classList.add("thread");$("#msg-title").textContent=p;$("#msg-sub").textContent=ROLE[p]||"In the office";
  renderThread();$("#msg-in").focus();
}
function renderThread(){
  var th=threads[curPerson]||[];var log=$("#msg-log");
  log.innerHTML=th.length?th.map(function(m){return '<div class="bub'+(m.me?" me":"")+'">'+esc(m.t)+'<small>'+esc(m.ts)+'</small></div>'}).join(""):'<div class="bub" style="align-self:center;color:var(--fg-3)">Start the conversation with '+esc(curPerson.split(" ")[0])+'. Messages stay in the register and are not emailed.</div>';
  log.scrollTop=log.scrollHeight;
}
$("#msg-form").addEventListener("submit",function(e){e.preventDefault();var v=$("#msg-in").value.trim();if(!v||!curPerson)return;threads[curPerson].push({me:true,t:v,ts:"Just now"});$("#msg-in").value="";renderThread();renderPeople($("#msg-q").value)});
$("#msg-back").addEventListener("click",function(){$("#msg-panel").classList.remove("thread");$("#msg-title").textContent="Messages";$("#msg-sub").textContent="People in the office";renderPeople($("#msg-q").value)});
$("#msg-new").addEventListener("click",function(){$("#msg-q").value="";renderPeople("");$("#msg-q").focus()});
$("#msg-q").addEventListener("input",function(){renderPeople(this.value)});
$("#msg-btn").addEventListener("click",function(){var p=$("#msg-panel");var o=!p.classList.contains("show");p.classList.toggle("show",o);this.setAttribute("aria-expanded",String(o));$("#ask-panel").classList.remove("show");$("#msg-dot").hidden=true;if(o&&!p.classList.contains("thread"))renderPeople($("#msg-q").value)});
$("#msg-dot").hidden=false;

/* ---------- boot ---------- */
renderItems();renderAll();renderModList();showModule("map");renderPeople("");
onHash();
})();
