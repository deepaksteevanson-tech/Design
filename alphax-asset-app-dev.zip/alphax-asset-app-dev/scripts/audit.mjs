// AlphaX quality check — run before every hand-off / publish.
//   npm run audit        → checks the source (Vite dev server)
//   npm run audit:dist   → builds first, then checks dist/ (Vite preview server)
//
// What it checks
//   1. Colour audit: every rendered text / background / border colour on every page, menu, popup
//      and panel (light + dark) must be an Alpha DS colour or a DS alpha step (100/48/20/12/8/6%).
//   2. Layout: no sideways page scroll at 390, 820, 1440 and 1920 (Compact density) on every page.
//   3. Runtime: no JavaScript errors.
// Exit code 1 if anything fails, so it can gate CI.
//
// First run only: npx playwright install chromium

import { chromium } from "playwright";
import { createServer, preview, build } from "vite";

const useDist = process.argv.includes("--dist");
const PAGES = ["home", "kit", "team", "requests", "help", "signin"];
const DS = ["#fcfcf4", "#1d1d1f", "#f2f2f2", "#292c30", "#fc4a2e", "#fd6e58", "#1d66ec", "#5e9bf9", "#1ba850", "#3cdf76", "#eab308", "#dc2626"];

let server, base;
if (useDist) {
  await build({ logLevel: "warn" });
  server = await preview({ preview: { port: 4173, open: false }, logLevel: "warn" });
  base = "http://localhost:4173/";
} else {
  server = await createServer({ server: { port: 5174, open: false }, logLevel: "warn" });
  await server.listen();
  base = "http://localhost:5174/";
}

const browser = await chromium.launch(process.env.AX_CHROMIUM ? { executablePath: process.env.AX_CHROMIUM } : {}); // AX_CHROMIUM = optional path to an existing Chrome/Chromium
const colourIssues = new Set();
const layoutIssues = [];
const jsErrors = [];

function audit(page, label) {
  return page.evaluate(([DS, label]) => {
    const hex = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
    const base = DS.map(hex);
    const mix = (a, c, t) => a.map((v, i) => Math.round(v * t + c[i] * (1 - t)));
    base.push(mix(hex("#1d1d1f"), hex("#f2f2f2"), 0.06), mix(hex("#fcfcf4"), hex("#292c30"), 0.06), mix(hex("#1d1d1f"), hex("#fcfcf4"), 0.08));
    const alphas = [1, 0, 0.48, 0.478, 0.2, 0.08, 0.078, 0.06, 0.059, 0.12];
    const ok = (c) => {
      const m = c.match(/rgba?\(([^)]+)\)/);
      if (!m) return true;
      const v = m[1].split(",").map(Number);
      const a = v.length > 3 ? v[3] : 1;
      if (a === 0) return true;
      if (!alphas.some((x) => Math.abs(x - a) < 0.006)) return false;
      return base.some((b) => b.every((x, i) => Math.abs(x - v[i]) <= 2)) || (v[0] === 0 && v[1] === 0 && v[2] === 0);
    };
    const out = [];
    document.querySelectorAll("body *").forEach((el) => {
      const r = el.getBoundingClientRect();
      if (!r.width || !r.height || el.closest("svg") || el.closest("#si-google")) return;
      const cs = getComputedStyle(el);
      if (cs.visibility === "hidden") return;
      const tag = el.tagName.toLowerCase() + (el.id ? "#" + el.id : "") + (typeof el.className === "string" && el.className ? "." + el.className.split(" ")[0] : "");
      [["color", cs.color], ["background", cs.backgroundColor], ["border", cs.borderTopWidth !== "0px" ? cs.borderTopColor : "rgba(0,0,0,0)"]].forEach(([k, v]) => {
        if (!ok(v)) out.push(`${label}: ${tag} ${k} ${v}`);
      });
    });
    return out;
  }, [DS, label]);
}

// 1. colour audit, light + dark
for (const theme of ["light", "dark"]) {
  const p = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  p.on("pageerror", (e) => jsErrors.push(String(e)));
  await p.addInitScript((t) => localStorage.setItem("ax-theme", JSON.stringify(t)), theme);
  const run = async (label) => (await audit(p, `${theme} ${label}`)).forEach((x) => colourIssues.add(x));
  for (const v of PAGES) {
    await p.goto(base + "#" + v);
    await p.waitForTimeout(300);
    await run(v);
  }
  await p.goto(base + "#home");
  await p.waitForTimeout(300);
  await p.click("#notif-btn"); await run("notifications"); await p.click("#notif-btn");
  await p.click("#prof-btn"); await run("profile menu"); await p.click("#prof-btn");
  await p.click("#kit-table tr.row"); await p.waitForTimeout(250); await run("asset popup");
  await p.click("#dr-service"); await p.waitForTimeout(250); await run("service form"); await p.click("#dr-close");
  await p.click("#team-table tr.row"); await p.waitForTimeout(250); await run("team popup");
  await p.click("#tm-decline"); await run("decline modal"); await p.click("#t-no"); await p.click("#dr-close");
  await p.click("#msg-btn"); await run("messages"); await p.click("#ask-btn"); await run("ask");
  await p.close();
}

// 2. layout: no sideways scroll
const sizes = [[390, 844, "default"], [820, 1180, "default"], [1440, 900, "default"], [1920, 1080, "compact"]];
for (const [w, h, density] of sizes) {
  const p = await browser.newPage({ viewport: { width: w, height: h } });
  p.on("pageerror", (e) => jsErrors.push(String(e)));
  await p.addInitScript((d) => localStorage.setItem("ax-density", JSON.stringify(d)), density);
  for (const v of PAGES) {
    await p.goto(base + "#" + v);
    await p.waitForTimeout(250);
    const over = await p.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    if (over > 0) layoutIssues.push(`${w}px ${density} #${v}: ${over}px sideways overflow`);
  }
  await p.close();
}

await browser.close();
if (useDist) server.httpServer.close(); else await server.close();

const report = (title, list) => {
  console.log(`\n${list.length ? "✗" : "✓"} ${title}: ${list.length}`);
  list.slice(0, 50).forEach((x) => console.log("  " + x));
};
report("Colour issues (non-DS colours)", [...colourIssues]);
report("Layout issues", layoutIssues);
report("JavaScript errors", [...new Set(jsErrors)]);
process.exit(colourIssues.size || layoutIssues.length || jsErrors.length ? 1 : 0);
